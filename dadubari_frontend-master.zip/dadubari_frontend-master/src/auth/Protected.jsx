import { useDispatch, useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';
import { userLoginCheck } from '../Reducers/userReducers/userSlice';
import { useEffect } from 'react';

const Protected = (props) => {
      const dispatch = useDispatch();
      useEffect(()=>{
        dispatch(userLoginCheck());
      },[dispatch]);
      
      const isAuth = useSelector(data=>data.users);

      return isAuth.dadubari&&isAuth.dadubari ? (
        props.element 
      ) : (
        <Navigate to="/login" />
      );
  
}

export default Protected