import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

const CorporateProtected = (props) => {
    const isAuth = useSelector(data=>data.corporateAuth);
    return isAuth.corporateToken&&isAuth.corporateToken ? (
      props.element 
    ) : (
      <Navigate to="/corporate/login" />
    );
}

export default CorporateProtected