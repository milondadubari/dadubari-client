
const findChatOwner=(loggedInId,chat)=>{
    let user;
    if (loggedInId === chat?.users[0]?._id) {
        user = chat?.users[1];
      } else {
        user = chat?.users[0];
      }
      return user;
}

const sOrNot=(value,type)=>{
  const typeWithS = type+"s";
      return`${value<=1 ? value +" "+ type : value + " " + typeWithS}`;
}

export {findChatOwner, sOrNot};