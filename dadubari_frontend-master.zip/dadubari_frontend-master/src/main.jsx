import React from "react";
import "./index.css";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import { Provider } from "react-redux";
import { store } from "./store.js";
import { AboutProvider } from "./context/AboutContext.jsx";
import ChatProvider from "./context/ChatContext.jsx";
import { PostProvider } from "./context/PostContext.jsx";
import { CorporateProfileProvider } from "./context/CorporateProfileContext.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Provider store={store}>
      <ChatProvider>
        <AboutProvider>
        <PostProvider>
          <CorporateProfileProvider>
          <App />
          </CorporateProfileProvider>
          </PostProvider>
        </AboutProvider>
      </ChatProvider>
    </Provider>
  </React.StrictMode>
);
