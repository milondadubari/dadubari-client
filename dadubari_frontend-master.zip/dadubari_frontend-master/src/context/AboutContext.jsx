import { createContext, useState } from "react";

const aboutContext = createContext([]);

function AboutProvider({ children }) {
    const [about , setAbout] = useState([])
  return <aboutContext.Provider value={{about,setAbout}}>{children}</aboutContext.Provider>;
}

export {AboutProvider,aboutContext}
