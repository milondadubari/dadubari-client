import { createContext, useContext, useState } from "react";

const ChatContext = createContext();

const ChatProvider = ({ children }) => {
  const [chatDetails, setChatDetails] = useState();
  return (
    <ChatContext.Provider
      value={{
        chatDetails,
        setChatDetails,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const ChatState = () => {
  return useContext(ChatContext);
};

export default ChatProvider;
