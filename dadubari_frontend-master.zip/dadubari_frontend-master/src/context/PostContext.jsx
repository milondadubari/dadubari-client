import { createContext, useContext, useState } from "react";

const postContext = createContext([]);

function PostProvider({ children }) {
    const [post , setPost] = useState([]);
    const [length , setLength] = useState(1);
  return <postContext.Provider value={{post , setPost, length , setLength}}>{children}</postContext.Provider>;
}
export const PostContext = () => {
    return useContext(postContext);
  };
export {PostProvider,postContext}