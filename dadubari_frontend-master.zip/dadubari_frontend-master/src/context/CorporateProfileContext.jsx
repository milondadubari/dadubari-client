import { createContext, useState } from "react";

const corporateProfileContext = createContext([]);

function CorporateProfileProvider({ children }) {
    const [corporateProfile , setCorporateProfile] = useState([])
  return <corporateProfileContext.Provider value={{corporateProfile , setCorporateProfile}}>{children}</corporateProfileContext.Provider>;
}

export {CorporateProfileProvider, corporateProfileContext}