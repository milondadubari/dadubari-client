import MyProfile from "../MyProfile/MyProfile";

const Single = () => {
  return (
    <MyProfile>
    </MyProfile>
  );
};

export default Single;
