import { useState } from "react";
import {
  RiFacebookCircleFill,
  RiInstagramLine,
  RiYoutubeLine,
} from "react-icons/ri";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { userForgetPassword } from "../../Reducers/userReducers/userSlice";

const ForgetPassword = () => {
  let [email, setEmail] = useState("");
  const dispatch = useDispatch();
  const handleSubmit = (event) => {
    event.preventDefault();
    email = email.toLowerCase();
    const data = {
      email,
    }
    dispatch(userForgetPassword(data));
  };
  return (
    <div className="bg-violet-500 min-h-screen flex items-center justify-center">
      <div className="md:flex w-full md:w-[70vw]">
        {/* left part */}
        <div className="flex lg:w-1/2 bg-gradient-to-tr from-blue-800 to-purple-700 justify-center md:justify-around items-center  rounded-l-md">
          <div className="px-10 py-16 md:py-32 md:px-20">
            <img
              className="w-32 mx-auto m-2"
              src="https://i.ibb.co/cJhTWSC/dadubari-logo.png"
              alt=""
            />
            <h1 className="text-white font-bold text-3xl font-sans text-center mt-4">
              Join DaduBari
            </h1>
            <p className="text-white mt-1 text-center">
              The best social media platform of Bangladesh
            </p>
            <div className="flex justify-center gap-2 text-3xl text-white mt-4 ">
              <a href="https://www.facebook.com/dadu.bari/" target="blank"><RiFacebookCircleFill /></a>
              <a href="https://www.instagram.com/dadubari" target="blank"><RiInstagramLine /></a>
              <a href="https://www.youtube.com/@dadubari" target="blank"><RiYoutubeLine /></a>
            </div>
            <div className="flex justify-center items-center text-gray-200 mt-4">
              <p>Dadubari <Link to={"/Users-Terms-And-Condition"} className="underline hover:text-white cursor-pointer">Terms & Condition</Link> </p>
            </div>
          </div>
        </div>
        {/* right part */}
        <div className="flex lg:w-1/2 justify-center items-center bg-white  rounded-r-md">
          <form onSubmit={handleSubmit} className="bg-white px-6 py-10 md:p-10">
            <h1 className="text-gray-800 font-bold text-2xl mb-2">
              Forgot Password!
            </h1>
            <p className="text-sm mb-7 bg-[#4e46e521] p-5 text-center">
              Enter your Email Address Or Phone Number here
            </p>
            <div className="flex items-center border-2 py-2 px-3 rounded-2xl">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"
                />
              </svg>
              <input
                className="pl-2 outline-none border-none"
                type="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                id="idEmail"
                placeholder="Email Address"
              />
            </div>
            <div className="my-2 text-center">
              <p className="text-indigo-500 font-semibold">Or</p>
            </div>
            <div className="flex items-center border-2 py-2 px-3 rounded-2xl mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                height="1em"
                className="fill-gray-400"
                viewBox="0 0 512 512"
              >
                <path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z" />
              </svg>
              <input
                className="pl-2 outline-none border-none"
                type="number"
                name="phone"
                placeholder="Phone Number"
              />
            </div>
            <button
              type="submit"
              className="block w-full bg-indigo-600 mt-4 py-2 rounded-2xl text-white font-semibold mb-2"
            >
              Continue
            </button>
            <span className="text-sm ml-2 ">
              Login here{" "}
              <span className="text-blue-500 cursor-pointer">
                <Link className="font-semibold" to={`/login`}>Login</Link>
              </span>{" "}
            </span>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgetPassword;
