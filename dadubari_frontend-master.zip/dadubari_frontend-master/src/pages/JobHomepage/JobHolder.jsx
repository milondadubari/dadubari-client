import verifyIcon from "../../icons/svg/verifyIcon.svg";
const JobHolder = () => {
  return (
    <div className="container mx-auto space-x-3 px-3 my-3 min-h-screen grid grid-cols-4">
      <div className=" col-span-3 space-y-2">
        <div className="space-y-3">
          <div className="gap-4 bg-white rounded-lg p-3">
            <div className="relative mb-16">
              <div className="relative -z-5 ">
                <img
                  src="https://i.ibb.co/TPGFMqQ/cover-OIG-Z1-Z.jpg"
                  className="rounded-t-lg w-[100vw]"
                  alt=""
                />
              </div>
              <img
                src="https://i.ibb.co/D1xYMM4/bird-logo.png"
                className="w-44 bg-white -my-16 border-4 z-10 absolute bottom-[5%] left-[5%] border-amber-400 rounded-xl object-contain"
              />
            </div>
            <div className="pl-10 space-y-2">
              <h1 className="font-semibold text-2xl flex gap-3 items-center">
                MM IT and Software Leading <br /> Software Company Of Bangladesh{" "}
                <span>
                  <img src={verifyIcon} alt="" />
                </span>{" "}
              </h1>
              <h2 className="font-medium">Zigatola, Dhanmondi , Dhaka</h2>
            </div>
          </div>
          <div className="bg-white rounded-lg p-3 space-y-3">
            <div>
              <h1 className="font-medium text-xl mb-3 pl-4">About Us</h1>
              <p className="text-gray-500 bg-gray-50 flex-1 p-4 rounded-lg">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Laudantium illum optio commodi quidem reprehenderit doloribus,
                amet voluptas nemo beatae ea at nesciunt ratione eligendi
                reiciendis, quisquam eos magnam. Quia animi aliquam dignissimos
                quidem rerum minima rem earum iusto voluptatem officiis
                architecto, facilis alias. Magni deleniti ullam delectus? Beatae
                voluptatum enim tempore neque laudantium, quas qui facilis
                reprehenderit soluta sit debitis repellendus, quod velit quae
                libero quidem praesentium? Optio incidunt excepturi hic
                accusamus, cumque impedit asperiores laudantium iure assumenda
                qui cum quis ipsam dolor id nemo fugit nisi delectus repellat,
                explicabo, voluptatum aperiam eos! Aliquam accusamus excepturi
                cumque laborum iste. Aperiam.
              </p>
            </div>
          </div>
          <div className="bg-white rounded-lg p-3 space-y-3">
            <h1 className="font-medium text-xl mb-3 pl-4">People</h1>
            <div className="grid grid-cols-3 gap-3 p-3">
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
              <div className="shadow-lg rounded-md">
                <div className="relative">
                  <div className="relative -z-5 ">
                    <img
                      src="https://i.ibb.co/60y1W9w/about.jpg"
                      className="rounded-t-lg"
                      alt=""
                    />
                  </div>
                  <img
                    src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg"
                    alt="User"
                    className="w-5/12 -my-20 border-4 z-10 absolute right-[29%] border-white rounded-xl"
                  />
                </div>
                <div className="mt-[9vh] text-center">
                  <h1 className="text-2xl font-medium">Rafik Alam</h1>
                  <div className="flex justify-center items-center mt-4 pb-10">
                    <p className="text-gray-900 font-medium">
                      React Developer | Full Stack Developer
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className=" space-y-2">
        <h1 className="bg-white p-4 rounded-lg text-2xl font-bold">
          Jobs by this Company
        </h1>
        <div className="bg-white p-3 rounded-lg space-y-3">
          <div className="space-y-3 h-screen" style={{ overflowY: "scroll" }}>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Software Engineer</h1>
              <p className="font-medium">Tech Innovators Inc.</p>
              <p>
                <b>Location:</b> New York
              </p>
              <p>
                <b>Experience:</b> 5 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Marketing Manager</h1>
              <p className="font-medium">Global Solutions Co.</p>
              <p>
                <b>Location:</b> London
              </p>
              <p>
                <b>Experience:</b> 6 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Front-End Developer</h1>
              <p className="font-medium">WebTech Systems Ltd.</p>
              <p>
                <b>Location:</b> San Francisco
              </p>
              <p>
                <b>Experience:</b> 4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Data Analyst</h1>
              <p className="font-medium">Data Insights Corporation</p>
              <p>
                <b>Location:</b> Chicago
              </p>
              <p>
                <b>Experience:</b> 2 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">UX Designer</h1>
              <p className="font-medium">Creative Studios Ltd.</p>
              <p>
                <b>Location:</b> Los Angeles
              </p>
              <p>
                <b>Experience:</b> 3 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Software Developer</h1>
              <p className="font-medium">Tech Solutions Inc.</p>
              <p>
                <b>Location:</b> Seattle
              </p>
              <p>
                <b>Experience:</b> 4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">HR Manager</h1>
              <p className="font-medium">People First Corp.</p>
              <p>
                <b>Location:</b> Toronto
              </p>
              <p>
                <b>Experience:</b> 5 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Graphic Designer</h1>
              <p className="font-medium">DesignWorks Studio</p>
              <p>
                <b>Location:</b> Sydney
              </p>
              <p>
                <b>Experience:</b> 3 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Financial Analyst</h1>
              <p className="font-medium">FinancePro Inc.</p>
              <p>
                <b>Location:</b> New York
              </p>
              <p>
                <b>Experience:</b> 2 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Quality Assurance Specialist
              </h1>
              <p className="font-medium">TechTest Solutions</p>
              <p>
                <b>Location:</b> San Francisco
              </p>
              <p>
                <b>Experience:</b> 4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Content Writer</h1>
              <p className="font-medium">ContentCreators Ltd.</p>
              <p>
                <b>Location:</b> Los Angeles
              </p>
              <p>
                <b>Experience:</b> 2 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">Software Architect</h1>
              <p className="font-medium">TechVision Systems</p>
              <p>
                <b>Location:</b> Boston
              </p>
              <p>
                <b>Experience:</b> 7 Years
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobHolder;
