import { Link } from "react-router-dom";

const Job = () => {
  return (
    <div className="container mx-auto space-x-3 px-3 my-3 min-h-screen grid grid-cols-4">
      <div className=" col-span-3 space-y-2">
        <div className="space-y-3">
          <div className="flex gap-4 bg-white rounded-lg p-3">
            <input
              type="text"
              className="h-10 bg-gray-100 rounded-md w-[800px] px-4 text-gray-800 focus:outline-none"
              placeholder="Search by keyword"
            />
            <select className="h-10 min-w-[200px] bg-gray-100 rounded-md px-4 text-gray-800 focus:outline-none">
              <option value="">Organization Type </option>
              <option value="Government">Government</option>
              <option value="Semi Government">Semi Government</option>
              <option value="Non Government/Company">
                Non Government / Company
              </option>
              <option value="Freelancing">Freelancing</option>
            </select>
            <button
              type="submit"
              className="whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md"
            >
              {" "}
              Search
            </button>
          </div>
          <div className="bg-white rounded-lg p-3 space-y-3">
            <h1 className="text-2xl font-bold">Categories</h1>
            <div>
              <table className="w-full border border-solid  divide-y rounded-lg">
                <tr className="divide-x text-lg">
                  <th className="p-5">Government</th>
                  <th className="p-5">Semi Government</th>
                  <th className="p-5">Non Government / Company</th>
                  <th className="p-5">Freelancing</th>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Railways</td>
                  <td className="p-2">BEPZA</td>
                  <td className="p-2">BRAC</td>
                  <td className="p-2">Graphic Designer</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Finance</td>
                  <td className="p-2">Dhaka Water Supply</td>
                  <td className="p-2">Grameen Bank</td>
                  <td className="p-2">Content Writer</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Home Affairs</td>
                  <td className="p-2">Chittagong Port Authority</td>
                  <td className="p-2">Save the Children</td>
                  <td className="p-2">Web Developer</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Health and Family Welfare</td>
                  <td className="p-2">BIFC</td>
                  <td className="p-2">CARE Bangladesh</td>
                  <td className="p-2">SEO Specialist</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Education</td>
                  <td className="p-2">Bangladesh Bank</td>
                  <td className="p-2">Oxfam in Bangladesh</td>
                  <td className="p-2">UX Designer</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Agriculture</td>
                  <td className="p-2">BTRC</td>
                  <td className="p-2">The Hunger Project</td>
                  <td className="p-2">Translator</td>
                </tr>
                <tr className="divide-x">
                  <td className="p-2">Ministry of Commerce</td>
                  <td className="p-2">Bangladesh Railway</td>
                  <td className="p-2">Plan International</td>
                  <td className="p-2">Photographer</td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div className=" space-y-2">
        <button className="bg-purple-500 text-white mt-3 cursor-pointer p-2 rounded-lg text-lg  font-semibold">
          <Link to="/job-application">Job Applicant</Link>
        </button>
        <h1 className="bg-white p-4 rounded-lg text-2xl font-bold">
          Latest Jobs
        </h1>
        <div className="bg-white p-3 rounded-lg space-y-3">
          <div
            className="space-y-3"
            style={{ maxHeight: "400px", overflowY: "scroll" }}
          >
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
            <div className="p-3 rounded-md bg-gray-100">
              <h1 className="text-lg font-bold">
                Product Development Executive (CSE Background)
              </h1>
              <p className="font-medium">Printhouse Ltd.</p>
              <p>
                <b>Location:</b> Dhaka
              </p>
              <p>
                <b>Experience:</b> 3/4 Years
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Job;
