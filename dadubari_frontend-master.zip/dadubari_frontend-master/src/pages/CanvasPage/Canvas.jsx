
import uploadImage from "../../icons/svg/uploadImage.svg";
import commentMore from "../../icons/svg/commentMore.svg";
import CanvasUserDetails from "../../components/Canvas/CanvasUserDetails/CanvasUserDetails";

const Canvas = () => {
  return (
    <div className="container my-3 mx-auto space-y-3 px-3 ">
      {/* User Details Part */}
      <CanvasUserDetails/>
      {/* Short info and post and product */}
      <div className="grid grid-cols-1  lg:grid-cols-2 gap-3">
        {/* About info & Product cards */}
        <div className="space-y-3">
          {/* About info */}
          <div className="rounded-lg bg-white p-4 space-y-4 w-full">
            {/* About */}
            <div>
              <h1 className="font-medium text-lg mb-3 pl-4">About</h1>
              <p className="text-gray-500 bg-gray-50 flex-1 p-4 rounded-lg">
                Welcome to CarHut, your ultimate destination for premium cars!
                🚗💨 Discover a wide range of meticulously curated vehicles that
                redefine luxury and performance. Whether you seek sleek sedans,
                rugged SUVs, or powerful sports cars, CarHut offers top-notch
                automobiles tailored to your preferences. Stay tuned for our
                latest arrivals, expert reviews, and exclusive deals. Drive into
                excellence with CarHut - where your dream car awaits!"
              </p>
            </div>
            {/* Contact Info */}
            <div className="flex flex-wrap gap-3">
              {/* Email */}
              <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                <h1 className="font-medium text-lg">Email Address</h1>
                <p className="text-gray-500">carhat@email.com</p>
              </div>
              {/* Phone Number */}
              <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                <h1 className="font-medium text-lg">Phone Number</h1>
                <p className="text-gray-500">0987245294, 1098347192</p>
              </div>
              {/* Website */}
              <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                <h1 className="font-medium text-lg">Website</h1>
                <p className="text-gray-500">Carhat.com.bd</p>
              </div>
            </div>

            {/* Location */}
            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
              <h1 className="font-medium text-lg">Location</h1>
              <p className="text-gray-500">Mirpur, Dhaka, Bangladesh</p>
            </div>
          </div>
          {/* Product cards 2 in a row */}
          <div className="rounded-lg bg-white p-4 space-y-4 w-full">
            {/* Featured Product */}
            <div>
              <h1 className="font-medium text-xl mb-3 pl-4">
                Featured Product
              </h1>
            </div>
            {/* Product card */}
            <div className="flex flex-wrap gap-3">
              {/* Product 1 */}
              <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                  <a href="#">
                    <img
                      className="rounded-t-lg mb-5"
                      src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
                      alt="product image"
                    />
                  </a>
                  <div className="px-5 pb-5">
                    <a href="#">
                      <h5 className="text-xl font-bold tracking-tight text-gray-900">
                        Toyota Car
                      </h5>
                    </a>
                    <div className="flex items-center mt-2.5 mb-3">
                      <div className="flex items-center space-x-1 rtl:space-x-reverse">
                        {/* Star Ratings */}
                        {[...Array(4)].map((_, index) => (
                          <svg
                            key={index}
                            className="w-4 h-4 text-yellow-300"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="currentColor"
                            viewBox="0 0 22 20"
                          >
                            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                          </svg>
                        ))}
                        {/* Star Rating */}
                        <svg
                          className="w-4 h-4 text-gray-200"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="currentColor"
                          viewBox="0 0 22 20"
                        >
                          <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                        </svg>
                        {/* Product Rating */}
                        <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">
                          4.0
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-gray-900">
                        ৳ 12,33,599
                      </span>
                      <a
                        href="#"
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                      >
                        Buy Now
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              {/* Product 2 */}
              <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                  <a href="#">
                    <img
                      className="rounded-t-lg mb-5"
                      src="https://i.ibb.co/MZJS125/mercedes-e-class.jpg"
                      alt="product image"
                    />
                  </a>
                  <div className="px-5 pb-5">
                    <a href="#">
                      <h5 className="text-xl font-bold tracking-tight text-gray-900">
                        Mercedes Car
                      </h5>
                    </a>
                    <div className="flex items-center mt-2.5 mb-3">
                      <div className="flex items-center space-x-1 rtl:space-x-reverse">
                        {/* Star Ratings */}
                        {[...Array(4)].map((_, index) => (
                          <svg
                            key={index}
                            className="w-4 h-4 text-yellow-300"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="currentColor"
                            viewBox="0 0 22 20"
                          >
                            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                          </svg>
                        ))}
                        {/* Star Rating */}
                        <svg
                          className="w-4 h-4 text-gray-200"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="currentColor"
                          viewBox="0 0 22 20"
                        >
                          <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                        </svg>
                        {/* Product Rating */}
                        <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">
                          4.0
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-gray-900">
                        ৳ 12,33,599
                      </span>
                      <a
                        href="#"
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                      >
                        Buy Now
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Create post or product */}
        <div className="space-y-3">
          {/* Create Post */}
          <form>
            <div className="bg-white p-5 rounded-lg w-full">
              <div className="flex gap-5 w-full">
                {/* User Avatar */}
                <img
                  src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
                  alt="User"
                  className="w-11 h-11 object-cover object-top rounded-xl hidden sm:block"
                />

                <div className="w-full">
                  <div className="flex gap-4">
                    {/* Caption Textarea */}
                    <textarea
                      className="h-auto bg-gray-100 rounded-md w-full px-4 py-1 text-gray-800 focus:outline-none"
                      placeholder="What's going on? #Hashtag.. @Mention.."
                    ></textarea>
                    {/* Create Post Button */}
                    <button className="whitespace-nowrap max-h-8 hidden sm:block bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md">
                      Create Post
                    </button>
                    {/* Create Post Icon Button */}
                    <button className="whitespace-nowrap max-h-16 sm:hidden bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4  rounded-md">
                      <img src="createPostIcon_source_here" alt="" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap justify-center gap-3">
                {/* Upload Image */}
                <div>
                  <label htmlFor="fileInputAvatar" className="cursor-pointer">
                    <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                      <img className="w-5" src={uploadImage} alt="" />
                      <span className="hidden sm:block">Upload Images</span>
                    </div>
                  </label>
                  <input
                    type="file"
                    id="fileInputAvatar"
                    accept="image/*"
                    className="opacity-0 hidden"
                  />
                </div>
                {/* Upload Product Image */}
                <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                  <img src={uploadImage} className="h-5" alt="" />
                  <span className="hidden sm:block">Upload Product Image</span>
                </div>

                {/* Upload Video */}
                <div>
                  <label htmlFor="fileInputCover" className="cursor-pointer">
                    <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                      <img
                        className="w-5"
                        src="uploadVideo_source_here"
                        alt=""
                      />
                      <span className="hidden sm:block">Upload Videos</span>
                      <input
                        type="file"
                        id="fileInputCover"
                        accept="video/*"
                        className="opacity-0 hidden"
                      />
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </form>
          {/* Normal post */}
          <div className="bg-white p-5 rounded-lg w-full">
            <div className="flex justify-between">
              <div className="flex gap-4 w-full items-center my-4">
                {/* Profile */}
                <img
                  src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
                  alt="User"
                  className=" w-12 h-12 md:w-16 md:h-16 object-cover object-top rounded-md shadow-lg bg-black"
                />
                <div>
                  <h1 className="text-gray-700 flex items-center gap-2 flex-wrap">
                    <h1 className="font-medium text-black text-lg">Car Hut </h1>
                    uploaded new photo
                  </h1>
                  <p className="text-gray-400">1 day ago</p>
                </div>
              </div>

              <img
                src={commentMore}
                className="w-4 h-4 cursor-pointer"
                alt=""
              />
            </div>
            <div>
              <div>
                <img
                  src="https://i.ibb.co/60y1W9w/about.jpg"
                  className="mt-6 mx-auto max-h-52 md:max-h-80 w-auto rounded-lg"
                  alt=""
                />
              </div>
              {/* post content */}
              <h1 className="py-3"></h1>
            </div>
            <hr className="mt-2" />
            <div className="mt-4 px-3 flex items-center justify-between">
              {/* Like comment share icon */}
              <div className="flex gap-2 items-center">
                {/* Like icon */}
                <svg
                  className="w-6 h-6 transition ease-in-out delay-50 hover:text-violet-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20.2694 16.265L20.9749 12.1852C21.1511 11.1662 20.3675 10.2342 19.3345 10.2342H14.1534C13.6399 10.2342 13.2489 9.77328 13.332 9.26598L13.9947 5.22142C14.1024 4.56435 14.0716 3.892 13.9044 3.24752C13.7659 2.71364 13.354 2.28495 12.8123 2.11093L12.6673 2.06435C12.3399 1.95918 11.9826 1.98365 11.6739 2.13239C11.3342 2.29611 11.0856 2.59473 10.9935 2.94989L10.5178 4.78374C10.3664 5.36723 10.1460 5.93045 9.8617 6.46262C9.44634 7.24017 8.80416 7.86246 8.13663 8.43769L6.69789 9.67749C6.29223 10.0271 6.07919 10.5506 6.12535 11.0844L6.93752 20.4771C7.01201 21.3386 7.73231 22 8.59609 22H13.2447C16.726 22 19.697 19.5744 20.2694 16.265Z"
                    fill="#8B5CF6"
                  ></path>
                  <path
                    opacity="0.5"
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M2.96767 9.48508C3.36893 9.46777 3.71261 9.76963 3.74721 10.1698L4.71881 21.4063C4.78122 22.1281 4.21268 22.7502 3.48671 22.7502C2.80289 22.7502 2.25 22.1954 2.25 21.5129V10.2344C2.25 9.83275 2.5664 9.50240 2.96767 9.48508Z"
                    fill="#8B5CF6"
                  ></path>
                </svg>
                {/* comment icon */}
                <svg
                  className="h-8 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 -0.5 25 25"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  transform="matrix(-1, 0, 0, 1, 0, 0)"
                >
                  <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                  <g
                    id="SVGRepo_tracerCarrier"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></g>
                  <g id="SVGRepo_iconCarrier">
                    {" "}
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M5.5 12C5.49988 14.613 6.95512 17.0085 9.2741 18.2127C11.5931 19.4169 14.3897 19.2292 16.527 17.726L19.5 18V12C19.5 8.13401 16.366 5 12.5 5C8.63401 5 5.5 8.13401 5.5 12Z"
                      stroke="#8B5CF6"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>{" "}
                    <path
                      d="M9.5 13.25C9.08579 13.25 8.75 13.5858 8.75 14C8.75 14.4142 9.08579 14.75 9.5 14.75V13.25ZM13.5 14.75C13.9142 14.75 14.25 14.4142 14.25 14C14.25 13.5858 13.9142 13.25 13.5 13.25V14.75ZM9.5 10.25C9.08579 10.25 8.75 10.5858 8.75 11C8.75 11.4142 9.08579 11.75 9.5 11.75V10.25ZM15.5 11.75C15.9142 11.75 16.25 11.4142 16.25 11C16.25 10.5858 15.9142 10.25 15.5 10.25V11.75ZM9.5 14.75H13.5V13.25H9.5V14.75ZM9.5 11.75H15.5V10.25H9.5V11.75Z"
                      fill="#8B5CF6"
                    ></path>{" "}
                  </g>
                </svg>
                {/* Share icon */}
                <svg
                  className="h-10 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 -0.5 25 25"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                  <g
                    id="SVGRepo_tracerCarrier"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></g>
                  <g id="SVGRepo_iconCarrier">
                    {" "}
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M14.734 15.8974L19.22 12.1374C19.3971 11.9927 19.4998 11.7761 19.4998 11.5474C19.4998 11.3187 19.3971 11.1022 19.22 10.9574L14.734 7.19743C14.4947 6.9929 14.1598 6.94275 13.8711 7.06826C13.5824 7.19377 13.3906 7.47295 13.377 7.78743V9.27043C7.079 8.17943 5.5 13.8154 5.5 16.9974C6.961 14.5734 10.747 10.1794 13.377 13.8154V15.3024C13.3888 15.6178 13.5799 15.8987 13.8689 16.0254C14.158 16.1521 14.494 16.1024 14.734 15.8974Z"
                      stroke="#8B5CF6"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>{" "}
                  </g>
                </svg>
              </div>
              <div>
                <button className="text-white px-2 md:px-6 py-2 rounded-xl bg-violet-500 flex items-center gap-1.5 font-medium transform duration-500 hover:-translate-y-1">
                  Enrich The Post
                </button>
              </div>
            </div>
          </div>
          {/* Product Post */}
          <div className="bg-white p-5 rounded-lg w-full">
            <div className="flex justify-between">
              <div className="flex gap-4 w-full items-center my-4">
                {/* Profile */}
                <img
                  src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
                  alt="User"
                  className=" w-12 h-12 md:w-16 md:h-16 object-cover object-top rounded-md shadow-lg bg-black"
                />
                <div>
                  <h1 className="text-gray-700 flex items-center gap-2 flex-wrap">
                    <h1 className="font-medium text-black text-lg">Car Hut </h1>
                    uploaded a new product
                  </h1>
                  <p className="text-gray-400">1 day ago</p>
                </div>
              </div>

              <img
                src={commentMore}
                className="w-4 h-4 cursor-pointer"
                alt=""
              />
            </div>
            {/* Product post */}
            <div>
              <div className="bg-gray-50 flex-1 p-4 rounded-lg flex justify-center">
                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                  <a href="#">
                    <img
                      className="rounded-t-lg mb-5"
                      src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
                      alt="product image"
                    />
                  </a>
                  <div className="px-5 pb-5">
                    <a href="#">
                      <h5 className="text-xl font-bold tracking-tight text-gray-900">
                        Toyota Car
                      </h5>
                    </a>
                    <div className="flex items-center mt-2.5 mb-3">
                      <div className="flex items-center space-x-1 rtl:space-x-reverse">
                        {/* Star Ratings */}
                        {[...Array(4)].map((_, index) => (
                          <svg
                            key={index}
                            className="w-4 h-4 text-yellow-300"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="currentColor"
                            viewBox="0 0 22 20"
                          >
                            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                          </svg>
                        ))}
                        {/* Star Rating */}
                        <svg
                          className="w-4 h-4 text-gray-200"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="currentColor"
                          viewBox="0 0 22 20"
                        >
                          <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                        </svg>
                        {/* Product Rating */}
                        <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">
                          4.0
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-gray-900">
                        ৳ 12,33,599
                      </span>
                      <a
                        href="#"
                        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                      >
                        Buy Now
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="mt-2" />
            <div className="mt-4 px-3 flex items-center justify-between">
              {/* Like comment share icon */}
              <div className="flex gap-2 items-center">
                {/* Like icon */}
                <svg
                  className="w-6 h-6 transition ease-in-out delay-50 hover:text-violet-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M20.2694 16.265L20.9749 12.1852C21.1511 11.1662 20.3675 10.2342 19.3345 10.2342H14.1534C13.6399 10.2342 13.2489 9.77328 13.332 9.26598L13.9947 5.22142C14.1024 4.56435 14.0716 3.892 13.9044 3.24752C13.7659 2.71364 13.354 2.28495 12.8123 2.11093L12.6673 2.06435C12.3399 1.95918 11.9826 1.98365 11.6739 2.13239C11.3342 2.29611 11.0856 2.59473 10.9935 2.94989L10.5178 4.78374C10.3664 5.36723 10.1460 5.93045 9.8617 6.46262C9.44634 7.24017 8.80416 7.86246 8.13663 8.43769L6.69789 9.67749C6.29223 10.0271 6.07919 10.5506 6.12535 11.0844L6.93752 20.4771C7.01201 21.3386 7.73231 22 8.59609 22H13.2447C16.726 22 19.697 19.5744 20.2694 16.265Z"
                    fill="#8B5CF6"
                  ></path>
                  <path
                    opacity="0.5"
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M2.96767 9.48508C3.36893 9.46777 3.71261 9.76963 3.74721 10.1698L4.71881 21.4063C4.78122 22.1281 4.21268 22.7502 3.48671 22.7502C2.80289 22.7502 2.25 22.1954 2.25 21.5129V10.2344C2.25 9.83275 2.5664 9.50240 2.96767 9.48508Z"
                    fill="#8B5CF6"
                  ></path>
                </svg>
                {/* comment icon */}
                <svg
                  className="h-8 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 -0.5 25 25"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  transform="matrix(-1, 0, 0, 1, 0, 0)"
                >
                  <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                  <g
                    id="SVGRepo_tracerCarrier"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></g>
                  <g id="SVGRepo_iconCarrier">
                    {" "}
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M5.5 12C5.49988 14.613 6.95512 17.0085 9.2741 18.2127C11.5931 19.4169 14.3897 19.2292 16.527 17.726L19.5 18V12C19.5 8.13401 16.366 5 12.5 5C8.63401 5 5.5 8.13401 5.5 12Z"
                      stroke="#8B5CF6"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>{" "}
                    <path
                      d="M9.5 13.25C9.08579 13.25 8.75 13.5858 8.75 14C8.75 14.4142 9.08579 14.75 9.5 14.75V13.25ZM13.5 14.75C13.9142 14.75 14.25 14.4142 14.25 14C14.25 13.5858 13.9142 13.25 13.5 13.25V14.75ZM9.5 10.25C9.08579 10.25 8.75 10.5858 8.75 11C8.75 11.4142 9.08579 11.75 9.5 11.75V10.25ZM15.5 11.75C15.9142 11.75 16.25 11.4142 16.25 11C16.25 10.5858 15.9142 10.25 15.5 10.25V11.75ZM9.5 14.75H13.5V13.25H9.5V14.75ZM9.5 11.75H15.5V10.25H9.5V11.75Z"
                      fill="#8B5CF6"
                    ></path>{" "}
                  </g>
                </svg>
                {/* Share icon */}
                <svg
                  className="h-10 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                  viewBox="0 -0.5 25 25"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                  <g
                    id="SVGRepo_tracerCarrier"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></g>
                  <g id="SVGRepo_iconCarrier">
                    {" "}
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M14.734 15.8974L19.22 12.1374C19.3971 11.9927 19.4998 11.7761 19.4998 11.5474C19.4998 11.3187 19.3971 11.1022 19.22 10.9574L14.734 7.19743C14.4947 6.9929 14.1598 6.94275 13.8711 7.06826C13.5824 7.19377 13.3906 7.47295 13.377 7.78743V9.27043C7.079 8.17943 5.5 13.8154 5.5 16.9974C6.961 14.5734 10.747 10.1794 13.377 13.8154V15.3024C13.3888 15.6178 13.5799 15.8987 13.8689 16.0254C14.158 16.1521 14.494 16.1024 14.734 15.8974Z"
                      stroke="#8B5CF6"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>{" "}
                  </g>
                </svg>
              </div>
              <div>
                <button className="text-white px-2 md:px-6 py-2 rounded-xl bg-violet-500 flex items-center gap-1.5 font-medium transform duration-500 hover:-translate-y-1">
                  Enrich The Post
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Canvas;
