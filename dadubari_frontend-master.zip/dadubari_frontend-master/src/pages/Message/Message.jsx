import UserSide from '../../components/MessageSection/UserSide';
import SendMessage from '../../components/MessageSection/SendMessage';

const Message = () => {

    return (
        <div className='container mx-auto grid grid-cols-4 space-x-3 px-3 my-3 min-h-[80vh]'>
            <UserSide />
            <SendMessage />
        </div>
    );
};

export default Message;