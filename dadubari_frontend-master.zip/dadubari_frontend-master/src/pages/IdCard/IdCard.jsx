import { useState } from "react";

const IdCard = () => {
  const [currentCardIndex, setCurrentCardIndex] = useState(2); // Initial index of the displayed card
  const [imageUrl, setImageUrl] = useState(""); // State to store the image URL
  const [cardImages, setCardImages] = useState([
    "https://i.ibb.co/BN12Jg7/klipartz-com.png",
    "https://i.ibb.co/4jKsB6Q/card1.png",
    "https://i.ibb.co/4st78Cm/18305452-115-business-card.png",
    "https://i.ibb.co/rmGGNpg/klipartz1.png",
    "https://i.ibb.co/9rf4zDt/card2.png",
  ]);

  const totalCardCount = cardImages.length;

  const prevCard = () => {
    setCurrentCardIndex((prevIndex) =>
      prevIndex === 0 ? cardImages.length - 1 : prevIndex - 1
    );
  };

  const nextCard = () => {
    setCurrentCardIndex((prevIndex) =>
      prevIndex === cardImages.length - 1 ? 0 : prevIndex + 1
    );
  };

  const handleImageUpload = (event) => {
    const uploadedImageUrl = URL.createObjectURL(event.target.files[0]);
    setImageUrl(uploadedImageUrl);

    // Add the new image to the cardImages array
    setCardImages([...cardImages, uploadedImageUrl]);

    // Set the index to the newly added card
    setCurrentCardIndex(cardImages.length);
  };

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = cardImages[currentCardIndex];
    link.download = `image${currentCardIndex + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="container mx-auto flex flex-col space-x-3 px-3 my-3 min-h-screen space-y-5">
      <div className="flex gap-40">
        <div className="flex gap-4 bg-white rounded-lg p-3 flex-1">
          <input
            type="text"
            className="h-10 bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Search by Name"
          />
          <button
            type="submit"
            className="whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md"
          >
            {" "}
            Search
          </button>
        </div>
        <div className="flex gap-3">
          <div>
            <p className="font-bold text-xl text-center text-indigo-500 border border-indigo-500 px-6 py-2 rounded-md">
              {totalCardCount}/20
            </p>
            <p className="text-red-500 text xl ">Make it Premium</p>
          </div>
        </div>
      </div>

      <div className="w-[500px] bg-white !mx-auto rounded-lg p-5 space-y-5">
        <img
          src={imageUrl || cardImages[currentCardIndex]}
          className="h-[250px] mx-auto rounded-md shadow-lg"
          alt=""
        />
        <div className="flex gap-3 items-center justify-center">
          <button
            className="bg-purple-500 text-white text-xl font-medium py-2 px-6 rounded-md"
            onClick={handleDownload}
          >
            Download
          </button>
          <button className="bg-purple-500 text-white text-xl font-medium py-2 px-6 rounded-md">
            Share
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <img
          src="https://i.ibb.co/JFvCfnG/left-arrow.png"
          onClick={prevCard}
          className="cursor-pointer h-16 bg-white py-5 px-2 rounded-lg"
          alt="Previous"
        />
        <div className="bg-white mx-auto rounded-lg p-5 grid grid-cols-5 gap-5 overflow-hidden">
          {cardImages.map((image, index) => (
            <img
              key={index}
              src={image}
              className={`w-[300px] h-[120px] mx-auto rounded-md shadow-lg ${
                index === currentCardIndex ? "border-4 border-purple-500" : ""
              }`}
              alt=""
            />
          ))}
        </div>
        <img
          src="https://i.ibb.co/wy0SNyj/right-arrow.png"
          onClick={nextCard}
          className="cursor-pointer h-16 bg-white py-5 px-2 rounded-lg"
          alt="Next"
        />
      </div>

      <div className="flex justify-center">
        <label
          htmlFor="file-upload"
          className="bg-indigo-500 text-white text-xl font-medium py-2 px-6 rounded-md cursor-pointer"
        >
          Add Card
        </label>
        <input
          id="file-upload"
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={handleImageUpload}
        />
      </div>
    </div>
  );
};

export default IdCard;
