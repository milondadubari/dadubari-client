import { Link, useNavigate, useParams } from "react-router-dom";
import UserAbout from "../../components/UserProfile/UserSinglePageInfo/UserAbout";
import UserEducation from "../../components/UserProfile/UserSinglePageInfo/UserEducation";
import UserInterests from "../../components/UserProfile/UserSinglePageInfo/UserInterests";
import UserPreferences from "../../components/UserProfile/UserSinglePageInfo/UserPreferences";
import UserSocialConnection from "../../components/UserProfile/UserSinglePageInfo/UserSocialConnection";
import UserWorkDetails from "../../components/UserProfile/UserSinglePageInfo/UserWorkDetails";
import useGetWithParam from "../../hooks/useGetWithParam";
import NormalPost from "../../components/Post/NormalPost/NormalPost";
import { useSelector } from "react-redux";
import { useContext, useEffect, useState } from "react";
import { aboutContext } from "../../context/AboutContext";
import axiosInstance from "../../services";
import { authorization } from "../../utils/authorization";
import { ChatState } from "../../context/ChatContext";
import { toast } from "react-toastify";
import { toastDesign } from "../../Reducers/userReducers/userSlice";

const UserProfile = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const userId = useSelector((states) => states?.users?.data?._id);
  if (id === userId) {
    navigate("/profile");
  }

  const [isFollow, setIsFollow] = useState(false);
  const [isAddFriend, setIsAddFriend] = useState(false);
  
  const { setAbout } = useContext(aboutContext);
  const {setChatDetails} = ChatState();

  const data = useGetWithParam(`/api/v1/user/profile/${id}`);
  setAbout(data);

  const followAndUnfollow = async () => {
    try {
      const res = await axiosInstance.get(
        `api/v1/follow-unfollow/${id}`,
        authorization
      );
      if (res) {
        setIsFollow((prev) => !prev);
        toast.success(res?.data?.message, toastDesign);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const accessMessage = async (id) => {
    try {
      const res = await axiosInstance.post(
        `/api/v3/access-chat/${id}`,
        {},
        authorization
      );
      setChatDetails(res?.data?.chat)
      navigate(`/message/${res?.data?.chat?._id}`);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (data?.followers?.includes(userId)) setIsFollow(true);
  }, [data?.followers, userId]);

  return (
    <div className="container my-3 mx-auto space-y-3 px-3 ">
      <div
        className="rounded-lg"
        style={{
          backgroundImage: `url(${data?.cover?.url})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="h-2/5 pt-40 pb-5 px-5 flex justify-between">
          <div className="flex flex-col md:flex-row gap-2 items-start md:items-center md:gap-6">
            <img
              src={data?.avatar?.url}
              className="rounded-xl w-20 h-20 object-cover object-top md:w-32 md:h-32 "
              alt=""
            />
            <div className="space-y-1">
              <h1 className="text-xl md:text-3xl font-medium text-white">
                {data?.name}
              </h1>
              <p className="text-gray-200"> @userid55887</p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-3 justify-center md:justify-normal items-end">
            <button
              onClick={() => setIsAddFriend((prev) => !prev)}
              className="bg-purple-600 py-2 px-4 rounded-md"
            >
              <h1 className="text-white">
                {isAddFriend ? "Cancel Request" : "Add Friend"}
              </h1>
            </button>
            <button
              onClick={followAndUnfollow}
              className="bg-purple-600 py-2 px-4 rounded-md"
            >
              <h1 className="text-white">{isFollow ? "Unfollow" : "Follow"}</h1>
            </button>

            <button
              onClick={() => accessMessage(data?._id)}
              className="bg-purple-600 py-2 px-4 rounded-md"
            >
              <h1 className="text-white">Message</h1>
            </button>
          </div>
        </div>
      </div>
      <div className="rounded-lg hidden lg:flex justify-center gap-3">
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          <Link to="/about">About</Link>
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Work & Profession
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Education
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Interests & Hobbies{" "}
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Personal Preferences{" "}
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Social Connections{" "}
        </button>
      </div>
      <div className="grid grid-cols-1  lg:grid-cols-2 gap-3">
        <div className="space-y-3 row-start-2 lg:row-auto">
          {data?.posts &&
            data?.posts.map((post) => (
              <NormalPost key={post?._id} data={post} />
            ))}
        </div>
        <div className="space-y-3">
          <UserAbout data={data} />
          <UserWorkDetails data={data} />
          <UserEducation data={data} />
          <UserInterests data={data} />
          <UserPreferences data={data} />
          <UserSocialConnection data={data} />
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
