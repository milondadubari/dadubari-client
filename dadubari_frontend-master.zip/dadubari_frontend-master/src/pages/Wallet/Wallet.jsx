
const Wallet = () => {
    return (
        <div className="container mx-auto space-y-3 px-3 my-3 min-h-screen">
            {/* wallet start from here */}
            {/* wallet id */}
            <div className='bg-white rounded-lg p-3 space-y-2 '>
                <div className='flex items-top justify-between'>
                    <div className=' text-xl p-3 space-y-1'>
                        <img src="https://i.ibb.co/ZWJy49G/qrc.jpg" className='h-20 mb-4 ml-16' alt="" />
                        <h1 className='font-medium'>User ID : <span className='text-violet-500'>WID49875123</span></h1>
                        <h3 className='font-semibold'>User Name : Mozahar</h3>
                        <h3 className='font-semibold'>User Email : mozahar@gmail.com</h3>
                    </div>
                    <div className='pr-3'>
                        <div className='text-center shadow-md rounded-md p-5 space-y-1'>
                            <h3 className='font-bold'>Remaining Balance</h3>
                            <h1 className='font-bold text-2xl text-indigo-500'>3584.00 BDT</h1>
                            <h2 className='font-semibold '>Expired in : 31 December 2025</h2>
                        </div>
                        <div className='space-x-3 my-5 flex justify-between'>
                            <button className='p-4 bg-violet-500 rounded-md text-white font-medium transform duration-500 hover:-translate-y-1'>Add Money</button>
                            <button className='p-4 bg-indigo-500 rounded-md text-white font-medium transform duration-500 hover:-translate-y-1'>Send Money</button>
                            <button className='p-4 bg-purple-500 rounded-md text-white font-medium transform duration-500 hover:-translate-y-1'>Withdraw Money</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className='bg-white rounded-lg p-3 spacey-2'>
                {/* Transition  */}
                <table className='w-full border border-solid text-center divide-y rounded-lg'>
                    <tr className='divide-x text-lg'>
                        <th className='p-5'>Date</th>
                        <th className='p-5' colSpan={2}>Description</th>
                        <th className='p-5'>Amount</th>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>01 Nov 2023</td>
                        <td className='p-2' colSpan={2}> Dabit to Dadubari payment to boost smart BD</td>
                        <td className='p-2'>2000 + 20(vat) BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>26 Oct 2023</td>
                        <td className='p-2' colSpan={2}>Send money Nahid</td>
                        <td className='p-2'>2500 + 25(vat) BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>20 Oct 2023</td>
                        <td className='p-2' colSpan={2}>Withdraw BK-P 071278 0000</td>
                        <td className='p-2'>1190+10(vat) BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>19 Oct 2023</td>
                        <td className='p-2' colSpan={2}>Credit from Dadubari jobs data entry</td>
                        <td className='p-2'>1200 BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>05 Sep 2023</td>
                        <td className='p-2' colSpan={2}>Dabit to Dadubari Jobs *</td>
                        <td className='p-2'>50 + 0.5(vat) BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>03 Aug 2023</td>
                        <td className='p-2' colSpan={2}>Dabit to yellow mart</td>
                        <td className='p-2'>200 + 20(vat) BDT</td>
                    </tr>
                    <tr className='divide-x'>
                        <td className='p-2'>02 Aug 2023</td>
                        <td className='p-2' colSpan={2}>Credit from Bkash</td>
                        <td className='p-2'>10,000 BDT</td>
                    </tr>
                    
                </table>
            </div>
        </div>
    );
};

export default Wallet;