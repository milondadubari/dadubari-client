import { useState } from "react"
import axiosInstance from "../../../services";
import { authorization } from "../../../utils/authorization";
import { toast } from "react-toastify";
import { toastDesign } from "../../../Reducers/userReducers/userSlice";
import { useNavigate } from "react-router-dom";

const CorporateLogin = () => {
  const [data,setData] = useState({});
  const navigate = useNavigate();

  const handleChange=(e)=>{
    const {value, name} = e.target;
    setData({...data , [name] : value});
  }
  const handleSubmit =async(e)=>{
    e.preventDefault();

    if(!data.organizationEmail.trim().length === 0){
      toast.error("Fill organization email", toastDesign);
      return;
    }
    if(!data.password.trim().length === 0){
      toast.error("Fill organization password", toastDesign);
      return;
    }
    try {
      const res = await axiosInstance.post("/api/v4/corporate/profile/enter", data, authorization);
      if(res.status===200){
        if(res?.data?.content?.data?.corporateProfile?._id){
          navigate(`/corporate/my/profile/${res?.data?.content?.data?.corporateProfile?._id}`);
          localStorage.setItem("corporateToken",res?.data?.content?.data?.token)
          toast.success("Corporate login successful", toastDesign);
        }
      }
    } catch (error) {
      toast.error(error?.response?.data?.message, toastDesign);
    }
  }
  return (
    <form onSubmit={handleSubmit}>
    <div className="min-h-[100vh] flex items-center">
      <div className="container w-1/2 m-12 mx-auto shadow-xl rounded-2xl bg-white p-8 space-y-5">
        <h1 className="text-4xl font-bold border-b-4 text-center w-80 mx-auto pb-2 mb-10 border-black leading-[50px]">
          Enter Your Corporate Profile
        </h1>
        {/* Organization Name */}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Organization Email :
          </label>
          <input
            type="email"
            name="organizationEmail"
            value={data["organizationEmail"] || "" }
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your Organization name here"
            required
          />
        </div>
          <div className="flex items-center justify-center gap-3">
            <label className="font-medium text-lg whitespace-nowrap">
              Password :
            </label>
            <input
              type="password"
              name="password"
              value={data["password"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Favorite Color"
              required
            />
          </div>
        <div className="flex-1">
          <button type="submit" className="text-white border p-2 rounded-md transition ease-in-out delay-50  bg-indigo-500 border-indigo-500 transform duration-500 hover:-translate-y-1 text-xl">
            Submit
          </button>
        </div>
      </div>
    </div>
    </form>
  )
}

export default CorporateLogin