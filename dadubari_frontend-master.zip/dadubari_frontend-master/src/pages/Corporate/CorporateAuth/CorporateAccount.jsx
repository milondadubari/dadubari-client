import { Link } from 'react-router-dom';

const CorporateAccount = () => {
    return (
        <div>
            <div className="min-h-[100vh] flex items-center">
                <div className="container w-1/2 m-12 mx-auto shadow-xl rounded-2xl bg-white p-8 space-y-5">
                    <h1 className="text-4xl font-bold border-b-4 text-center w-96 mx-auto pb-2 border-black leading-[50px]">
                        Welcome To Corporate Account
                    </h1>
                    <p className='text-center'>Lorem ipsum dolor sit amet consectetur adipisicing elit. In incidunt quae culpa perspiciatis veritatis tenetur, molestias quis velit possimus exercitationem voluptas! Animi, similique laborum doloribus expedita voluptate nihil corporis excepturi esse. Corrupti sit accusamus ratione qui consectetur, sed fuga numquam.</p>
                    <div className='flex justify-center gap-5 items-center'>
                        <Link to={'/corporate/register'}>
                        < button className="text-white border p-4 rounded-md transition ease-in-out delay-50  bg-indigo-500 border-indigo-500 transform duration-500 hover:-translate-y-1 text-xl">
                            Apply For A Corporate Account
                        </button>
                        </Link>
                        <Link to={'/corporate/login'}>
                        <button className="text-white border p-4 rounded-md transition ease-in-out delay-50 bg-violet-500 border-indigo-500 transform duration-500 hover:-translate-y-1 text-xl">
                            Enter Your Corporate Account
                        </button>
                        </Link>
                        <Link to={'/corporate/my-corporate-accounts'}>
                        <button className="text-white border p-4 rounded-md transition ease-in-out delay-50 bg-purple-500 border-indigo-500 transform duration-500 hover:-translate-y-1 text-xl">
                            All Corporate Account
                        </button>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CorporateAccount;