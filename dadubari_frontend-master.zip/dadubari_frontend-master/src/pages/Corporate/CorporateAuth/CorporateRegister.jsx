import uploadImage from "../../../icons/svg/uploadImage.svg";
import { useState } from "react";
import axiosInstance from "../../../services";
import { toast } from "react-toastify";
import { toastDesign } from "../../../Reducers/userReducers/userSlice";
import { useNavigate } from "react-router-dom";
import { authorization } from "../../../utils/authorization";

const CorporateRegister = () => {
  const [data , setData] = useState({});
  const [companyCoverPhoto , setCompanyCoverPhoto] = useState("");
  const [companyLogo, setCompanyLogo] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { value, name } = e.target;
    setData({ ...data, [name]: value });
  };

  const handleCoverChange = (e) => {
    const file = e.target.files[0];

    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        setCompanyCoverPhoto(Reader.result);
      }
    };
  };
  const handleImageChange = (e) => {
    const file = e.target.files[0];

    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        console.log(Reader.result);
        setCompanyLogo(Reader.result);
      }
    };
  };

  const handleSubmit=async(e)=>{
    e.preventDefault();
    if(!data.organizationName.trim().length === 0){
      toast.error("Fill organization name", toastDesign);
      return;
    }
    if(!data.organizationEmail.trim().length === 0){
      toast.error("Fill organization email", toastDesign);
      return;
    }
    if(!data.password.trim().length === 0){
      toast.error("Fill organization password", toastDesign);
      return;
    }
    try {
      const res = await axiosInstance.post("/api/v4/corporate/register", {...data, companyCoverPhoto , companyLogo}, authorization);
      if(res.status===200){
        toast.success("Corporate registration successful", toastDesign);
        navigate("/corporate/login");
        return;
      }
    } catch (error) {
      toast.error(error?.response?.data?.message, toastDesign);
      return;
    }
  }
  return (
    <div className="min-h-[100vh]">
     <form onSubmit={handleSubmit}>
      <div className="container md:w-5/6 m-12 mx-auto shadow-xl rounded-2xl bg-white p-8 space-y-5">
        <h1 className="text-4xl font-bold border-b-4 text-center w-96 mx-auto pb-2 mb-10 border-black leading-[50px]">
          Apply To Register A Corporate Profile
        </h1>

        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Organization Name :
          </label>
          <input
            type="text"
            name="organizationName"
            value={data["organizationName"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your Organization name here"
            required
          />
        </div>
        <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Password :
            </label>
            <input
              type="password"
              name="password"
              value={data["password"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Organization password"
              required
            />
          </div>
        <div className="flex flex-wrap items-center gap-3 w-full">
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Email :
            </label>
            <input
              type="email"
              name="organizationEmail"
              value={data["organizationEmail"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Organization Email"
              required
            />
          </div>
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Phone Number :
            </label>
            <input
              type="number"
              name="phoneNumber"
              value={data["phoneNumber"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Organization Phone Number"
              required
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full">
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Website :
            </label>
            <input
              type="text"
              name="website"
              value={data["website"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Organization Website"
              required
            />
          </div>
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Type :
            </label>
            <select
              name="type"
              value={data["type"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            >
              <option value="">Organization</option>
              <option value="Government">Government</option>
              <option value="Semi Government">Semi Government</option>
              <option value="Non Government">Non Government</option>
              <option value="Hotel">Hotel</option>
              <option value="Restaurant">Restaurant</option>
              <option value="Bank">Bank</option>
              <option value="IT Company">IT Company</option>
              <option value="Others">Others</option>
            </select>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full">
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Size :
            </label>
            <input
              type="text"
              name="size"
              value={data["size"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Organization Size here (People)"
              required
            />
          </div>
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Country :
            </label>
            <select
              name="OrganizationType"
              value={data["OrganizationType"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            >
              <option value="">Organization</option>
              <option value="Afghanistan">Afghanistan 🇦🇫</option>
              <option value="Armenia">Armenia 🇦🇲</option>
              <option value="Azerbaijan">Azerbaijan 🇦🇿</option>
              <option value="Bahrain">Bahrain 🇧🇭</option>
              <option value="Bangladesh">Bangladesh 🇧🇩</option>
              <option value="Bhutan">Bhutan 🇧🇹</option>
              <option value="Brunei">Brunei 🇧🇳</option>
              <option value="Cambodia">Cambodia 🇰🇭</option>
              <option value="China">China 🇨🇳</option>
              <option value="Cyprus">Cyprus 🇨🇾</option>
              <option value="Georgia">Georgia 🇬🇪</option>
              <option value="India">India 🇮🇳</option>
              <option value="Indonesia">Indonesia 🇮🇩</option>
              <option value="Iran">Iran 🇮🇷</option>
              <option value="Iraq">Iraq 🇮🇶</option>
              <option value="Japan">Japan 🇯🇵</option>
              <option value="Jordan">Jordan 🇯🇴</option>
              <option value="Kazakhstan">Kazakhstan 🇰🇿</option>
              <option value="Kuwait">Kuwait 🇰🇼</option>
              <option value="Kyrgyzstan">Kyrgyzstan 🇰🇬</option>
              <option value="Laos">Laos 🇱🇦</option>
              <option value="Lebanon">Lebanon 🇱🇧</option>
              <option value="Malaysia">Malaysia 🇲🇾</option>
              <option value="Maldives">Maldives 🇲🇻</option>
              <option value="Mongolia">Mongolia 🇲🇳</option>
              <option value="Myanmar">Myanmar 🇲🇲</option>
              <option value="Nepal">Nepal 🇳🇵</option>
              <option value="North Korea">North Korea 🇰🇵</option>
              <option value="Oman">Oman 🇴🇲</option>
              <option value="Pakistan">Pakistan 🇵🇰</option>
              <option value="Palestine">Palestine 🇵🇸</option>
              <option value="Philippines">Philippines 🇵🇭</option>
              <option value="Qatar">Qatar 🇶🇦</option>
              <option value="Russia">Russia 🇷🇺</option>
              <option value="Saudi Arabia">Saudi Arabia 🇸🇦</option>
              <option value="Singapore">Singapore 🇸🇬</option>
              <option value="South Korea">South Korea 🇰🇷</option>
              <option value="Sri Lanka">Sri Lanka 🇱🇰</option>
              <option value="Syria">Syria 🇸🇾</option>
              <option value="Taiwan">Taiwan 🇹🇼</option>
              <option value="Tajikistan">Tajikistan 🇹🇯</option>
              <option value="Thailand">Thailand 🇹🇭</option>
              <option value="Timor-Leste">Timor-Leste 🇹🇱</option>
              <option value="Turkey">Turkey 🇹🇷</option>
              <option value="Turkmenistan">Turkmenistan 🇹🇲</option>
              <option value="United Arab Emirates">
                United Arab Emirates 🇦🇪
              </option>
              <option value="Uzbekistan">Uzbekistan 🇺🇿</option>
              <option value="Vietnam">Vietnam 🇻🇳</option>
              <option value="Yemen">Yemen 🇾🇪</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Address :
          </label>
          <input
            type="text"
            name="address"
            value={data["address"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your Organization Address"
            required
          />
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full">
          <div className="flex flex-wrap items-center gap-3">
            <label
              htmlFor="fileInputCompanyLogo"
              className="font-medium text-lg whitespace-nowrap"
            >
              Company Logo :
            </label>
            <label htmlFor="fileInputCompanyLogo" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadImage} alt="" /> Upload Your
                Company Logo
              </div>
            </label>
            <input
              type="file"
              id="fileInputCompanyLogo"
              accept="image/*"
              onChange={handleImageChange}
              className="opacity-0 hidden"
            />
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <label
              htmlFor="fileInputCompanyCover"
              className="font-medium text-lg whitespace-nowrap"
            >
              Company Cover Photo :
            </label>
            <label htmlFor="fileInputCompanyCover" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadImage} alt="" /> Upload Your
                Company Cover Photo
              </div>
            </label>
            <input
              type="file"
              id="fileInputCompanyCover"
              accept="image/*"
              onChange={handleCoverChange}
              className="opacity-0 hidden"
            />
          </div>
        </div>

        <div className="flex justify-center items-center">
          <button type="submit" className=" text-white border p-2 rounded-md transition ease-in-out delay-50  bg-indigo-500 border-indigo-500 transform duration-500 hover:-translate-y-1  text-xl">
            Register
          </button>
        </div>

      </div>
      </form>
    </div>
  );
};

export default CorporateRegister;
