import { useEffect, useState } from "react";
import axiosInstance from "../../../services";
import { authorization } from "../../../utils/authorization";
import { Link } from "react-router-dom";

const AllCorporateProfile = () => {
    const [data, setData] = useState([]);
    const getAllCorporateUserAdded =async()=>{
        try {
            const res = await axiosInstance.get("/api/v4/corporate/getAllCorporateUserAdded", authorization);
            setData(res?.data?.content);
        } catch (error) {
            console.log(error)
        }
    }
    useEffect(()=>{
        getAllCorporateUserAdded();
    },[])
    return (
        <div className='min-h-[100vh] container md:w-5/6 m-12 mx-auto shadow-xl rounded-2xl bg-white p-8 space-y-5'>
            <h1 className='text-3xl font-bold border-b-4 text-center w-96 mx-auto pb-2 mb-10 border-black leading-[50px]'>All Corporate Accounts</h1>
            {/* Corporate accounts list */}
            <div className='grid grid-cols-5 text-xl font-bold shadow-lg p-4 rounded-lg'>
                <h3>Corporate Logo</h3>
                <h3>Account Name</h3>
                <h3>Position</h3>
                <h3>Role</h3>
                <h3>Actions</h3>
            </div>
            {
                data?.map((corporate)=>{
                    return (
                        <div key={corporate?._id} className='grid grid-cols-5 text-lg items-center font-bold bg-gray-50 p-4 rounded-lg'>
                            <img className='h-20 w-20 rounded-sm object-cover' src={corporate?.corporate?.companyLogo?.url} alt="" />
                                <h3 className='font-medium'>{corporate?.corporate?.organizationName}</h3>
                                <h3 className='font-medium '>{corporate?.position}</h3>
                                <h3 className='font-medium '>{corporate?.role}</h3>
                            <div className='flex flex-col gap-1'>
                                <button className='bg-purple-500 text-white p-2 rounded-md'>Accept</button>
                                <Link to={`/corporate/profile/${corporate?.corporate?._id}`} className='bg-violet-500 text-white text-center p-2 rounded-md'>Visit</Link>
                                <button className='bg-indigo-500 text-white p-2 rounded-md'>Leave</button>
                            </div>
                        </div>
                        )
                    }) 
            }
        </div>
    );
};

export default AllCorporateProfile;
