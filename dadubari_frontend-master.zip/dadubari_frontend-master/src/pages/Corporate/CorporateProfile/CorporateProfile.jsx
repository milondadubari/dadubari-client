import CorporateProfileHero from '../../../components/Corporate/CorporateProfileHero';
import CorporateProfileMembers from '../../../components/Corporate/CorporateProfileMembers';
import { useParams } from 'react-router-dom';


const CorporateProfile = () => {
    const {id} = useParams();
    return (
        <div className="container my-3 mx-auto space-y-3 px-3 ">
            {/* Profile hero section */}
            <CorporateProfileHero id={id} />
            <CorporateProfileMembers page={"others"} id={id} />
           
        </div>
    );
};

export default CorporateProfile;
