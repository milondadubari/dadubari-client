import { useState } from "react";
import { useParams } from "react-router-dom";
import CorporateProfileHero from "../../../components/Corporate/CorporateProfileHero";
import CorporateProfileMembers from "../../../components/Corporate/CorporateProfileMembers";
import CorporateMemberAttendance from "../../../components/Corporate/CorporateMemberAttendance";
import CorporateProfileVisitors from "../../../components/Corporate/CorporateProfileVisitors";


const MyCorporateProfile = () => {
    const {id} = useParams();
    const [activeComponent, setActiveComponent] = useState('Members');
    const handleComponentChange = (componentName) => {
        setActiveComponent(componentName);
    };
  return (
    <div className="container my-3 mx-auto space-y-3 px-3 ">
    {/* Profile hero section */}
    <CorporateProfileHero id={id} />
    {/* corporate option */}
    <div className="rounded-lg hidden lg:flex justify-center gap-3">
        <button
            className={`text-black px-8 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1 ${
                activeComponent === 'Members' && 'bg-gray-200'
            }`}
            onClick={() => handleComponentChange('Members')}
        >
            Members
        </button>
        <button
            className={`text-black px-8 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1 ${
                activeComponent === 'Attendance' && 'bg-gray-200'
            }`}
            onClick={() => handleComponentChange('Attendance')}
        >
            Attendance
        </button>
        <button
            className={`text-black px-8 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1 ${
                activeComponent === 'Visitors' && 'bg-gray-200'
            }`}
            onClick={() => handleComponentChange('Visitors')}
        >
            Visitors
        </button>
        {/* Add more buttons for other components if needed */}
    </div>
    {/* Render the active component based on the state */}
    {activeComponent === 'Members' && <CorporateProfileMembers page={"my"} id={id} />}
    {activeComponent === 'Attendance' && <CorporateMemberAttendance />}
    {activeComponent === 'Visitors' && <CorporateProfileVisitors id={id} />}
    {/* Add rendering logic for other components if needed */}
</div>
  )
}

export default MyCorporateProfile