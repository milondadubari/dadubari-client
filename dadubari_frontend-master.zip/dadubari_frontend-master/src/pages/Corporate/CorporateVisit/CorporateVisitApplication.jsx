import { useState } from "react";
import { toast } from "react-toastify";
import axiosInstance from "../../../services";
import { authorization } from "../../../utils/authorization";
import codeScanner from "../../../icons/svg/scanQrCode.svg";
import uploadIcon from "../../../icons/svg/uploadIcon.svg"
// import QRScanner from "../../../components/QrScanner/QrScanner";


const CorporateVisitApplication = () => {
    const [data,setData] = useState({});
    const handleChange=(e)=>{
        const {name , value} = e.target;
        setData({...data, [name] : value});
    }
    const handleSubmit =async(e)=>{
        e.preventDefault();
        if(!data?.corporateAccountName || !data?.applicantName || !data?.email){
            toast.warn("fill necessary fields")
            return;
        }
        if(data?.corporateAccountName.trim().length===0 || data?.applicantName.trim().length===0 || data?.email.trim().length===0){
            toast.warn("fill necessary fields")
            return;
        }
        try {
            const res = await axiosInstance.post("api/v4/corporate/profile/visite-apply",data,authorization);
            if(res.status===200){
                toast.success("application successful");
                return;
            }
        } catch (error) {
            toast.error(error?.response?.data?.message);
            return;
        }
    }
    return (
        <div className="min-h-[100vh]">
            <form onSubmit={handleSubmit}>
            <div className="container md:w-5/6 m-12 mx-auto shadow-xl rounded-2xl bg-white p-8 space-y-5">
                <div className="flex justify-between items-center">
                    <h1 className="text-4xl font-bold border-b-4 text-center w-96 mx-auto pb-2 mb-10 border-black leading-[50px]">
                        Apply To Visit A Corporate Office
                    </h1>
                    <div className="relative mr-5 flex flex-col justify-center items-center">
                        <img
                            className=" border w-16 border-purple-500 p-3 rounded-lg cursor-pointer"
                            src={codeScanner}
                            alt="Code Scanner"
                        />
                        <p className="mt-3 font-medium">Scan A QR Code</p>
                    </div>
                    <div className="relative flex flex-col justify-center items-center">
                        <img
                            className=" border w-16 border-purple-500 p-3 rounded-lg cursor-pointer"
                            src={uploadIcon}
                            alt="Upload qr Scanner"
                        />
                        <p className="mt-3 font-medium">Upload A QR Code (jpg/png)</p>
                    </div>
                </div>

                {/* Corporate Account */}
                <div className="flex items-center gap-3 flex-1">
                    <label className="font-medium text-lg whitespace-nowrap">
                        Corporate Account Name :
                    </label>
                    <input
                        type="text"
                        name="corporateAccountName"
                        value={data["corporateAccountName" || ""]}
                        onChange={handleChange}
                        className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                        placeholder="Type the account name you want to visit"
                        required
                    />
                </div>
                {/* Applicant Name and Designation*/}
                <div className="flex flex-wrap items-center gap-3 w-full">
                    {/* Applicant Name */}

                <div className="flex items-center gap-3 flex-1">
                    <label className="font-medium text-lg whitespace-nowrap">
                        Applicant Name :
                    </label>
                    <input
                        type="text"
                        name="applicantName"
                        value={data["applicantName" || ""]}
                        onChange={handleChange}
                        className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                        placeholder="Type your name here"
                        required
                    />
                </div>
                    {/* Applicant Designation */}
                    <div className="flex items-center gap-3 flex-1">
                        <label className="font-medium text-lg whitespace-nowrap">
                            Designation :
                        </label>
                        <input
                            type="text"
                            name="designation"
                            value={data["designation" || ""]}
                            onChange={handleChange}
                            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                            placeholder="Type your Designation"
                            required
                        />
                    </div>
                </div>
                {/* Applicant email and phone number*/}
                <div className="flex flex-wrap items-center gap-3 w-full">
                    {/* Applicant email*/}
                    <div className="flex items-center gap-3 flex-1">
                        <label className="font-medium text-lg whitespace-nowrap">
                            Email :
                        </label>
                        <input
                            type="email"
                            name="email"
                            value={data["email" || ""]}
                            onChange={handleChange}
                            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                            placeholder="Type your Email"
                            required
                        />
                    </div>
                    {/* Applicant Phone Number */}
                    <div className="flex items-center gap-3 flex-1">
                        <label className="font-medium text-lg whitespace-nowrap">
                            Phone Number :
                        </label>
                        <input
                            type="text"
                            name="phoneNumber"
                            value={data["phoneNumber" || ""] }
                            onChange={handleChange}
                            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                            placeholder="Type your Phone Number"
                            required
                        />
                    </div>
                </div>
                {/*Purpose of Visiting*/}
                <div className="flex items-center gap-3 flex-1">
                        <label className="font-medium text-lg whitespace-nowrap">
                            Purpose of Visiting :
                        </label>
                        <input
                            type="text"
                            name="purposeOfVisiting"
                            value={data["purposeOfVisiting" || "" ]}
                            onChange={handleChange}
                            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                            placeholder="Type Purpose of Visiting"
                            required
                        />
                </div>

                    {/* Description */}
                <div className="flex items-top gap-3 flex-1">
                        <label className="font-medium text-lg whitespace-nowrap">
                            Description :
                        </label>
                        <textarea name="description" value={data["description" || ""]} onChange={handleChange} id="message" rows="4" className="block p-2.5 w-full min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none" placeholder="Type here your visit description" required></textarea>
                </div>
                {/* Description */}
                {/* Description */}
                <div className="flex items-top gap-3 flex-1">
                    <label className="font-medium text-lg whitespace-nowrap">
                        Description :
                    </label>
                    <textarea id="message" rows="4" className="block p-2.5 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none" placeholder="Type here your visit description" required></textarea>
                </div>
                {/* Submit Button */}
                <div className="flex justify-center items-center">
                    < button type="sumbit" className=" text-white border p-2 rounded-md transition ease-in-out delay-50  bg-indigo-500 border-indigo-500 transform duration-500 hover:-translate-y-1  text-xl">
                            Apply To Visit
                    </button>
                </div>
            </div>
            </form>
        </div>
    );
};

export default CorporateVisitApplication;