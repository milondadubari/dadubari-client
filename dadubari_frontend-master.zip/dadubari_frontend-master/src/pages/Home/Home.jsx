import LeftSidebar from '../../components/Sidebar/LeftSidebar/LeftSidebar';
import RightSIdebar from './../../components/Sidebar/RightSidebar/RightSIdebar';
import CenterSidebar from '../../components/Sidebar/CenterSidebar/CenterSidebar';
const Home = () => {
  return (
    <div className="container mx-auto grid grid-cols-12 space-x-0 md:space-x-3 md:px-3 my-3 min-h-screen">
      {/* This is left sidebar */}
      <div className="sticky top-[90px]  h-[80vh] overflow-y-scroll scroll left-0 z-10 col-span-4 lg:col-span-2 rounded-lg hidden md:block">
        <LeftSidebar></LeftSidebar>
      </div>
      {/* This is center area */}
      <div className="col-span-12 md:col-span-8 lg:col-span-7 rounded-lg">
        <CenterSidebar></CenterSidebar>
      </div>
      {/* This is right sidebar */}
      <div className="col-span-3 rounded-lg hidden lg:block">
        <RightSIdebar></RightSIdebar>
      </div>
    </div>
  );
};

export default Home;
