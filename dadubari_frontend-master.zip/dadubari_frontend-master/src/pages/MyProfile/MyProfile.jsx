import UserAbout from "../../components/UserProfile/UserSinglePageInfo/UserAbout";
import UserWorkDetails from "../../components/UserProfile/UserSinglePageInfo/UserWorkDetails";
import UserEducation from "../../components/UserProfile/UserSinglePageInfo/UserEducation";
import UserInterests from "../../components/UserProfile/UserSinglePageInfo/UserInterests";
import UserPreferences from "../../components/UserProfile/UserSinglePageInfo/UserPreferences";
import UserSocialConnection from "../../components/UserProfile/UserSinglePageInfo/UserSocialConnection";
import CreatePost from "../../components/Post/CreatePost/CreatePost";
import NormalPost from "../../components/Post/NormalPost/NormalPost";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { getAllMyPosts } from "../../Reducers/postReducers/getSingleUserPostSlice";

import editProfileIcon from "../../icons/svg/editProfileIcon.svg";

const MyProfile = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAllMyPosts());
  }, [dispatch]);
  const userDetails = useSelector((da) => da?.users?.data);
  const myPosts = useSelector((da) => da?.myPosts?.data?.posts);

  return (
    <div className="container my-3 mx-auto space-y-3 px-3 ">
      {/* Profile hero section */}
      <div
        className="rounded-lg"
        style={{
          backgroundImage: `url(${userDetails?.cover?.url})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* cover photo and profile picture */}
        <div className="h-2/5 pt-40 pb-5 px-5 flex justify-between">
          {/* Profile info */}
          <div className="flex flex-col md:flex-row gap-2 items-start md:items-center md:gap-6">
            <img
              src={userDetails?.avatar?.url}
              className="rounded-xl w-20 h-20 object-cover object-top md:w-32 md:h-32 "
              alt=""
            />
            <div className="space-y-1">
              <h1 className="text-xl md:text-3xl font-medium text-white">
                {userDetails?.name}
              </h1>
              <p className="text-gray-200"> @userid55887</p>
            </div>
          </div>
          {/* Edit & Activities */}
          <div className="flex flex-col md:flex-row gap-3 justify-center md:justify-normal items-end">
            <Link to={`/edit`}>
              <button className="text-black px-2 md:px-6 py-2 rounded-xl bg-white flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
                <img src={editProfileIcon} className="h-5" alt="" />{" "}
                <span className="hidden md:block"> Edit</span>
              </button>
            </Link>
            <button className="text-black px-2 md:px-4 py-2 rounded-xl bg-white flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
              <svg
                className="h-5"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                <g
                  id="SVGRepo_tracerCarrier"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></g>
                <g id="SVGRepo_iconCarrier">
                  {" "}
                  <path
                    d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z"
                    stroke="#8B5CF6"
                    strokeWidth="1.5"
                  ></path>{" "}
                  <path
                    d="M6 15.8L7.14286 17L10 14"
                    stroke="#8B5CF6"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>{" "}
                  <path
                    d="M6 8.8L7.14286 10L10 7"
                    stroke="#8B5CF6"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>{" "}
                  <path
                    d="M13 9L18 9"
                    stroke="#8B5CF6"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  ></path>{" "}
                  <path
                    d="M13 16L18 16"
                    stroke="#8B5CF6"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  ></path>{" "}
                </g>
              </svg>{" "}
              <span className="hidden md:block">Activities</span> 
            </button>
          </div>
        </div>
        {/* Profile details */}
      </div>
      {/* Profile hero section end */}
      <div className="rounded-lg hidden lg:flex justify-center gap-3">
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          About
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Work & Profession
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Education
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Interests & Hobbies{" "}
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Personal Preferences{" "}
        </button>
        <button className="text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1">
          Social Connections{" "}
        </button>
        {/* <button className='text-black px-4 py-2 rounded-lg bg-white hover:bg-gray-200 flex items-center gap-1 font-medium transform duration-500 hover:-translate-y-1'>Additional Details </button> */}
      </div>
      {/* Users profile post and about part */}
      <div className="grid grid-cols-1  lg:grid-cols-2 gap-3">
        {/* Personal post */}
        <div className="space-y-3 row-start-2 lg:row-auto">
          <CreatePost></CreatePost>
          {myPosts &&
            myPosts?.map((post) => <NormalPost key={post?._id} data={post} />)}
        </div>
        {/* User data */}
        <div className="space-y-3">
          <UserAbout data={userDetails}/>
          <UserWorkDetails data={userDetails} />
          <UserEducation data={userDetails}/>
          <UserInterests data={userDetails}/>
          <UserPreferences data={userDetails}/>
          <UserSocialConnection data={userDetails}/>
        </div>
      </div>
    </div>
  );
};

export default MyProfile;
