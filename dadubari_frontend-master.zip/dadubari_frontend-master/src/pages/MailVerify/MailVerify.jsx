import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom"
import { userEmailVerification } from "../../Reducers/userReducers/userSlice";

const MailVerify = () => {
    const {id , token} = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    useEffect(()=>{
        dispatch(userEmailVerification({id,token}));
        navigate("/login");
    },[id,token,dispatch,navigate])
  return (
    <div></div>
  )
}

export default MailVerify