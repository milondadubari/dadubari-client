
const ShoppingPage = () => {
    return (
        <div className='container mx-auto space-x-3 px-3 my-3 min-h-screen'>
            <div className="space-y-2">
                <div className="space-y-3">
                    <div className="flex flex-wrap gap-4 bg-white rounded-lg p-3">
                        <input
                            type="text"
                            className="h-10 bg-gray-100 rounded-md flex-1 px-4 text-gray-800 focus:outline-none"
                            placeholder="Search by keyword"
                        />
                        <select className="h-10 min-w-[200px] bg-gray-100 rounded-md px-4 text-gray-800 focus:outline-none">
                            <option value="">Filter No.1 </option>
                            <option value="Item 1">Item 1</option>
                            <option value="Item 2">Item 2</option>
                            <option value="Item 3">
                               Item 3
                            </option>
                        </select>
                        <select className="h-10 min-w-[200px] bg-gray-100 rounded-md px-4 text-gray-800 focus:outline-none">
                            <option value="">Filter No.2 </option>
                            <option value="Item 1">Item 1</option>
                            <option value="Item 2">Item 2</option>
                            <option value="Item 3">
                               Item 3
                            </option>
                        </select>
                        <select className="h-10 min-w-[200px] bg-gray-100 rounded-md px-4 text-gray-800 focus:outline-none">
                            <option value="">Filter No.3 </option>
                            <option value="Item 1">Item 1</option>
                            <option value="Item 2">Item 2</option>
                            <option value="Item 3">
                               Item 3
                            </option>
                        </select>
                        <button
                            type="submit"
                            className="whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md"
                        >
                            {" "}
                            Search
                        </button>
                    </div>
                    <div className="bg-white rounded-lg p-3 space-y-3">
                        <h1 className="text-2xl font-bold">Shop Item</h1>
                        <div className='flex flex-wrap gap-3 justify-between'>
                            {/* Card 1 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 2 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 3 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 4 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div className='flex flex-wrap gap-3 justify-between'>
                            {/* Card 1 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 2 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 3 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* Card 4 */}
                            <div className="bg-gray-50 flex-1 p-4 rounded-lg">
                                <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                                    <a href="#">
                                        <img className="rounded-t-lg mb-5" src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg" alt="product image" />
                                    </a>
                                    <div className="px-5 pb-5">
                                        <a href="#">
                                            <h5 className="text-xl font-bold tracking-tight text-gray-900">Toyota Car</h5>
                                        </a>
                                        <div className="flex items-center mt-2.5 mb-3">
                                            <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                                {/* Star Ratings */}
                                                {[...Array(4)].map((_, index) => (
                                                    <svg
                                                        key={index}
                                                        className="w-4 h-4 text-yellow-300"
                                                        aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        fill="currentColor"
                                                        viewBox="0 0 22 20"
                                                    >
                                                        <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                    </svg>
                                                ))}
                                                {/* Star Rating */}
                                                <svg
                                                    className="w-4 h-4 text-gray-200"
                                                    aria-hidden="true"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fill="currentColor"
                                                    viewBox="0 0 22 20"
                                                >
                                                    <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
                                                </svg>
                                                {/* Product Rating */}
                                                <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded ms-3">4.0</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-lg font-semibold text-gray-900">৳ 12,33,599</span>
                                            <a href="#" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                Buy Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ShoppingPage;