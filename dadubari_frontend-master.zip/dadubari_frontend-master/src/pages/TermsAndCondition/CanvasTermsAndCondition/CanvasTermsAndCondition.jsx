import React from 'react';

const CanvasTermsAndCondition = () => {
    return (
        <div className='container mx-auto p-10 bg-white m-4 rounded-md'>
            <h1 className='text-3xl text-center font-semibold mt-4'> Dadubari Canvas Premium Terms and Conditions</h1>
            <hr className='max-w-80 mx-auto my-5 bg-black h-1' />
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Introduction</h3>
            <ol className='list-decimal space-y-3'>
                <li>
                    <h1 className='text-lg font-semibold'>Dadubari Canvas Overview:</h1>
                    <p>Dadubari Canvas is a dynamic feature that empowers users to create, manage, and customize their canvases for personal, business, e-commerce, or marketing purposes.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Canvas Enrichment:</h1>
                    <p>Dadubari Canvas Premium enhances the user experience by providing additional features and advantages for those opting for the premium option.
</p>
                </li>
                
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Creating and Managing Canvases</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Canvas Creation:</h1>
                    <p>Users can create canvases on Dadubari for various purposes, and Dadubari Canvas Premium offers exclusive customization options for an enriched canvas creation experience.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Advanced Customization:</h1>
                    <p>Dadubari Canvas Premium allows users to access advanced customization tools, providing them with unparalleled flexibility to tailor their canvases to their unique needs.
</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>E-commerce Excellence:</h1>
                    <p>Premium users enjoy enhanced e-commerce integration on Dadubari Canvas, with exclusive features to showcase, promote, and sell products, enriching their online shopping experience.</p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Marketing and Promotion</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Premium Marketing Features:</h1>
                    <p>Dadubari Canvas Premium introduces premium marketing features, empowering users to conduct more impactful campaigns, promotions, and brand-building initiatives.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Promotional Power:</h1>
                    <p>Premium users can leverage Dadubari Canvas to its full potential, creating and sharing promotional content that enriches their brand presence and engages their audience effectively.
</p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Premium Advantages</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Enriched Visibility:</h1>
                    <p>Premium canvases receive enriched visibility, reaching a broader audience and enhancing the chances of engagement and interaction.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Boosted Discoverability:</h1>
                    <p>Dadubari Canvas Premium users benefit from boosted discoverability, ensuring that their canvases stand out among others for enriched visibility.
</p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>User Responsibilities</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Premium Content Guidelines:</h1>
                    <p>Premium users are responsible for maintaining premium content quality, adhering to community guidelines, and ensuring that their enriched canvases contribute positively to the Dadubari community.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Transactional Excellence:</h1>
                    <p>For e-commerce activities conducted on Dadubari Canvas Premium, users are responsible for maintaining the highest standards in transactional integrity, enriching the shopping experience for their customers.
</p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Privacy and Security</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Premium Privacy Settings:</h1>
                    <p>Dadubari Canvas Premium allows users to access premium privacy settings, offering an enriched level of control over who can view and engage with their canvases.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Security Assurance:</h1>
                    <p>Dadubari upholds stringent security measures for Dadubari Canvas Premium to ensure the privacy and security of premium users' information and transactions.

</p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Termination and Moderation</h3>
            <ol className='list-decimal space-y-3'>
               
                <li>
                    <h1 className='text-lg font-semibold'>Premium Termination Rights:</h1>
                    <p>Dadubari reserves the right to terminate or suspend Dadubari Canvas Premium access for users who violate terms and conditions, ensuring an enriched and secure environment for premium subscribers.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Moderation Excellence:</h1>
                    <p>Premium canvases undergo enriched moderation, ensuring that premium users maintain the highest standards in content and activities on Dadubari Canvas Premium.

</p>
                </li>
            </ol>

        </div>
    );
};

export default CanvasTermsAndCondition;