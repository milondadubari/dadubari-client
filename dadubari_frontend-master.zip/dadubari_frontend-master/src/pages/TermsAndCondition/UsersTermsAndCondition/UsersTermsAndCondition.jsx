import React from 'react';

const UsersTermsAndCondition = () => {
    return (
        <div className='container mx-auto p-10 bg-white m-4 rounded-md'>
            <h1 className='text-3xl text-center font-semibold mt-4'> Dadubari Terms and Conditions</h1>
            <hr className='max-w-80 mx-auto my-5 bg-black h-1' />
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Account Creation and Registration</h3>
            <ol className='list-decimal space-y-3'>
                <li>
                    <h1 className='text-lg font-semibold'>Eligibility:</h1>
                    <p>To create an account on Dadubari, users must meet the eligibility criteria outlined in these terms.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>User Information:</h1>
                    <p>During the registration process on Dadubari, users will be required to provide accurate and complete information, including their name, email address, and password.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Accurate Information:</h1>
                    <p>Users are obligated to furnish truthful and accurate information when registering on Dadubari. Any discrepancies may result in account suspension or termination.
                    </p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Account Security:</h1>
                    <p>Dadubari places a high priority on account security. Users are encouraged to create strong passwords and take necessary measures to protect their accounts.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Age Verification:</h1>
                    <p>Users must verify their age during registration. If applicable, parental consent may be required for users below a certain age.
                    </p>
                </li>
            </ol>
            <h3 className='text-2xl text-center mt-10 mb-9 font-semibold'>Forgot Password and Account Recovery</h3>
            <ol className='list-decimal space-y-3'>
                <li>
                    <h1 className='text-lg font-semibold'>Password Reset:</h1>
                    <p>In the event of a forgotten password, users can initiate a password reset on Dadubari. This process involves a series of security checks to safeguard account integrity.
</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Security Measures:</h1>
                    <p>Dadubari implements robust security measures during the password recovery process to prevent unauthorized access.</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Verification Steps:</h1>
                    <p>Users will need to follow specific steps to verify their identity during the account recovery process. This may include confirming account details or using two-factor authentication.
</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Authentication Methods:</h1>
                    <p>Dadubari employs various authentication methods to ensure that only the rightful account owner can successfully recover their account.
</p>
                </li>
                <li>
                    <h1 className='text-lg font-semibold'>Communication Channels:</h1>
                    <p>Account recovery information and instructions will be communicated through designated channels, such as email, to ensure a secure and reliable process.</p>
                </li>
            </ol>

        </div>
    );
};

export default UsersTermsAndCondition;