import JobApplicantProfile from "../../components/Job/JobApplicantProfile/JobApplicantProfile";
// import FormPartFour from "../../components/Job/JobApplicationForm/FormPartFour";
// import FormPartOne from "../../components/Job/JobApplicationForm/FormPartOne";
// import FormPartThree from "../../components/Job/JobApplicationForm/FormPartThree";
// import FromPartTwo from "../../components/Job/JobApplicationForm/FromPartTwo";

const JobApplicant = () => {

    //!file handling function

    return (
        <div className="container mx-auto space-x-3 px-3 my-3 min-h-screen space-y-4">
            <JobApplicantProfile />
        </div>
    );
};

export default JobApplicant;
