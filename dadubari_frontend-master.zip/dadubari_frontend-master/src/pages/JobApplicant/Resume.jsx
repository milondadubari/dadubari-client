import { useState } from "react";
import Stepper from "../../components/Form/Stepper";
import StepperControl from "../../components/Form/StepperControl";
import About from "../../components/JobApplication/About";
import Experience from "../../components/JobApplication/Experience";
import OtherInfo from "../../components/JobApplication/OtherInfo";
import Qualification from "../../components/JobApplication/Qualification";
import { StepperContext } from "../../context/StepperContext";
import axiosInstance from "../../services";
import { toastDesign } from "../../Reducers/userReducers/userSlice";
import { toast } from "react-toastify";

const Resume = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [userData, setUserData] = useState("");
  const [finalData, setFinalData] = useState([]);

  const allSteps = ["About", "Experience", "Qualification", "Job Preference"];

  const displayStep = (step) => {
    switch (step) {
      case 1:
        return <About />;
      case 2:
        return <Experience />;
      case 3:
        return <Qualification />;
      case 4:
        return <OtherInfo />;
      default:
    }
  };

  const postAllInfo = async () => {
    try {
      const data = await axiosInstance.patch(
        "/api/v1/job-application-profileSetUp",
        userData,
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("dadubari")}`,
          },
        }
      );
      if(data){
        toast.success("job application successfull",toastDesign)
        setUserData("")
        setCurrentStep(1);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleClick = (direction) => {
    let newStep = currentStep;

    if (direction == "submit") {
      postAllInfo();
      return;
    }
    direction === "next" ? newStep++ : newStep--;

    newStep > 0 && newStep <= allSteps.length && setCurrentStep(newStep);
  };
  const handleChange = (e) => {
    e.preventDefault();
  };
  return (
    <div className="container md:w-5/6 m-12 mx-auto shadow-xl rounded-2xl pb-2 bg-white">
      <form onSubmit={handleChange}>
        <div className="container horizontal mt-5">
          <Stepper currentStep={currentStep} allSteps={allSteps} />
        </div>
        <div className="my-10 p-10">
          <StepperContext.Provider
            value={{ userData, setUserData, finalData, setFinalData }}
          >
            {displayStep(currentStep)}
          </StepperContext.Provider>
        </div>
        <div>
          <StepperControl
            handleClick={handleClick}
            currentStep={currentStep}
            allSteps={allSteps}
          />
        </div>
      </form>
    </div>
  );
};

export default Resume;
