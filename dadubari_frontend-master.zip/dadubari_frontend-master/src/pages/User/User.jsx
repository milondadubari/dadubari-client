import { Link } from "react-router-dom"

const User = ({userid , userName}) => {

  return (
   <div>
    <h1><Link to={`/user/profile/${userid}`}> {userName} </Link></h1>
   </div>
  )
}

export default User