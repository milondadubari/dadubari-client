import { useSelector } from "react-redux";
import chatIcon from "../../../src/icons/svg/chatIcon.svg"
import searchIcon from "../../../src/icons/svg/searchIcon.svg"
import qrScannerIcon from "../../../src/icons/svg/qrScannerIcon.svg"
import reelsIcon from "../../../src/icons/svg/reelsIcon.svg"
import documentIcon from "../../../src/icons/svg/documentIcon.svg"
import createPostIcon from "../../../src/icons/svg/createPostIcon.svg"
import commentMore from "../../../src/icons/svg/commentMore.svg"
import homeIcon from "../../../src/icons/svg/homeIcon.svg"
import notificationIcon from "../../../src/icons/svg/notificationIcon.svg"
import menuIcon from "../../../src/icons/svg/menuIcon.svg"
import businessCard from "../../../src/icons/svg/businessCard.svg"
import albumsIcon from "../../../src/icons/svg/albumsIcon.svg"
const AndroidAppView = () => {
    const userDetails = useSelector((data) => data?.users?.data);

    // Function to get the time of day
    const getTimeOfDay = () => {
        const currentTime = new Date().getHours();
        if (currentTime >= 5 && currentTime < 12) {
            return "morning";
        } else if (currentTime >= 12 && currentTime < 17) {
            return "afternoon";
        } else if (currentTime >= 17 && currentTime < 21) {
            return "evening";
        } else {
            return "night";
        }
    };

    // Get the appropriate greeting based on the time of day
    const greeting = getTimeOfDay();

    // Define content for each time of day
    const greetingsContent = {
        morning: {
            text: "Good morning",
            image: "https://img.icons8.com/arcade/64/morning.png",
        },
        afternoon: {
            text: "Good afternoon",
            image: "https://img.icons8.com/arcade/64/afternoon.png",
        },
        evening: {
            text: "Good evening",
            image: "https://img.icons8.com/arcade/64/evening.png",
        },
        night: {
            text: "Good night",
            image: "https://img.icons8.com/arcade/64/night.png",
        },
    };

    // Normal post intregetion start

    // Normal post intregetion end


    return (
        <div>
            {/* Navbar start */}
            <nav className="bg-gradient-to-tr from-blue-800 to-purple-700 p-2">
                <div className="container mx-auto flex justify-between  items-center pr-3">
                    {/* logo */}
                    <div className="text-white text-xl mt-2 ml-2 font-bold">
                        <a>
                            <img
                                className="w-12 md:w-16"
                                src="https://i.ibb.co/cJhTWSC/dadubari-logo.png"
                                alt=""
                            />
                        </a>
                    </div>
                    {/* nav item */}
                    <div className='flex gap-3'>
                        {/* Search Bar */}
                        {/* <img className='h-9' src={searchIcon} alt="" /> */}
                        <div className="flex items-center max-w-md mx-auto bg-white rounded-l-md rounded-r-lg">
                            <div className="w-full">
                                <input
                                    type="search"
                                    className="w-32 px-3 text-gray-800 focus:outline-none"
                                    placeholder="Search"
                                />
                            </div>
                            <div>
                                <button
                                    type="button"
                                    className="flex items-center justify-center w-9 h-9 text-white rounded-r-md bg-violet-500"
                                >
                                    <img src={searchIcon} className="h-6" alt="" />
                                </button>
                            </div>
                        </div>
                        {/* Qr Scanner */}
                        <img className='h-9' src={qrScannerIcon} alt="" />
                        {/* Chat icon */}
                        <img className='h-9' src={chatIcon} alt="" />
                    </div>
                </div>
            </nav>
            <div className='space-y-2 p-2'>

                {/* Navbar end */}
                {/* Home page start */}
                {/* Hero section start */}
                <div className='flex justify-between items-center rounded-lg bg-white p-4  space-y-4 w-full'>
                    {/* Mini profile area start */}
                    <div className='flex flex-col items-center gap-2'>
                        <div className='flex items-center gap-2'>
                            <p className='text-base pl-5 font-medium'>Good Morning</p>
                            <img className=" h-8" src="https://img.icons8.com/arcade/64/morning.png" alt="" />
                        </div>
                        <img className='rounded-full w-32 h-32 object-cover object-top' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        <h1 className='text-lg font-medium'>Shamsu Uddin</h1>

                    </div>
                    {/* User Shortcut Area start */}
                    <div className='space-y-2'>
                        <div className='flex gap-3 items-center bg-gray-100 p-1 px-2 shadow-sm rounded-md'>
                            <img className='h-6' src={reelsIcon} alt="" />
                            <h1 className='text-lg font-medium'>Reel Video</h1>
                        </div>
                        <div className='flex gap-3 items-center bg-gray-100 p-1 px-2  shadow-sm rounded-md'>
                            <img className='h-6' src={businessCard} alt="" />
                            <h1 className='text-lg font-medium'>Business Card</h1>
                        </div>
                        <div className='flex gap-3 items-center bg-gray-100 p-1 px-2  shadow-sm rounded-md'>
                            <img className='h-6' src={documentIcon} alt="" />
                            <h1 className='text-lg font-medium'>Document</h1>
                        </div>
                        <div className='flex gap-3 items-center bg-gray-100 p-1 px-2  shadow-sm rounded-md'>
                            <img className='h-6' src={albumsIcon} alt="" />
                            <h1 className='text-lg font-medium'>Albums</h1>
                        </div>
                        {/* <div className='flex gap-3 items-center'>
                            <svg class="h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M5 21V3.90002C5 3.90002 5.875 3 8.5 3C11.125 3 12.875 4.8 15.5 4.8C18.125 4.8 19 3.9 19 3.9V14.7C19 14.7 18.125 15.6 15.5 15.6C12.875 15.6 11.125 13.8 8.5 13.8C5.875 13.8 5 14.7 5 14.7" stroke="#a855f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                            <h1 className='text-lg font-medium'>My Pages</h1>
                        </div> */}
                    </div>

                    {/* User Shortcut Area end */}
                    {/* Mini profile area end */}
                </div>
                {/* Hero section end */}
                {/* Create post start */}
                <form className='bg-white p-2 rounded-lg w-full'>
                    <div className='w-full  flex justify-center gap-3'>
                        <img className='w-11 h-11 object-cover object-top rounded' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        <textarea
                            type="text"
                            className="h-11 bg-gray-100 rounded-md w-full px-4 py-2 text-gray-800 focus:outline-none"
                            placeholder="What's going on?"
                        />
                        <button
                            type="submit"
                            className="whitespace-nowrap max-h-11 sm:hidden bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4  rounded-md"
                        >
                            {" "}
                            <img src={createPostIcon} alt="" />
                        </button>
                    </div>
                </form>
                {/* Welcome Message */}
                <div className="bg-white p-2 px-3 rounded-lg w-full">
                    <div className="flex items-center">
                        <div className="space-y-1 w-full">
                            <h1 className="text-lg font-semibold">
                                {greetingsContent[greeting].text}, {userDetails?.name}
                            </h1>
                            <p>{greetingsContent[greeting].message}</p>
                        </div>
                        <div>
                            <img
                                className="motion-safe:animate-bounce"
                                src={greetingsContent[greeting].image}
                                alt=""
                            />
                        </div>
                    </div>
                </div>
                {/* Create post end */}

                {/* Normal post start */}
                <div className="bg-white p-5 rounded-lg w-full">
                    <div className="flex justify-between">
                        <div className="flex gap-4 w-full items-center my-4">
                            {/* Profile */}
                            <img
                                src="https://i.ibb.co/4MfBkWh/t4h9mzr6w1sptcsbrpk4.jpg"
                                className=" w-12 h-12 md:w-16 md:h-16 object-cover object-top rounded-md shadow-lg bg-black"
                            />
                            <div>
                                <h1 className="text-gray-700 flex items-center gap-2 flex-wrap">
                                    <h1 className="font-medium text-black text-lg">Md. Muzhar</h1>
                                    uploaded new photo
                                </h1>
                                <p className="text-gray-400"> 1d ago</p>
                            </div>
                        </div>

                        <img
                            src={commentMore}
                            className="w-4 h-4 cursor-pointer"
                            alt=""
                        />
                    </div>
                    <div>
                        <div>
                            <img
                                src="https://i.ibb.co/60y1W9w/about.jpg"
                                className="my-3 mx-auto max-h-52 md:max-h-80 w-auto rounded-lg"
                                alt=""
                            />

                        </div>

                    </div>
                    <hr className="mt-2" />
                    <div className="mt-4 px-3 flex items-center justify-between">
                        {/* Like comment share icon */}
                        <div className="flex gap-2 items-center">
                            {/* Like icon */}

                            <svg
                                className="w-6 h-6 transition ease-in-out delay-50 hover:text-violet-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M20.2694 16.265L20.9749 12.1852C21.1511 11.1662 20.3675 10.2342 19.3345 10.2342H14.1534C13.6399 10.2342 13.2489 9.77328 13.332 9.26598L13.9947 5.22142C14.1024 4.56435 14.0716 3.892 13.9044 3.24752C13.7659 2.71364 13.354 2.28495 12.8123 2.11093L12.6673 2.06435C12.3399 1.95918 11.9826 1.98365 11.6739 2.13239C11.3342 2.29611 11.0856 2.59473 10.9935 2.94989L10.5178 4.78374C10.3664 5.36723 10.1460 5.93045 9.8617 6.46262C9.44634 7.24017 8.80416 7.86246 8.13663 8.43769L6.69789 9.67749C6.29223 10.0271 6.07919 10.5506 6.12535 11.0844L6.93752 20.4771C7.01201 21.3386 7.73231 22 8.59609 22H13.2447C16.726 22 19.697 19.5744 20.2694 16.265Z"
                                    fill="#8B5CF6"
                                ></path>
                                <path
                                    opacity="0.5"
                                    fillRule="evenodd"
                                    clipRule="evenodd"
                                    d="M2.96767 9.48508C3.36893 9.46777 3.71261 9.76963 3.74721 10.1698L4.71881 21.4063C4.78122 22.1281 4.21268 22.7502 3.48671 22.7502C2.80289 22.7502 2.25 22.1954 2.25 21.5129V10.2344C2.25 9.83275 2.5664 9.50240 2.96767 9.48508Z"
                                    fill="#8B5CF6"
                                ></path>
                            </svg>

                            {/* comment icon */}
                            <svg
                                className="h-8 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 -0.5 25 25"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                transform="matrix(-1, 0, 0, 1, 0, 0)"
                            >
                                <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                                <g
                                    id="SVGRepo_tracerCarrier"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                ></g>
                                <g id="SVGRepo_iconCarrier">
                                    {" "}
                                    <path
                                        fillRule="evenodd"
                                        clipRule="evenodd"
                                        d="M5.5 12C5.49988 14.613 6.95512 17.0085 9.2741 18.2127C11.5931 19.4169 14.3897 19.2292 16.527 17.726L19.5 18V12C19.5 8.13401 16.366 5 12.5 5C8.63401 5 5.5 8.13401 5.5 12Z"
                                        stroke="#8B5CF6"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    ></path>{" "}
                                    <path
                                        d="M9.5 13.25C9.08579 13.25 8.75 13.5858 8.75 14C8.75 14.4142 9.08579 14.75 9.5 14.75V13.25ZM13.5 14.75C13.9142 14.75 14.25 14.4142 14.25 14C14.25 13.5858 13.9142 13.25 13.5 13.25V14.75ZM9.5 10.25C9.08579 10.25 8.75 10.5858 8.75 11C8.75 11.4142 9.08579 11.75 9.5 11.75V10.25ZM15.5 11.75C15.9142 11.75 16.25 11.4142 16.25 11C16.25 10.5858 15.9142 10.25 15.5 10.25V11.75ZM9.5 14.75H13.5V13.25H9.5V14.75ZM9.5 11.75H15.5V10.25H9.5V11.75Z"
                                        fill="#8B5CF6"
                                    ></path>{" "}
                                </g>
                            </svg>
                            {/* Share icon */}
                            <svg
                                className="h-10 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 -0.5 25 25"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                                <g
                                    id="SVGRepo_tracerCarrier"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                ></g>
                                <g id="SVGRepo_iconCarrier">
                                    {" "}
                                    <path
                                        fillRule="evenodd"
                                        clipRule="evenodd"
                                        d="M14.734 15.8974L19.22 12.1374C19.3971 11.9927 19.4998 11.7761 19.4998 11.5474C19.4998 11.3187 19.3971 11.1022 19.22 10.9574L14.734 7.19743C14.4947 6.9929 14.1598 6.94275 13.8711 7.06826C13.5824 7.19377 13.3906 7.47295 13.377 7.78743V9.27043C7.079 8.17943 5.5 13.8154 5.5 16.9974C6.961 14.5734 10.747 10.1794 13.377 13.8154V15.3024C13.3888 15.6178 13.5799 15.8987 13.8689 16.0254C14.158 16.1521 14.494 16.1024 14.734 15.8974Z"
                                        stroke="#8B5CF6"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    ></path>{" "}
                                </g>
                            </svg>
                        </div>
                        <div className="flex gap-3 text-gray-500">
                            <p>5 coments</p>
                        </div>
                    </div>
                </div>
                <div className="bg-white p-5 rounded-lg w-full">
                    <div className="flex justify-between">
                        <div className="flex gap-4 w-full items-center my-4">
                            {/* Profile */}
                            <img
                                src="https://i.ibb.co/4MfBkWh/t4h9mzr6w1sptcsbrpk4.jpg"
                                className=" w-12 h-12 md:w-16 md:h-16 object-cover object-top rounded-md shadow-lg bg-black"
                            />
                            <div>
                                <h1 className="text-gray-700 flex items-center gap-2 flex-wrap">
                                    <h1 className="font-medium text-black text-lg">Md. Muzhar</h1>
                                    has a status
                                </h1>
                                <p className="text-gray-400"> 1d ago</p>
                            </div>
                        </div>

                        <img
                            src={commentMore}
                            className="w-4 h-4 cursor-pointer"
                            alt=""
                        />
                    </div>
                    <div>
                        {/* post content */}
                        <h1 className="py-3">Social media is an important part of today's world. It helps people stay connected and share ideas, thoughts, and opinions with others in a safe and secure environment. It can also be used to promote businesses, organizations, and causes, as well as to stay informed about current events and trends.</h1>
                    </div>

                    <hr className="mt-2" />
                    <div className="mt-4 px-3 flex items-center justify-between">
                        {/* Like comment share icon */}
                        <div className="flex gap-2 items-center">
                            {/* Like icon */}

                            <svg
                                className="w-6 h-6 transition ease-in-out delay-50 hover:text-violet-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M20.2694 16.265L20.9749 12.1852C21.1511 11.1662 20.3675 10.2342 19.3345 10.2342H14.1534C13.6399 10.2342 13.2489 9.77328 13.332 9.26598L13.9947 5.22142C14.1024 4.56435 14.0716 3.892 13.9044 3.24752C13.7659 2.71364 13.354 2.28495 12.8123 2.11093L12.6673 2.06435C12.3399 1.95918 11.9826 1.98365 11.6739 2.13239C11.3342 2.29611 11.0856 2.59473 10.9935 2.94989L10.5178 4.78374C10.3664 5.36723 10.1460 5.93045 9.8617 6.46262C9.44634 7.24017 8.80416 7.86246 8.13663 8.43769L6.69789 9.67749C6.29223 10.0271 6.07919 10.5506 6.12535 11.0844L6.93752 20.4771C7.01201 21.3386 7.73231 22 8.59609 22H13.2447C16.726 22 19.697 19.5744 20.2694 16.265Z"
                                    fill="#8B5CF6"
                                ></path>
                                <path
                                    opacity="0.5"
                                    fillRule="evenodd"
                                    clipRule="evenodd"
                                    d="M2.96767 9.48508C3.36893 9.46777 3.71261 9.76963 3.74721 10.1698L4.71881 21.4063C4.78122 22.1281 4.21268 22.7502 3.48671 22.7502C2.80289 22.7502 2.25 22.1954 2.25 21.5129V10.2344C2.25 9.83275 2.5664 9.50240 2.96767 9.48508Z"
                                    fill="#8B5CF6"
                                ></path>
                            </svg>

                            {/* comment icon */}
                            <svg
                                className="h-8 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 -0.5 25 25"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                transform="matrix(-1, 0, 0, 1, 0, 0)"
                            >
                                <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                                <g
                                    id="SVGRepo_tracerCarrier"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                ></g>
                                <g id="SVGRepo_iconCarrier">
                                    {" "}
                                    <path
                                        fillRule="evenodd"
                                        clipRule="evenodd"
                                        d="M5.5 12C5.49988 14.613 6.95512 17.0085 9.2741 18.2127C11.5931 19.4169 14.3897 19.2292 16.527 17.726L19.5 18V12C19.5 8.13401 16.366 5 12.5 5C8.63401 5 5.5 8.13401 5.5 12Z"
                                        stroke="#8B5CF6"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    ></path>{" "}
                                    <path
                                        d="M9.5 13.25C9.08579 13.25 8.75 13.5858 8.75 14C8.75 14.4142 9.08579 14.75 9.5 14.75V13.25ZM13.5 14.75C13.9142 14.75 14.25 14.4142 14.25 14C14.25 13.5858 13.9142 13.25 13.5 13.25V14.75ZM9.5 10.25C9.08579 10.25 8.75 10.5858 8.75 11C8.75 11.4142 9.08579 11.75 9.5 11.75V10.25ZM15.5 11.75C15.9142 11.75 16.25 11.4142 16.25 11C16.25 10.5858 15.9142 10.25 15.5 10.25V11.75ZM9.5 14.75H13.5V13.25H9.5V14.75ZM9.5 11.75H15.5V10.25H9.5V11.75Z"
                                        fill="#8B5CF6"
                                    ></path>{" "}
                                </g>
                            </svg>
                            {/* Share icon */}
                            <svg
                                className="h-10 transition ease-in-out delay-50  hover:text-indigo-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
                                viewBox="0 -0.5 25 25"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                                <g
                                    id="SVGRepo_tracerCarrier"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                ></g>
                                <g id="SVGRepo_iconCarrier">
                                    {" "}
                                    <path
                                        fillRule="evenodd"
                                        clipRule="evenodd"
                                        d="M14.734 15.8974L19.22 12.1374C19.3971 11.9927 19.4998 11.7761 19.4998 11.5474C19.4998 11.3187 19.3971 11.1022 19.22 10.9574L14.734 7.19743C14.4947 6.9929 14.1598 6.94275 13.8711 7.06826C13.5824 7.19377 13.3906 7.47295 13.377 7.78743V9.27043C7.079 8.17943 5.5 13.8154 5.5 16.9974C6.961 14.5734 10.747 10.1794 13.377 13.8154V15.3024C13.3888 15.6178 13.5799 15.8987 13.8689 16.0254C14.158 16.1521 14.494 16.1024 14.734 15.8974Z"
                                        stroke="#8B5CF6"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    ></path>{" "}
                                </g>
                            </svg>
                        </div>
                        <div className="flex gap-3 text-gray-500">
                            <p>5 coments</p>
                        </div>
                    </div>
                </div>
                {/* Normal post end */}

                {/* Home page end */}
            </div>
            {/* Footer */}
            <footer className="bg-gradient-to-tr from-blue-800 to-purple-700 py-3 px-6">
                <div className="container mx-auto flex justify-between  items-center pr-3">
                    {/* Explore */}
                    <svg className="h-10" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M9.73319 10.4608C9.82276 10.1025 10.1025 9.82273 10.4608 9.73315L13.9187 8.86869C14.651 8.68559 15.3144 9.34899 15.1313 10.0814L14.2669 13.5392C14.1773 13.8975 13.8975 14.1773 13.5393 14.2668L10.0814 15.1313C9.34902 15.3144 8.68562 14.651 8.86872 13.9186L9.73319 10.4608Z" stroke="#ffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M12 3.5C5.5 3.5 3.5 5.5 3.5 12C3.5 18.5 5.5 20.5 12 20.5C18.5 20.5 20.5 18.5 20.5 12C20.5 5.5 18.5 3.5 12 3.5Z" stroke="#ffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                    {/* Search */}
                    <svg className='h-9' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#ffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M20 20L15.8033 15.8033M18 10.5C18 6.35786 14.6421 3 10.5 3C6.35786 3 3 6.35786 3 10.5C3 14.6421 6.35786 18 10.5 18C14.6421 18 18 14.6421 18 10.5Z" stroke="#ffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                    {/* Homeicon */}
                    <img className='h-16 p-3 bg-purple-500 border-white border-2 rounded-full' src={homeIcon} alt="" />
                    {/* Qr Scanner */}
                    <img className='h-9' src={notificationIcon} alt="" />
                    {/* Chat icon */}
                    <img className='h-10' src={menuIcon} alt="" />
                </div>
            </footer>
        </div>

    );
};

export default AndroidAppView;