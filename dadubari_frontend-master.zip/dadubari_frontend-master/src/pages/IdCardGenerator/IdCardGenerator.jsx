import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode.react";
import uploadImage from "../../icons/svg/uploadImage.svg";
import html2canvas from "html2canvas";
import emailIcon from "../../icons/svg/emailIcon.svg";
import addressIcon from "../../icons/svg/addressIcon.svg";
import phoneOneIcon from "../../icons/svg/phoneIcon.svg";
import websiteIcon from "../../icons/svg/websiteIcon.svg";
import IdCardTemplate1 from "../../components/IdCardTemplate/IdCardTemplate1"
import AllIdCardTemplate from "../../components/IdCardTemplate/AllIdCardTemplate";

const IdCardGenerator = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    designation: "",
    companyName: "",
    companyTagline: "",
    address: "",
    phoneOne: "",
    phoneTwo: "",
    email: "",
    website:"",
    bloodGroup: "",
  });

  const [backgroundImage, setBackgroundImage] = useState("");
  const [backgroundColor, setBackgroundColor] = useState("#00203C");
  const [textColor, setTextColor] = useState("#ffffff");
  const [useImageBackground, setUseImageBackground] = useState(false);
  const [profileImage, setProfileImage] = useState(
    "https://i.ibb.co/BL2FBLK/shadow.png"
  );
  const [companyLogo, setCompanyLogo] = useState(
    "https://i.ibb.co/cJhTWSC/dadubari-logo.png"
  );

  const generateQRCode = () => {
    const {
      fullName,
      designation,
      companyName,
      companyTagline,
      address,
      phoneOne,
      phoneTwo,
      email,
      website,
      bloodGroup,
    } = formData;
    const data = `
        ${fullName}, 
        ${designation}, 
        ${companyName}, 
        ${companyTagline},
        ${address}, 
        ${phoneOne}, 
        ${phoneTwo},
        ${email}, 
        ${website}`;
    return data;
  };

  useEffect(() => {
    generateQRCode();
  }, [formData]);

  const handleInputChange = (e, field) => {
    setFormData({
      ...formData,
      [field]: e.target.value,
    });
  };

  const cardRef = useRef(null);
  const handleDownloadCard = () => {
    cardRef.current;

    html2canvas(cardRef.current).then((canvas) => {
      const dataURL = canvas.toDataURL("image/png");
      const downloadLink = document.createElement("a");
      downloadLink.href = dataURL;
      downloadLink.download = "id_card.png";
      downloadLink.click();
    });
  };

  const handleBackgroundImageUpload = (e) => {
    const imageFile = e.target.files[0];
    const imageUrl = URL.createObjectURL(imageFile);
    setBackgroundImage(imageUrl);
    setUseImageBackground(true);
  };

  const handleBackgroundColorChange = (e) => {
    setBackgroundColor(e.target.value);
    setUseImageBackground(false);
  };

  const handleTextColorChange = (e) => {
    setTextColor(e.target.value);
  };
  const handleProfileImageUpload = (e) => {
    const imageFile = e.target.files[0];
    const imageUrl = URL.createObjectURL(imageFile);
    setProfileImage(imageUrl);
  };
  const handleCompanyLogoUpload = (e) => {
    const imageFile = e.target.files[0];
    const imageUrl = URL.createObjectURL(imageFile);
    setCompanyLogo(imageUrl);
  };
  return (
    <div className="container mx-auto space-x-3 px-3 my-3  space-y-4 ">
      <h1 className="text-2xl font-bold border-b-4 text-center w-60 mx-auto pb-2 mb-10 border-black">
        Id Card Generator
      </h1>
      <div className="flex flex-wrap justify-between gap-5 ">
        {/* Card data */}
        <div className="flex-1 h-[60vh] overflow-y-scroll">
          {/* Your Name, Designation */}
          <div className="bg-white p-4 rounded-lg space-y-5">
            {/*Full Name*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Full Name :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your name here"
                required
                value={formData.fullName}
                onChange={(e) => handleInputChange(e, "fullName")}
              />
            </div>
            {/*Designation*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Designation :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Designation here"
                required
                value={formData.designation}
                onChange={(e) => handleInputChange(e, "designation")}
              />
            </div>
            {/*Company Name*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Company Name :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Company Name here"
                required
                value={formData.companyName}
                onChange={(e) => handleInputChange(e, "companyName")}
              />
            </div>
            {/*Company Tagline*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Company Tagline :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Company Tagline here"
                required
                value={formData.companyTagline}
                onChange={(e) => handleInputChange(e, "companyTagline")}
              />
            </div>
            {/* Company logo */}
            <div className="flex flex-wrap items-center gap-3">
              <label
                htmlFor="fileInputCompanyLogo"
                className="font-medium text-lg whitespace-nowrap"
              >
                Company Logo :
              </label>
              <label htmlFor="fileInputCompanyLogo" className="cursor-pointer">
                <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                  <img className="w-5" src={uploadImage} alt="" /> Upload Your
                  Company Logo
                </div>
              </label>
              <input
                type="file"
                id="fileInputCompanyLogo"
                accept="image/*"
                onChange={handleCompanyLogoUpload}
                className="opacity-0 hidden"
              />
            </div>
            {/*Address*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Address :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Address here"
                required
                value={formData.address}
                onChange={(e) => handleInputChange(e, "address")}
              />
            </div>
            {/*phoneOne*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Phone One :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your phone number here"
                required
                value={formData.phoneOne}
                onChange={(e) => handleInputChange(e, "phoneOne")}
              />
            </div>
            {/*phoneTwo*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Phone Two :
              </label>
              <input
                type="text"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your phone number here"
                required
                value={formData.phoneTwo}
                onChange={(e) => handleInputChange(e, "phoneTwo")}
              />
            </div>
            {/*Email*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Email :
              </label>
              <input
                type="email"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Email here"
                required
                value={formData.email}
                onChange={(e) => handleInputChange(e, "email")}
              />
            </div>
            {/*website*/}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Website :
              </label>
              <input
                type="website"
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your website name here"
                required
                value={formData.website}
                onChange={(e) => handleInputChange(e, "website")}
              />
            </div>
            <div className="flex flex-wrap gap-4">
              {/* Upload your Image */}
              <div className="flex flex-wrap items-center gap-3">
                <label
                  htmlFor="fileInputUserImage"
                  className="font-medium text-lg whitespace-nowrap"
                >
                  Image :
                </label>
                <label htmlFor="fileInputUserImage" className="cursor-pointer">
                  <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                    <img className="w-5" src={uploadImage} alt="" /> Upload Your
                    Image
                  </div>
                </label>
                <input
                  type="file"
                  id="fileInputUserImage"
                  accept="image/*"
                  onChange={handleProfileImageUpload}
                  className="opacity-0 hidden"
                />
              </div>
            </div>
            {/*Card Text Color */}
            <div className="flex flex-wrap items-center gap-3">
              <label className="font-medium text-lg whitespace-nowrap">
                Card Text Color :
              </label>
              <input
                type="color"
                value={textColor}
                onChange={handleTextColorChange}
                className="appearance-none rounded-md border-0 w-20 h-10"
                defaultValue="#ffffff"
              />
            </div>
            {/*Card Background Color */}
            <div className="flex flex-wrap items-center gap-3">
              <label className="font-medium text-lg whitespace-nowrap">
                Card Background Color :
              </label>
              <input
                type="color"
                value={backgroundColor}
                onChange={handleBackgroundColorChange}
                className="appearance-none rounded-md border-0 w-20 h-10"
                defaultValue="#00203C"
              />
            </div>

            {/* OR text */}
            <div className="flex justify-center items-center gap-3">
              <h1 className="font-semibold text-xl">OR</h1>
            </div>
            {/* Upload Card Background IMage */}
            <div className="flex flex-wrap items-center gap-3">
              <label
                htmlFor="fileInputBackground"
                className="font-medium text-lg whitespace-nowrap"
              >
                Card Background Image :
              </label>
              <label htmlFor="fileInputBackground" className="cursor-pointer">
                <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                  {/* Image dimension should be 500*300 */}
                  <img className="w-5" src={uploadImage} alt="" /> Upload Your
                  Background Image (500*300)
                </div>
              </label>
              <input
                type="file"
                accept="image/*"
                id="fileInputBackground"
                onChange={handleBackgroundImageUpload}
                className="opacity-0 hidden"
              />
            </div>
          </div>
        </div>
        {/* Id card*/}
        <div className="flex-1 space-y-5 flex flex-col items-center ">
          {/* Main Card start */}
          <div
            className="flex justify-center lg:justify-end rounded-lg mt-1"
            ref={cardRef}
          >
            {/* Card background */}
            <div
              className="h-[340px] w-[550px] pt-6 px-6 bg-no-repeat bg-cover space-y-5"
              style={{
                backgroundImage: useImageBackground
                  ? `url(${backgroundImage})`
                  : "none",
                backgroundColor: useImageBackground
                  ? "transparent"
                  : backgroundColor,
                color: textColor,
              }}
            >
              {/* Company data and blood group */}
              <div className="flex justify-between ">
                <div className="flex items-center gap-3">
                  {/* Company logo goes here */}
                  <img
                    src={companyLogo}
                    className="h-9 w-9 mt-5"
                    alt="Company Logo"
                  />
                  {/* Company Name Goes Here */}
                  <div>
                    <h1 className="text-lg font-semibold">
                      {formData.companyName}
                    </h1>
                    <p className="text-sm">{formData.companyTagline}</p>
                  </div>
                </div>
                {/* Blood group */}
                <div className="flex flex-col items-center">
                  {/* <p
                    className="text-lg"
                    style={{
                      color: textColor,
                    }}
                  >
                    Blood Group
                  </p>
                  <p className="text-red-500 font-semibold">
                    {formData.bloodGroup}
                  </p> */}
                </div>
              </div>
              {/* Profile Image, Profile Data, Qr Code*/}
              <div className="flex justify-between gap-3 items-center">
                {/* profile Image */}
                <div>
                  <img
                    className="w-36 object-cover rounded-md mt-4"
                    src={profileImage}
                    alt=""
                  />
                </div>
                {/* Profile Data */}
                <div className="w-60">
                  <h1 className="text-xl font-semibold">{formData.fullName}</h1>
                  <h4 className="text-sm mb-1">{formData.designation}</h4>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={emailIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">{formData.email}</p>
                  </p>
                  
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={phoneOneIcon}
                      alt=""
                    />
                    <div>
                    <p>{formData.phoneOne}</p>
                    <p className="mb-4">{formData.phoneTwo}</p>
                    </div>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={addressIcon}
                      alt=""
                    />
                    <p className="mb-4">{formData.address}</p>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={websiteIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">{formData.website}</p>
                  </p>
                </div>
                {/* Qr Code */}
                <div className="flex items-center ml-5">
                  <QRCode
                    className="bg-white p-1 rounded-lg"
                    value={generateQRCode()}
                    size={140}
                  />
                </div>
              </div>
            </div>
          </div>
          {/* Main Card end */}
          {/* Id card Download Button */}
          <button
            className="whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 py-3 rounded-md"
            onClick={handleDownloadCard}
          >
            Download Card
          </button>
        </div>
      </div>
      <div className="p-5 bg-white rounded-md">
        <AllIdCardTemplate/>

      </div>
    </div>
  );
};

export default IdCardGenerator;
