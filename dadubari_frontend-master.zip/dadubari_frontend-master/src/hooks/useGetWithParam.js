import { useEffect, useState } from "react";
import axiosInstance from "../services";
import { authorization } from "../utils/authorization";

const useGetWithParam=(path)=>{
    const [data,setData] = useState([]);
    useEffect(()=>{
        (async function (){
            try {
                const res = await axiosInstance.get(path,authorization);
                setData(res?.data?.user);
            } catch (error) {
                console.log(error)
            }
        })();
    },[path])
    return data;
}

export default useGetWithParam;

