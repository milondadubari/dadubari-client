import { useEffect, useState } from "react";
import axiosInstance from "../services";
import { authorization } from "../utils/authorization";

const useGetData = (url) => {
  const [data, setdata] = useState([]);
  useEffect(() => {
   (async function(){
    try {
        const res = await axiosInstance.get(url, authorization);
        setdata(res?.data);
      } catch (error) {
          console.log(error);
      }
   })();
  }, [url]);

  return data;
};

export default useGetData;
