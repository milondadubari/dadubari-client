import Navbar from "./components/Navbar/Navbar";
import "./index.css";
import Footer from "./components/Footer/Footer";
import Home from "./pages/Home/Home";
import Single from "./pages/Single/Single";
import Register from "./pages/Register/Register";
import Login from "./pages/Login/Login";
import { Outlet, RouterProvider, createBrowserRouter} from "react-router-dom";
import ForgetPassword from "./pages/ForgetPassword/ForgetPassword";
import UpdatePassword from "./pages/ForgetPassword/UpdatePassword";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { userLoginCheck } from "./Reducers/userReducers/userSlice";
import MailVerify from "./pages/MailVerify/MailVerify";
import Protected from "./auth/Protected";
import SingleProfileEdit from "./components/UserProfile/UserSingleProfileEdit/SingleProfileEdit";
import Wallet from "./pages/Wallet/Wallet";
import Job from "./pages/JobHomepage/Job";
import JobHolder from "./pages/JobHomepage/JobHolder";
import IdCard from "./pages/IdCard/IdCard";
import JobApplicant from "./pages/JobApplicant/JobApplicant";
import Resume from "./pages/JobApplicant/Resume";
import IdCardGenerator from "./pages/IdCardGenerator/IdCardGenerator";
import Message from "./pages/Message/Message";
import UserProfile from "./pages/UserProfile/UserProfile";
import About from "./components/UserProfile/About/About";
import Canvas from "./pages/CanvasPage/Canvas";
import ShoppingPage from "./pages/ShoppingPage/ShoppingPage";
import ProductView from "./pages/ProductView/ProductView";
import CorporateLogin from "./pages/Corporate/CorporateAuth/CorporateLogin";
import CorporateRegister from "./pages/Corporate/CorporateAuth/CorporateRegister";
import CorporateProfile from "./pages/Corporate/CorporateProfile/CorporateProfile";
import AndroidAppView from "./pages/AndroidAppView/AndroidAppView";
import CorporateAccount from "./pages/Corporate/CorporateAuth/CorporateAccount";
import CorporateVisitApplication from "./pages/Corporate/CorporateVisit/CorporateVisitApplication";
import AdminDashboard from "./pages/Admin/AdminDashboard";
import AllCorporateProfile from "./pages/Corporate/CorporateProfile/AllCorporateProfile";
import MyCorporateProfile from "./pages/Corporate/CorporateProfile/MyCorporateProfile";
import CorporateProtected from "./auth/CorporateProtected";
import { corporateAuthCheck } from "./Reducers/corporateReducers/corporateAuthSlice";

import NotFoundPage from "./pages/NotFoundPage/NotFoundPage";
import ComingSoonPage from "./pages/ComingSoonPage/ComingSoonPage";
import UsersTermsAndCondition from "./pages/TermsAndCondition/UsersTermsAndCondition/UsersTermsAndCondition";
import CanvasTermsAndCondition from "./pages/TermsAndCondition/CanvasTermsAndCondition/CanvasTermsAndCondition";

function Layout() {
  return (
    <>
      <Navbar />
      <Outlet />
      <Footer />
    </>
  );
}


function App() {

  const dispatch = useDispatch();
  useEffect(()=>{
     if(localStorage.getItem("dadubari")){
      dispatch(userLoginCheck());
     }

     if(localStorage.getItem("corporateToken")){
        dispatch(corporateAuthCheck());
     }
  },[dispatch])


  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      children: [
        {
          path: "/",
          element: <Protected element={<Home />} />
        },
        {
          path: "/profile",
          element: <Protected element={<Single />} />,
        },
        {
          path: "/wallet",
          element: <Protected element={<Wallet/>}/>,
        },
        {
          path: "/edit",
          element: <Protected element={<SingleProfileEdit/>}/>
        },
        {
          path:"/job",
          element:<Protected element={<Job/>}/>
        },
        {
          path:"/job-provider",
          element:<Protected element={<JobHolder/>}/>
        },
        {
          path:"/job-application",
          element:<Protected element={<JobApplicant/>}/>

        },
        {
          path:"/idCard",
          element:<Protected element={<IdCard/>}/>
        },
        {
          path:"/idCardGenerator",
          element: <Protected element={<IdCardGenerator/>}/>
        },
        {
          path:"/resume",
          element:<Protected element={<Resume />}/>
        },
        {
          path:"/message/:id",
          element:<Protected element={<Message/>}/>
        },
        {
          path : "/user/profile/:id",
          element:<Protected element={<UserProfile />} />
        },
        {
          path : "/about",
          element:<Protected element={<About />}/>
        },
        
        {
          path:"/canvas",
          element:<Protected element={<Canvas/>}/>
        },
        {
          path:"/shopping-page",
          element:<Protected element={<ShoppingPage/>}/>
        },
        {
          path:"/product-view",
          element:<Protected element={<ProductView/>}/>
        },
        {
          path:"/corporate/register",
          element:<Protected element={<CorporateRegister />}/>,
        },
        {
          path:"/corporate/login",
          element:<Protected element={<CorporateLogin />}/>
        },
        {
          path: "/corporate/my-corporate-accounts",
          element:<Protected element={<AllCorporateProfile/>}/>
        },
        {
          path:"/corporate/profile/:id",
          element:<Protected element={<CorporateProfile />}/>
        },
        {
          path:"/corporate/my/profile/:id",
          element:<Protected element={<CorporateProtected element={<MyCorporateProfile />} />}/>
        },
        {
          path:"/corporate/account",
          element:<Protected element={<CorporateAccount/>}/>
        },
        {
          path:"/corporate/apply-to-visit",
          element:<Protected element={<CorporateVisitApplication/>}/>
        },
        {
          path:"/AndroidApp",
          element:<Protected element={<AndroidAppView/>}/>
        },
        {
          path:"/admin-dashboard",
          element:<Protected element={<AdminDashboard/>}/>
        },
        {
          path:"/Coming-soon",
          element: <ComingSoonPage/>
        },
        {
          path:"/Users-Terms-And-Condition",
          element:<UsersTermsAndCondition/>
        },
        {
          path:"/Canvas-Premium-Terms-And-Condition",
          element:<CanvasTermsAndCondition/>
        }
        
        
      ],
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/register",
      element: <Register />,
    },
    {
      path: "/forgetPassword",
      element: <ForgetPassword/>
    },
    {
      path: "/update/Password/:id/:token",
      element: <UpdatePassword/>
    },
    {
      path: "/user/verify/:id/:token",
      element: <MailVerify />
    },
    {
      path:"/Page-not-found",
      element: <NotFoundPage/>
    },
  ]);
  return (
      <div className="bg-gray-100">
        <RouterProvider router={router} />
        <ToastContainer />
      </div>
  );
}
export default App;
