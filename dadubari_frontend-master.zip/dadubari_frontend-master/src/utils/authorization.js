export const authorization = {
  headers: {
    authorization: `Bearer ${localStorage.getItem("dadubari")}`,
  },
};

export const authorizationCorporate = {
  headers: {
    corporateauthorization: `Bearer ${localStorage.getItem("corporateToken")}`,
  },
};

export const authorizationCorporateAndUser = {
  headers: {
    authorization: `Bearer ${localStorage.getItem("dadubari")}`,
    corporateauthorization: `Bearer ${localStorage.getItem("corporateToken")}`,
  },
};
