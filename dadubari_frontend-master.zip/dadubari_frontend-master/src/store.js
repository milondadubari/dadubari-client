import { configureStore } from "@reduxjs/toolkit";
import  usersReducer  from "./Reducers/userReducers/userSlice";
import postsReducer from "./Reducers/postReducers/postSlice";
import myPostReducer from "./Reducers/postReducers/getSingleUserPostSlice";
import singlePostReducer from "./Reducers/postReducers/getSinglePostSlice";
import corporateAuthReducer from "./Reducers/corporateReducers/corporateAuthSlice";


export const store = configureStore({
  reducer: {
      users : usersReducer,
      posts : postsReducer,
      myPosts : myPostReducer,
      singlePost : singlePostReducer,
      corporateAuth : corporateAuthReducer
  }
});