import { Link, useParams } from "react-router-dom";
import messageMoreIcon from "../../icons/svg/messageMoreIcon.svg";
import axiosInstance from "../../services";
import { authorization } from "../../utils/authorization";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { findChatOwner } from "../../Services/findChatOwner";

const SendMessage = () => {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState({});
  const [allMessages, setAllMessages] = useState({});
  const [chatFailedORWrongChatId, setChatFailedORWrongChatId] = useState(false);
  const { id } = useParams();

  const allMessagesFunction = async () => {
    try {
      const res = await axiosInstance.get(
        `/api/v3/getAllMessages/${id}`,
        authorization
      );
      setAllMessages(res?.data);
      setChatFailedORWrongChatId(false);
    } catch (error) {
      setChatFailedORWrongChatId(true);
      console.log(error);
    }
  };
  const handleMessage = async () => {
    try {
      await axiosInstance.post(
        `/api/v3/sendMessage/${id}`,
        { message },
        authorization
      );
      allMessagesFunction();
      await axiosInstance.get(`/api/v3/chat-update/${id}`, authorization);
      setMessage("");
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    (async function () {
      const res = await axiosInstance.get(
        `/api/v3/get-single-chat/${id}`,
        authorization
      );
      setChat(res?.data);
    })();
    allMessagesFunction();
  }, [id]);

  const userId = useSelector((states) => states?.users?.data?._id);
  let chatOwner = findChatOwner(userId, chat?.chat);
  if (id === "m" || chatFailedORWrongChatId) {
    return (
      <div className="flex items-center justify-center w-[60vw]">
        <h1 className="bold text-xl text-purple-300">No Chat</h1>
      </div>
    );
  }
  return (
    <div className="bg-white p-3 rounded-lg col-span-3 flex flex-col">
      <div className="flex justify-between items-center pb-3 border-b">
        <div className="flex gap-3">
          <img
            className="rounded-lg h-14 w-12"
            src={chatOwner?.avatar?.url}
            alt=""
          />
          <div>
            <h1 className="text-lg font-semibold">{chat?.chat?.chatName}</h1>
            <p className="font-light">Active now</p>
          </div>
        </div>
        <img className="w-6" src={messageMoreIcon} alt="" />
      </div>
      <div className="w-full h-[65vh] flex flex-col justify-end overflow-y-scroll">
        {allMessages?.allMessage?.map((msg) => {
          if (msg?.sender?._id === userId) {
            return (
              <div className="my-2 mx-4" key={msg?._id}>
                <div className="flex flex-row-reverse items-center gap-3">
                  <Link to={`/user/profile/${msg?.sender?._id}`}>
                    <img
                      className="h-8 w-8 rounded-full "
                      src={msg?.sender?.avatar?.url}
                    />
                  </Link>
                  <h1 className="bg-purple-500 text-white p-2 rounded-lg">
                    {msg?.message}
                  </h1>
                </div>
              </div>
            );
          } else {
            return (
              <div className="my-2 mx-4" key={msg?._id}>
                <div className="flex items-center justify-start gap-3">
                  <Link to={`/user/profile/${msg?.sender?._id}`}>
                    <img
                      className="h-8 w-8 rounded-full "
                      src={msg?.sender?.avatar?.url}
                    />
                  </Link>
                  <h1 className="bg-purple-500 text-white p-2 rounded-lg">
                    {msg?.message}
                  </h1>
                </div>
              </div>
            );
          }
        })}
      </div>
      <div className="w-full mt-2">
        <div className="flex gap-4">
          <textarea
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="h-auto bg-gray-100 rounded-md w-full px-4 py-1 text-gray-800 focus:outline-none"
            placeholder="What's going on? #Hashtag.. @Mention.."
          />
          {/* Emoji Pop up here*/}
          {/* <div className='text-3xl text-center'>
              ✌️😊😂😍👍😒❤️💕🤦‍♂️
              </div> */}
          <button
            type="submit"
            onClick={handleMessage}
            className="whitespace-nowrap sm:block bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md"
          >
            Message
          </button>
        </div>
      </div>
    </div>
  );
};

export default SendMessage;
