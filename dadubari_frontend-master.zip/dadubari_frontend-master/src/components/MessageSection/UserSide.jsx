import searchIcon from "../../icons/svg/searchIcon.svg";
import messageMoreIcon from "../../icons/svg/messageMoreIcon.svg";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { findChatOwner } from "../../Services/findChatOwner";
import { useEffect, useState } from "react";
import axiosInstance from "../../services";
import { authorization } from "../../utils/authorization";

const UserSide = () => {
  const [chats, setChats] = useState({});

  const loggedInId = useSelector((states) => states?.users?.data?._id);
  const getAllChat = async () => {
    try {
      const res = await axiosInstance.get(
        "/api/v3/get-all-chats",
        authorization
      );
      setChats(res?.data);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getAllChat();
  }, []);
  return (
    <div className="bg-white p-3 rounded-lg space-y-5 col-span-1 h-full">
      <div className="flex items-center max-w-md mx-auto border bg-white rounded-l-md rounded-r-lg">
        <div className="w-full">
          <input
            type="search"
            className="w-60 px-4 text-gray-800 focus:outline-none"
            placeholder="Search"
          />
        </div>
        <div>
          <button
            type="button"
            className="flex items-center justify-center w-11 h-11 text-white rounded-r-md bg-violet-500"
          >
            <img src={searchIcon} className="h-6" alt="" />
          </button>
        </div>
      </div>
      <div className="overflow-y-scroll h-[70vh] ">
        {chats?.chats?.map((chat) => {
          let user = findChatOwner(loggedInId, chat);
          if (chat?.latestMessage) {
            return (
              <div key={chat?._id}>
                <Link to={`/message/${chat?._id}`}>
                  <div className="flex justify-between items-center my-3">
                    <div className="flex gap-3">
                      <img
                        className="rounded-full w-14 h-14 "
                        src={user?.avatar?.url}
                        alt="image"
                      />
                      <div>
                        <h1 className="text-lg font-semibold">
                          {chat?.chatName}
                        </h1>
                        <p className="font-light">
                          {chat?.latestMessage?.message}
                        </p>
                      </div>
                    </div>
                    <img className="w-6" src={messageMoreIcon} alt="" />
                  </div>
                </Link>
              </div>
            );
          }
        })}
      </div>
    </div>
  );
};

export default UserSide;
