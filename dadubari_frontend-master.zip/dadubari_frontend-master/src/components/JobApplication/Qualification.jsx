import Jsc from "./Qualification/Jsc"
import Msc from "./Qualification/Msc";
import Ssc from "./Qualification/Ssc";
import Bsc from "./qualification/Bsc";
import Hsc from "./qualification/Hsc";

const Qualification = () => {

  return (
    <div className="space-y-4">
      {/* Education part */}
      <div className="bg-white p-3 rounded-lg space-y-5">
        <Jsc />
        <Ssc />
        <Hsc />
        <Bsc />
        <Msc />
      </div>
    </div>
  );
};

export default Qualification;
