import { useContext } from "react";
import uploadImage from "../../icons/svg/uploadImage.svg";
import { StepperContext } from "../../context/StepperContext";

const About = () => {
  const { userData, setUserData } = useContext(StepperContext);
  const handleChange = (e) => {
    const { value, name } = e.target;
    setUserData({ ...userData, [name]: value });
  };
  const handleCertificate = (e) => {
    const file = e.target.files[0];
    if (file) {
      const Reader = new FileReader();
      Reader.readAsDataURL(file);
      Reader.onload = () => {
        if (Reader.readyState === 2) {
          setUserData({ ...userData, [e.target.name]: Reader.result });
        }
      };
    }
  };
  return (
    <div className="space-y-4">
      {/* About yourself part */}
      <div className="bg-white p-3 rounded-lg space-y-5">
        {/*Full Name*/}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Full Name :
          </label>
          <input
            type="text"
            name="fullName"
            value={userData["fullName"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your name here"
            required
          />
        </div>
        {/* Father's Name, Mother's Name */}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Father's Name*/}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Father's Name :
            </label>
            <input
              type="text"
              name="fatherName"
              value={userData["fatherName"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Father's Name"
              required
            />
          </div>
          {/* Mother's Name */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Mother's Name :
            </label>
            <input
              type="text"
              name="motherName"
              value={userData["motherName"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Mother's Name"
              required
            />
          </div>
        </div>
        {/* NID / Birth ID, Birth, Sex */}
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3 w-full">
            {/* NID / Birth ID */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                NID / Birth ID No. :
              </label>
              <input
                type="number"
                name="NID"
                value={userData["NID"] || ""}
                onChange={handleChange}
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Job Title"
                required
              />
            </div>
            {/* Date of Birth */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Date of Birth :
              </label>
              <input
                type="date"
                name="DOBJob"
                value={userData["DOBJob"] || ""}
                onChange={handleChange}
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your website"
                required
              />
            </div>
            {/* Gender */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Gender :
              </label>
              <select
                name="gender"
                value={userData["gender"] || ""}
                onChange={handleChange}
                className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              >
                <option value="">Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Others">Others</option>
              </select>
            </div>
          </div>
        </div>
        {/*PhoneNumber, email */}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Phone Number */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Phone Number :
            </label>
            <input
              type="text"
              name="phoneNumber"
              value={userData["phoneNumber"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Phone Number"
              required
            />
          </div>
          {/* Email */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Email :
            </label>
            <input
              type="email"
              name="emailJob"
              value={userData["emailJob"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Enter your Email address"
            />
          </div>
        </div>
        {/* Linkdin */}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Linkdin Profile :
          </label>
          <input
            type="text"
            name="linkdinProfile"
            value={userData["linkdinProfile"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your Linkdin URL"
          />
        </div>
        {/* Skill */}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Skill :
          </label>
          <select
            name="skills"
            required
            value={userData["skills"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
          >
            <option value="">Select your Skill</option>
            <option value="JavaScript">JavaScript</option>
            <option value="React.js">React.js</option>
            <option value="Node.js">Node.js</option>
            <option value="Python">Python</option>
            <option value="Data Analysis">Data Analysis</option>
            <option value="UX/UI Design">UX/UI Design</option>
            <option value="Agile Methodology">Agile Methodology</option>
            <option value="Digital Marketing">Digital Marketing</option>
            <option value="Cloud Computing">Cloud Computing</option>
            <option value="Problem Solving">Problem Solving</option>
            <option value="Java">Java</option>
            <option value="Android Development">Android Development</option>
            <option value="iOS Development">iOS Development</option>
            <option value="Database Management">Database Management</option>
            <option value="Cybersecurity">Cybersecurity</option>
            <option value="Artificial Intelligence">
              Artificial Intelligence
            </option>
            <option value="Machine Learning">Machine Learning</option>
            <option value="Language Proficiency (e.g., Mandarin)">
              Language Proficiency (e.g., Mandarin)
            </option>
            <option value="Cross-Cultural Communication">
              Cross-Cultural Communication
            </option>
            <option value="Project Management">Project Management</option>
            <option value="Networking">Networking</option>
            <option value="E-commerce">E-commerce</option>
            <option value="Content Creation">Content Creation</option>
            <option value="Customer Service">Customer Service</option>
            <option value="Supply Chain Management">
              Supply Chain Management
            </option>
            <option value="Adaptability">Adaptability</option>
            <option value="Time Management">Time Management</option>
            <option value="Leadership">Leadership</option>
            <option value="Critical Thinking">Critical Thinking</option>
            <option value="Multilingual">Multilingual</option>
            <option value="Blockchain Technology">Blockchain Technology</option>
            <option value="Software Testing">Software Testing</option>
            <option value="Front-end Development">Front-end Development</option>
            <option value="Back-end Development">Back-end Development</option>
            <option value="UI/UX Research">UI/UX Research</option>
            <option value="SEO (Search Engine Optimization)">
              SEO (Search Engine Optimization)
            </option>
            <option value="Sales and Marketing">Sales and Marketing</option>
            <option value="Financial Analysis">Financial Analysis</option>
            <option value="Public Speaking">Public Speaking</option>
            <option value="Cultural Sensitivity">Cultural Sensitivity</option>
            <option value="Mobile App Development">
              Mobile App Development
            </option>
            <option value="International Business">
              International Business
            </option>
            <option value="Health and Wellness">Health and Wellness</option>
            <option value="Statistical Analysis">Statistical Analysis</option>
            <option value="Rapid Prototyping">Rapid Prototyping</option>
            <option value="Problem Resolution">Problem Resolution</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Upload your certificate */}
          <div className="flex flex-wrap items-center gap-3">
            <label className="font-medium text-lg whitespace-nowrap">
              Certificate :
            </label>
            <label htmlFor="fileInputCertificate" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadImage} alt="" /> Upload
                Certificates
              </div>
            </label>
            <input
              type="file"
              id="fileInputCertificate"
              name="certificate"
              // value={userData["certificate"] || ""}
              onChange={handleCertificate}
              accept="image/*"
              multiple
              className="opacity-0 hidden"
            />
          </div>
          {/* Award */}
          <div className="flex flex-wrap items-center gap-3">
            <label className="font-medium text-lg whitespace-nowrap">
              Award :
            </label>
            <label htmlFor="fileInputAward" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadImage} alt="" /> Add Award
                Images
              </div>
            </label>
            <input
              type="file"
              id="fileInputAward"
              name="award"
              // value={userData["award"] || ""}
              onChange={handleCertificate}
              accept="image/*"
              multiple
              className="opacity-0 hidden"
            />
          </div>
        </div>
        {/* Professional summary edit form */}
        <div className="space-y-3">
          <label className="font-medium text-lg whitespace-nowrap">
            Professional Summary :
          </label>
          <textarea
            name="professionalSummary"
            value={userData["professionalSummary"] || ""}
            onChange={handleChange}
            className="h-24 bg-gray-100 rounded-md w-full p-3 text-gray-800 focus:outline-none"
            placeholder="Tell me about your professional summary"
          />
        </div>
      </div>
    </div>
  );
};

export default About;
