import { useContext, useState } from "react";
import { StepperContext } from "../../context/StepperContext";

const Experience = () => {
  const { userData, setUserData } = useContext(StepperContext);
  const [isChecked, setIsChecked] = useState(false);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };
  const handleWorkHere = (e) => {
    setIsChecked(!isChecked);
    if (!isChecked) {
      setUserData({ ...userData, [e.target.name]: e.target.value });
    } else {
      setUserData({ ...userData, [e.target.name]: "" });
    }
  };
  return (
    <div className="space-y-4">
      {/* Work Experience Heading */}
      {/* Work Experience part */}
      <div className="bg-white p-3 rounded-lg space-y-5">
        {/*Job title*/}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Job Title :
          </label>
          <input
            type="text"
            name="jobTitleJob"
            value={userData["jobTitleJob"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your job title"
          />
        </div>
        {/*Company*/}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Company :
          </label>
          <input
            type="text"
            name="companyJob"
            value={userData["companyJob"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Type your Company Name"
          />
        </div>
        {/* Job start & job end */}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Job Start*/}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Job Start :
            </label>
            <input
              type="date"
              name="jobStart"
              value={userData["jobStart"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            />
          </div>
          {/* Job End */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Job End :
            </label>
            <input
              type="date"
              name="jobEnd"
              value={isChecked ? "" : userData["jobEnd"] || ""}
              onChange={handleChange}
              disabled={isChecked}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            />
          </div>
          {/* Active */}
          <div className="flex items-center gap-3 flex-1">
            <input
              type="checkbox"
              id="JobEnd"
              onChange={handleWorkHere}
              value="Works Here"
              name="jobEnd"
            />
            <label htmlFor="JobEnd"> I still Job here</label>
          </div>
        </div>
        {/* Description form */}
        <div className="space-y-3">
          <label className="font-medium text-lg whitespace-nowrap">
            Description :
          </label>
          <textarea
            name="Description"
            value={userData["Description"] || ""}
            onChange={handleChange}
            className="h-24 bg-gray-100 rounded-md w-full p-3 text-gray-800 focus:outline-none"
            placeholder="Tell me about your Job Description "
          />
        </div>
        {/* add more work experience */}
        <button className="block px-16 bg-violet-600 mt-5 py-2 rounded-lg text-white font-semibold mb-2">
          Add More Experience
        </button>
      </div>
    </div>
  );
};

export default Experience;
