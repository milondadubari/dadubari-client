import { useContext } from "react";
import { StepperContext } from "../../context/StepperContext";

const OtherInfo = () => {
  const { userData, setUserData } = useContext(StepperContext);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };

  return (
    <div className="space-y-4">
      {/* Job part */}
      <div className="bg-white p-3 rounded-lg space-y-5">
        {/*Job*/}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Job Title */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Job Title :
            </label>
            <input
              type="text"
              name="jobTitlePreference"
              value={userData["jobTitlePreference"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Job Title"
            />
          </div>
          {/* Desired Industry */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Desired Industry :
            </label>
            <input
              type="text"
              name="desiredIndustry"
              value={userData["desiredIndustry"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Enter your Desired Industry"
            />
          </div>
        </div>
        {/*Location*/}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Location */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Location :
            </label>
            <input
              type="text"
              required
              name="preferedJobLocation"
              value={userData["preferedJobLocation"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Enter your Location"
            />
          </div>
          {/* Employment Type */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Employment Type :
            </label>
            <select
              name="EmploymentType"
              value={userData["EmploymentType"] || ""}
              onChange={handleChange}
              required
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            >
              <option value="">Select your Type</option>
              <option value="Full-Time Employment">Full-Time Employment</option>
              <option value="Part-Time Employment">Part-Time Employment</option>
              <option value="Contract Employment">Contract Employment</option>
              <option value="Remote Employment">Remote Employment</option>
              <option value="Internship">Internship</option>
              <option value="Freelance">Freelance</option>
            </select>
          </div>
        </div>
        {/*  */}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Salary */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Salary Expectation :
            </label>
            <input
              required
              type="number"
              name="salaryExpectaion"
              value={userData["salaryExpectaion"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Your Salary Expectation"
            />
          </div>
          {/* Time Available */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Time Available :
            </label>
            <input
              type="text"
              name="EmploymentType"
              value={userData["EmploymentType"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="When you are available?"
            />
          </div>
        </div>
        {/* Portfolio */}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Portfolio Link :
          </label>
          <input
            type="text"
            name="portfolioLink"
            value={userData["portfolioLink"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Enter your Portfolio URL"
          />
        </div>
        {/* Hobbies */}
        <div className="flex items-center gap-3 flex-1">
          <label className="font-medium text-lg whitespace-nowrap">
            Hobbies :
          </label>
          <input
            type="text"
            name="hobbiesJob"
            value={userData["hobbiesJob"] || ""}
            onChange={handleChange}
            className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            placeholder="Tell us about your Hobbies"
          />
        </div>
        {/* Additional Info */}
        <div className="space-y-3">
          <label className="font-medium text-lg whitespace-nowrap">
            Additional Info :
          </label>
          <textarea
            name="additionalInfo"
            value={userData["additionalInfo"] || ""}
            onChange={handleChange}
            className="h-24 bg-gray-100 rounded-md w-full p-3 text-gray-800 focus:outline-none"
            placeholder="Share your Additional Info here "
          />
        </div>
      </div>
    </div>
  );
};

export default OtherInfo;
