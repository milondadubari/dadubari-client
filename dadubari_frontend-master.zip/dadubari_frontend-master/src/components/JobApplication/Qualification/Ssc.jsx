import { useContext } from "react";
import { StepperContext } from "../../../context/StepperContext";

const Ssc = () => {
  const { setUserData, userData } = useContext(StepperContext);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };
  return (
    <div>
      <h1 className="text-lg font-bold pt-5">SSC / Dhakil Qualification :</h1>
      <div className="space-y-5">
        {/*Institute*/}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Institute Name */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Institute Name :
            </label>
            <input
              type="text"
              name="InstituteNameSSC"
              value={userData["InstituteNameSSC"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Institute Name"
            />
          </div>
          {/* Institute Location */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Institute Location :
            </label>
            <input
              type="text"
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Enter your Institute Location"
              name="instituteLocationSSC"
              value={userData["instituteLocationSSC"] || ""}
              onChange={handleChange}
            />
          </div>
        </div>
        {/*Grading and field of study*/}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Grading */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Grading :
            </label>
            <input
              type="text"
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Enter your Grading"
              name="GradeSSC"
              value={userData["GradeSSC"] || ""}
              onChange={handleChange}
            />
          </div>
          {/* Field Of Study */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Field Of Study :
            </label>
            <select
              name="FieldOfStudySSC"
              value={userData["FieldOfStudySSC"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            >
              <option value="">Select your Field</option>
              <option value="Science">Science</option>
              <option value="Arts">Arts</option>
              <option value="Commerce">Commerce</option>
              <option value="Others">Others</option>
            </select>
          </div>
        </div>
        {/* roll, graduation */}
        <div className="flex flex-wrap items-center gap-3 w-full">
          {/* Roll Number */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Roll No. :
            </label>
            <input
              type="text"
              name="RollSSC"
              value={userData["RollSSC"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              placeholder="Type your Roll No. here"
            />
          </div>

          {/* start*/}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              Start :
            </label>
            <input
              type="date"
              name="StartSSC"
              value={userData["StartSSC"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            />
          </div>
          {/* End */}
          <div className="flex items-center gap-3 flex-1">
            <label className="font-medium text-lg whitespace-nowrap">
              End :
            </label>
            <input
              type="date"
              name="EndSSC"
              value={userData["EndSSC"] || ""}
              onChange={handleChange}
              className="h-10 min-w-[150px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ssc;
