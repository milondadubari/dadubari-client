import { useSelector } from 'react-redux';
import { sOrNot } from '../../../Services/findChatOwner';

const MiniProfile = () => {
    const userDetails = useSelector((data)=>data?.users?.data);
    return (
        <div className='bg-white  rounded-lg w-full'>
            <div className='relative'>
                <div className='relative -z-5 '>
                    <img src={userDetails?.cover?.url} className='rounded-t-lg w-full object-cover object-top min-h-[120px]' alt="" />
                </div>
                <img
                    src={userDetails?.avatar?.url}
                    alt="User"
                    className="!w-32 !h-32 object-cover object-top left-1/2 transform -translate-x-1/2  -my-16 border-4 z-10 absolute  border-white rounded-xl"
                />
            </div>
            <div className='md:mt-20 text-center'>
                <h1 className='text-2xl font-medium'>{userDetails?.name}</h1>
                <p className='text-gray-500 mt-1'>@{userDetails?.userid}</p>

                <div className='flex justify-center items-center mt-4 pb-10'>  
                    <p className='text-gray-900'>{`${sOrNot(userDetails?.followers?.length,"Follower")} | ${sOrNot(userDetails?.posts?.length,"Post")} | ${sOrNot(userDetails?.following?.length,"Following")}`}  </p>
                </div>
            </div>
        </div>

    );
};
export default MiniProfile;