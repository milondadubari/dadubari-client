
const UserPreferences = () => {
    return (
        <div className='rounded-lg bg-white p-4 space-y-4 w-full'>
            {/* Personal Preferences */}
            <h1 className='font-medium text-lg pl-4'>Personal Preferences</h1>
            <div className='bg-gray-50 flex-1 rounded-lg p-4'>
            {/* Privacy Settings */}
            <h1 className='font-medium bg-gray-50 rounded-lg'>Privacy Settings: <span className='font-bold'>Coming Soon</span> </h1>
            {/* Notification Preferences */}
            <h1 className='font-medium bg-gray-50 rounded-lg'>Notification Preferences: <span className='font-bold'>Coming Soon</span> </h1>
            </div>
        </div>
    );
};

export default UserPreferences;