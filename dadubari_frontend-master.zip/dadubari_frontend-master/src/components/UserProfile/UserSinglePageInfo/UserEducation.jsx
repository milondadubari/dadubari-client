
const UserEducation = ({data}) => {

  return (
    <div className="rounded-lg bg-white p-4 space-y-4 w-full">
      {/* Education */}
      <h1 className="font-medium text-lg pl-4">Education</h1>
      {/* Job info */}
      <div className="bg-gray-50 flex-1 rounded-lg p-4">
        {/* School / University */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          School / University:{" "}
          <span className="font-bold">
            {data?.school?.trim().length > 0
              ? data?.school?.trim()
              : ""}
          </span>{" "}
        </h1>
        {/* Degree Earned */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Degree Earned :{" "}
          <span className="font-bold">
            {data?.degreeEarn?.trim().length > 0
              ? data?.degreeEarn?.trim()
              : ""}
          </span>{" "}
        </h1>
        {/* Field of study */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Field of study:{" "}
          <span className="font-bold">
            {data?.fieldOfStudy?.trim().length > 0
              ? data?.fieldOfStudy?.trim()
              : ""}
          </span>{" "}
        </h1>
      </div>
    </div>
  );
};

export default UserEducation;
