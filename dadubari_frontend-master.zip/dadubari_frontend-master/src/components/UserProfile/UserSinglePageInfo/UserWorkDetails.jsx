
const UserWorkDetails = ({data}) => {
  
  return (
    <div className="rounded-lg bg-white p-4 space-y-4 w-full">
      {/* Work */}
      <h1 className="font-medium text-lg pl-4">Work & Profession</h1>
      {/* Job info */}
      <div className="bg-gray-50 flex-1 rounded-lg p-4">
        {/* Job title */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Job Title:{" "}
          <span className="font-bold">
            {data?.jobTitle?.trim().length > 0
              ? data?.jobTitle?.trim()
              : ""}
          </span>{" "}
        </h1>
        {/* Company */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Company / Industry :{" "}
          <span className="font-bold">
            {data?.company?.trim().length > 0
              ? data?.company?.trim()
              : ""}
          </span>{" "}
        </h1>
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Job Description:{" "}
          <span className="font-normal">
            {data?.jobDescription?.trim().length > 0
              ? data?.jobDescription?.trim()
              : ""}
          </span>{" "}
        </h1>
      </div>

      <div className="bg-gray-50 flex-1 rounded-lg p-4">
        {/* Job title */}
        <h1 className="font-medium bg-gray-50 rounded-lg">Work History</h1>
        <p>
          {data?.workHistory?.trim().length > 0
            ? data?.workHistory?.trim()
            : ""}
        </p>
      </div>
    </div>
  );
};

export default UserWorkDetails;
