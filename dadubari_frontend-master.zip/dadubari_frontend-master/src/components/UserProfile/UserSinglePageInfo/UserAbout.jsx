
const UserAbout = ({data}) => {
  
  return (
    <div className="rounded-lg bg-white p-4 space-y-4 w-full">
      {/* About */}
      <div>
        <h1 className="font-medium text-lg mb-3 pl-4">About</h1>
        <p className="text-gray-500 bg-gray-50 flex-1 p-4 rounded-lg">
          {data?.aboutYourself?.trim().length > 0
            ? data?.aboutYourself?.trim()
            : ""}
        </p>
      </div>
      {/* Contact Info */}
      <div className="flex flex-wrap gap-3">
        {/* Email */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Email Address</h1>
          <p className="text-gray-500">
            {data?.email?.trim().length > 0
              ? data?.email?.trim()
              : ""}
          </p>
        </div>
        {/* Gender */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Phone Number</h1>
          <p className="text-gray-500">
            {data?.phone?.trim().length > 0
              ? data?.phone?.trim()
              : ""}
          </p>
        </div>
        {/* Date of Birth */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Website</h1>
          <p className="text-gray-500">
            {data?.website && data?.website?.trim().length > 0
              ? data?.website?.trim()
              : ""}
          </p>
        </div>
      </div>
      {/* Other details */}
      <div className="flex flex-wrap gap-3">
        {/* Location */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Location</h1>
          <p className="text-gray-500">
            {data?.location && data?.location?.trim().length > 0
              ? data?.location?.trim()
              : ""}
          </p>
        </div>
        {/* Gender */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Gender</h1>
          <p className="text-gray-500">
            {data?.gender && data?.gender?.trim().length > 0
              ? data?.gender?.trim()
              : ""}
          </p>
        </div>
        {/* Date of Birth */}
        <div className="bg-gray-50 flex-1 p-4 rounded-lg">
          <h1 className="font-medium text-lg">Date of Birth</h1>
          <p className="text-gray-500">
            {data?.DOB && data?.DOB?.trim().length > 0
              ? data?.DOB.split("-").reverse().join("/")
              : ""}
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserAbout;
