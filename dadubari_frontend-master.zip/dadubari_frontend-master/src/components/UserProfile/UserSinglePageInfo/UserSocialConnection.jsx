
const UserSocialConnection = ({data}) => {
  return (
    <div className="rounded-lg bg-white py-4 px-8 space-y-4 w-full">
      {/* Social*/}
      <h1 className="font-medium text-lg mb-3">Social Connections</h1>
      {/* Other details */}
      <div className="flex gap-3 flex-wrap">
        {/* Facebook */}
        <button className="bg-[#1877F2]  px-4 py-3 rounded-lg text-white">
          <a
            href={data?.facebook}
            target="_blank"
            rel="noopener noreferrer"
          >
            Facebook
          </a>
        </button>
        {/* Instagram */}
        <button className="bg-gradient-to-r from-[#962fbf] to-[#d62976] px-4 py-3 rounded-lg text-white">
          <a
            href={data?.instagram}
            target="_blank"
            rel="noopener noreferrer"
          >
            Instagram
          </a>
        </button>
        {/* Youtube */}
        <button className="bg-[#c4302b]  px-4 py-3 rounded-lg text-white">
          <a
            href={data?.youtube}
            target="_blank"
            rel="noopener noreferrer"
          >
            Youtube
          </a>
        </button>
        {/* Linkedin */}
        <button className="bg-[#0072b1]  px-4 py-3 rounded-lg text-white">
          <a
            href={data?.linkedin}
            target="_blank"
            rel="noopener noreferrer"
          >
            {" "}
            Linkedin
          </a>
        </button>
      </div>
    </div>
  );
};

export default UserSocialConnection;
