
const UserInterests = ({data}) => {
  return (
    <div className="rounded-lg bg-white p-4 space-y-4 w-full">
      {/* Interests & Hobbies */}
      <h1 className="font-medium text-lg pl-4">Interests & Hobbies</h1>
      <div className="bg-gray-50 flex-1 rounded-lg p-4">
        {/* Interests */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Interests:{" "}
          <span className="font-bold">
            {data?.interests?.trim().length > 0
              ? data?.interests?.trim()
              : ""}
          </span>{" "}
        </h1>
        {/* Hobbies / Passions */}
        <h1 className="font-medium bg-gray-50 rounded-lg">
          Hobbies / Passions :{" "}
          <span className="font-bold">
            {data?.hobbies?.trim().length > 0
              ? data?.hobbies?.trim()
              : ""}
          </span>{" "}
        </h1>
      </div>
    </div>
  );
};

export default UserInterests;
