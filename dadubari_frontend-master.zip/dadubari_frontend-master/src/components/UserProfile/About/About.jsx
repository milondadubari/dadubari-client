import { useContext } from "react";
import UserAbout from "../UserSinglePageInfo/UserAbout";
import UserEducation from "../UserSinglePageInfo/UserEducation";
import UserInterests from "../UserSinglePageInfo/UserInterests";
import UserPreferences from "../UserSinglePageInfo/UserPreferences";
import UserSocialConnection from "../UserSinglePageInfo/UserSocialConnection";
import UserWorkDetails from "../UserSinglePageInfo/UserWorkDetails";
import { aboutContext } from "../../../context/AboutContext";

const About = () => {
  const {about} = useContext(aboutContext);
  return (
    <div className="flex items-center justify-center">
      <div className="space-y-3 container">
        <UserAbout data={about}/>
        <UserWorkDetails data={about}/>
        <UserEducation data={about}/>
        <UserInterests data={about}/>
        <UserPreferences data={about}/>
        <UserSocialConnection data={about}/>
      </div>
    </div>
  );
};

export default About;
