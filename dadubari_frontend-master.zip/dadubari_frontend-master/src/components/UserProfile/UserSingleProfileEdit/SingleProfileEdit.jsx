import { useState } from "react";
import uploadImage from "../../../icons/svg/uploadImage.svg";
import axiosInstance from "../../../services";
import { useDispatch } from "react-redux";
import { toastDesign, userLoginCheck } from "../../../Reducers/userReducers/userSlice";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
const SingleProfileEdit = () => {
  const [formData, setFormData] = useState({
    aboutYourself: "",
    phone: "",
    website: "",
    location: "",
    gender: "",
    DOB: "",
    jobTitle: "",
    company: "",
    jobDescription: "",
    workHistory: "",
    school: "",
    degreeEarn: "",
    fieldOfStudy: "",
    interests: "",
    hobbies: "",
    facebook: "",
    instagram: "",
    youtube: "",
    linkedin: "",
  });

  const [avatar, setAvatar] = useState("");
  const [cover, setCover] = useState("");

  const { facebook, instagram, youtube, linkedin } = formData;

  //!profile change
  const handleProfileChange = (e) => {
    const file = e.target.files[0];

    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        setAvatar(Reader.result);
      }
    };
  };


  //!cover change
  const handleCoverChange = (e) => {
    const file = e.target.files[0];

    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        setCover(Reader.result);
      }
    };
  };


  //!hooks
  const dispatch = useDispatch();


  //!file handling function
  const handleSubmit = async (e) => {
    e.preventDefault();
    let newFormData = { ...formData, avatar: avatar, cover: cover };
    try {
      const res = await axiosInstance.patch(
        "/api/v1/update-user-details",
        newFormData,
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("dadubari")}`,
          },
        }
      );
      dispatch(userLoginCheck());
      toast.success("User details updated", toastDesign);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="container mx-auto space-x-3 px-3 my-3 min-h-screen">
      <div className="bg-white p-3 rounded-lg">
        {/* Edit from start here */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {/*profile,cover */}
          <div className="flex gap-3 flex-wrap">
            {/* Upload profile image start */}
            <div>
              <label htmlFor="fileInputAvatar" className="cursor-pointer">
                {avatar && <img src={avatar} />}
                <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                  <img className="w-5" src={uploadImage} alt="" /> Upload
                  Profile Image
                </div>
              </label>
              <input
                type="file"
                id="fileInputAvatar"
                accept="image/*"
                onChange={handleProfileChange}
                className="opacity-0 hidden"
              />
            </div>
            {/* Upload profile image end */}
            {/* Upload Cover image start */}
            <div>
              <label htmlFor="fileInputCover" className="cursor-pointer">
                {cover && <img src={cover} />}
                <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                  <img className="w-5" src={uploadImage} alt="" /> Upload Cover
                  Image
                </div>
              </label>
              <input
                type="file"
                id="fileInputCover"
                accept="image/*"
                onChange={handleCoverChange}
                className="opacity-0 hidden"
              />
            </div>
            {/* Upload Cover image end */}
          </div>
          {/* About yourself edit form */}
          <div className="space-y-3">
            <label className="font-medium text-lg whitespace-nowrap">
              About Yourself :
            </label>
            <textarea
              className="h-24 bg-gray-100 rounded-md w-full p-3 text-gray-800 focus:outline-none"
              placeholder="Tell me about yourself"
              onChange={(e) =>
                setFormData({ ...formData, aboutYourself: e.target.value })
              }
            />
          </div>
          {/* Email, PhoneNumber, Website */}
          <div className="flex flex-wrap items-center gap-3 w-full">
            {/* Phone Number */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Phone Number :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Type your Number"
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
              />
            </div>
            {/* Website */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Website :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your website"
                onChange={(e) =>
                  setFormData({ ...formData, website: e.target.value })
                }
              />
            </div>
          </div>
          {/* Location, Gender, Date of Birth */}
          <div className="flex flex-wrap items-center gap-3 w-full">
            {/* Location */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Location :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Location"
                onChange={(e) => {
                  setFormData({ ...formData, location: e.target.value });
                }}
              />
            </div>

            {/* Gender */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Gender :
              </label>
              <select
                onChange={(e) => {
                  setFormData({ ...formData, gender: e.target.value });
                }}
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
              >
                <option value="">Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="others">Others</option>
              </select>
            </div>
            {/* Date of Birth */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Date of Birth :
              </label>
              <input
                type="date"
                onChange={(e) => {
                  setFormData({ ...formData, DOB: e.target.value });
                }}
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your website"
              />
            </div>
          </div>
          {/* Work & profession */}
          <div className="space-y-3">
            <h1 className="font-medium text-lg">Work & Profession :</h1>
            <div className="flex flex-wrap items-center gap-3 w-full">
              {/* Job title */}
              <div className="flex items-center gap-3 flex-1">
                <label className="font-medium text-lg whitespace-nowrap">
                  Job title :
                </label>
                <input
                  type="text"
                  className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                  placeholder="Enter your Job Title"
                  onChange={(e) =>
                    setFormData({ ...formData, jobTitle: e.target.value })
                  }
                />
              </div>
              {/* Company */}
              <div className="flex items-center gap-3 flex-1">
                <label className="font-medium text-lg whitespace-nowrap">
                  Company/Industry :
                </label>
                <input
                  type="text"
                  className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                  placeholder="Enter your Company Name"
                  onChange={(e) =>
                    setFormData({ ...formData, company: e.target.value })
                  }
                />
              </div>
              {/* Job Description */}
              <div className="flex items-center gap-3 flex-1">
                <label className="font-medium text-lg whitespace-nowrap">
                  Job description :
                </label>
                <input
                  type="text"
                  className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                  placeholder="Enter your job description"
                  onChange={(e) =>
                    setFormData({ ...formData, jobDescription: e.target.value })
                  }
                />
              </div>
            </div>
          </div>
          {/* Work History */}
          <div className="space-y-3">
            <label className="font-medium text-lg whitespace-nowrap">
              Work History :
            </label>
            <textarea
              className="h-24 bg-gray-100 rounded-md w-full p-3 text-gray-800 focus:outline-none"
              placeholder="You work history..."
              onChange={(e) =>
                setFormData({ ...formData, workHistory: e.target.value })
              }
            />
          </div>
          {/* Education */}
          <div className="flex flex-wrap items-center gap-3 w-full">
            {/* School */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                School / University :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your School/University Name"
                onChange={(e) =>
                  setFormData({ ...formData, school: e.target.value })
                }
              />
            </div>
            {/* Degree Earn */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Degree Earn :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Degree Name"
                onChange={(e) =>
                  setFormData({ ...formData, degreeEarn: e.target.value })
                }
              />
            </div>
            {/* Field of Study  */}
            <div className="flex items-center gap-3 flex-1">
              <label className="font-medium text-lg whitespace-nowrap">
                Field of study :
              </label>
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Field of study"
                onChange={(e) =>
                  setFormData({ ...formData, fieldOfStudy: e.target.value })
                }
              />
            </div>
          </div>
          {/* Interest & Hobbies */}
          <div className="space-y-3">
            <h1 className="font-medium text-lg">Interest & Hobbies :</h1>
            <div className="flex flex-wrap items-center gap-3 w-full">
              {/* Interests */}
              <div className="flex items-center gap-3 flex-1">
                <label className="font-medium text-lg whitespace-nowrap">
                  Interests :
                </label>
                <input
                  type="text"
                  className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                  placeholder="Enter your Interests"
                  onChange={(e) =>
                    setFormData({ ...formData, interests: e.target.value })
                  }
                />
              </div>
              {/* Hobbies / Passions */}
              <div className="flex items-center gap-3 flex-1">
                <label className="font-medium text-lg whitespace-nowrap">
                  Hobbies / Passions:
                </label>
                <input
                  type="text"
                  className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                  placeholder="Enter your Hobbies"
                  onChange={(e) =>
                    setFormData({ ...formData, hobbies: e.target.value })
                  }
                />
              </div>
            </div>
          </div>
          {/* Social Connection */}
          <div className="space-y-3">
            <h1 className="font-medium text-lg">Social Connections :</h1>
            <div className="flex flex-wrap items-center gap-3 w-full">
              {/* Facebook */}
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Facebook profile"
                name="facebook"
                value={facebook}
                onChange={(e) =>
                  setFormData({ ...formData, [e.target.name]: e.target.value })
                }
              />
              {/* Instagram */}
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Instagram profile"
                name="instagram"
                value={instagram}
                onChange={(e) =>
                  setFormData({ ...formData, [e.target.name]: e.target.value })
                }
              />
              {/* Youtube */}
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Youtube profile"
                name="youtube"
                value={youtube}
                onChange={(e) =>
                  setFormData({ ...formData, [e.target.name]: e.target.value })
                }
              />
              {/* Linkedin */}
              <input
                type="text"
                className="h-10 min-w-[200px] bg-gray-100 rounded-md w-full px-4 text-gray-800 focus:outline-none"
                placeholder="Enter your Linkdin profile"
                name="linkedin"
                value={linkedin}
                onChange={(e) =>
                  setFormData({ ...formData, [e.target.name]: e.target.value })
                }
              />
            </div>
          </div>

          <button
            type="submit"
            className="block w-full bg-indigo-600 mt-5 py-2 rounded-2xl text-white font-semibold mb-2"
          >
            Save
          </button>
        </form>
      </div>
    </div>
  );
};

export default SingleProfileEdit;
