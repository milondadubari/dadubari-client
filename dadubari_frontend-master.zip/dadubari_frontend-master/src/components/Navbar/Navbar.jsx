import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import homeIcon from "../../icons/svg/homeIcon.svg";
import searchIcon from "../../icons/svg/searchIcon.svg";
import createIcon from "../../icons/svg/createIcon.svg";
import corporateIcon from "../../icons/svg/corporateIcon.svg";
import closeIcon from "../../icons/svg/closeIcon.svg";
import friendReq from "../../icons/svg/friendReq.svg";
import chatIcon from "../../icons/svg/chatIcon.svg";
import notificationIcon from "../../icons/svg/notificationIcon.svg";

import { useSelector } from "react-redux";
import LeftSidebar from './../Sidebar/LeftSidebar/LeftSidebar';
const Navbar = () => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };
  //! dropdown search
  const toggleSearch = () => {
    setIsOpen((prev) => !prev);
  };

  const dropdownRef = useRef(null);

  const closeDropdownOnClickOutside = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setDropdownOpen(false);
    }
  };
  // menu modal
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  useEffect(() => {
    document.addEventListener("click", closeDropdownOnClickOutside);
    return () =>
      document.removeEventListener("click", closeDropdownOnClickOutside);
  }, []);

  const [search, setSearch] = useState("");

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = () => {
    console.log("Search query:", search);
  };
  const navigate = useNavigate();
  const logOutHandler = () => {
    localStorage.removeItem("dadubari");
    navigate("/login");
  };
  const userDetails = useSelector((da) => da?.users?.data);

  return (
    <nav className="bg-gradient-to-tr from-blue-800 to-purple-700 p-2 sticky top-0 z-50">
      <div className="container mx-auto flex justify-between  items-center pr-3">
        {/* logo */}
        <div className="text-white text-xl font-bold ml-5">
          <Link>
            <img
              className="w-12 md:w-16"
              src="https://i.ibb.co/cJhTWSC/dadubari-logo.png"
              alt=""
            />
          </Link>
        </div>
        <div className="hidden md:flex  items-center space-x-6">
          {/* home */}
          <Link
            to={`/`}
            className="text-white border p-2 rounded-md transition ease-in-out delay-50 hover:bg-indigo-500 hover:border-indigo-500  transform duration-500 hover:-translate-y-1 hidden lg:block"
          >
            <div className="flex gap-1 items-center">
              <img className="h-5" src={homeIcon} alt="" />
              Home
            </div>
          </Link>
          {/* Create */}
          {/* <a
            href="#"
            className="text-white  border p-2 rounded-md transition ease-in-out delay-50 hover:bg-indigo-500 hover:border-indigo-500 transform duration-500 hover:-translate-y-1 hidden lg:block"
          >
            <div className="flex gap-2 items-center">
              <img src={createIcon} className="h-5" alt="" />
              Create
            </div>
          </a> */}
          {/* Service */}
          <Link to={'/corporate/account'}
            href="#"
            className="text-white  border p-2 rounded-md transition ease-in-out delay-50 hover:bg-indigo-500 hover:border-indigo-500 transform duration-500 hover:-translate-y-1 hidden lg:block"
          >
            <div className="flex gap-2 items-center">
              <img src={corporateIcon} className="h-5" alt="" />
              Corporate
            </div>
          </Link>
          {/* Search field */}
          <div className="flex items-center max-w-md mx-auto bg-white rounded-l-md rounded-r-lg">
            <div className="w-full">
              <input
                type="search"
                className="w-60 px-4 text-gray-800 focus:outline-none"
                placeholder="Search"
                value={search}
                onChange={handleSearchChange}
              />
            </div>
            <div>
              <button
                type="button"
                className={`flex items-center justify-center w-11 h-11 text-white rounded-r-md ${
                  search.length > 0
                    ? "bg-indigo-500"
                    : "bg-violet-500 cursor-not-allowed"
                }`}
                onClick={handleSearchSubmit}
                disabled={search.length === 0}
              >
                <img src={searchIcon} className="h-6" alt="" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex !items-center gap-5 md:gap-10">
          <div className="flex !items-center space-x-5">
            {/* Friend Request */}
            <Link to={"/Coming-soon"}
              href="#"
              className="text-white transform duration-500 hover:-translate-y-1 hidden sm:block"
            >
              <img src={friendReq} className="h-6" alt="" />
            </Link>
            {/* //!Mobile search bar start */}
            <div className="relative sm:hidden">
              <button onClick={toggleSearch} className="text-white">
                <img src={searchIcon} className="h-6" alt="" />
              </button>
              {isOpen && (
                <dialog open={isOpen} onClose={console.log("onClose")}>
                  <div className=" absolute top-10 -left-10 rounded-md bg-white ring-1 focus:outline-none">
                    <div className="flex items-center max-w-md mx-auto  rounded-l-md rounded-r-lg">
                      <div className="w-full">
                        <input
                          type="search"
                          className="w-36 px-4 text-gray-800 focus:outline-none"
                          placeholder="Search"
                          value={search}
                          onChange={handleSearchChange}
                        />
                      </div>
                      <div>
                        <button
                          type="button"
                          className={`flex items-center justify-center w-10 h-9 text-white rounded-r-md ${
                            search.length > 0
                              ? "bg-indigo-500"
                              : "bg-violet-500 cursor-not-allowed"
                          }`}
                          onClick={handleSearchSubmit}
                          disabled={search.length === 0}
                        >
                          <img src={searchIcon} className="h-5" alt="" />
                        </button>
                      </div>
                    </div>
                  </div>
                </dialog>
              )}
            </div>
            {/* Mobile search bar end */}
            {/* Chat */}
            <Link to={'/message/m'}
              href="#"
              className="text-white transform duration-500 hover:-translate-y-1"
            >
              <img src={chatIcon} className="h-6" alt="" />
            </Link>
            {/* Notification */}
            <Link to={"/Coming-soon"}
              href="#"
              className="text-white transform duration-500 hover:-translate-y-1"
            >
              <img src={notificationIcon} className="h-6" alt="" />
            </Link>
          </div>
          <div className="relative" ref={dropdownRef}>
            <button
              className="text-white flex items-center gap-4"
              onClick={toggleDropdown}
            >
              <img
                src={userDetails?.avatar?.url}
                alt="User"
                className="w-11 h-11 object-cover object-top rounded-xl"
              />
            </button>
            {/* Drop down code start */}
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-300 z-50 rounded-lg shadow-lg py-2 space-y-2">
                <div className="px-4 ">
                  <img
                    src={userDetails?.avatar?.url}
                    alt="User"
                    className="w-10 h-10 object-cover object-top rounded-xl mx-auto"
                  />
                </div>
                <div className="text-center font-semibold">
                  {userDetails?.name}
                </div>
                <hr />
                <Link
                  to={`/profile`}
                  className="block px-4 py-2 hover:bg-gray-100 transform duration-500 hover:-translate-y-1"
                  onClick={() => setDropdownOpen(false)}
                >
                  My Profile
                </Link>
                <button
                  href="#"
                  className=" block md:hidden px-4 py-2 hover:bg-gray-100 transform duration-500 hover:-translate-y-1"
                  onClick={() => {
                    openModal();
                    setDropdownOpen(false);
                  }}
                >
                  Menu
                </button>
                <Link to={"/Coming-soon"}
                  className="block px-4 py-2 hover:bg-gray-100 transform duration-500 hover:-translate-y-1"
                  onClick={() => setDropdownOpen(false)}
                >
                  General Setting
                </Link>
                <Link to={"/Users-Terms-And-Condition"}
                  className="block px-4 py-2 hover:bg-gray-100 transform duration-500 hover:-translate-y-1"
                  onClick={() => setDropdownOpen(false)}
                >
                  Terms & Condition
                </Link>
                <hr />
                <span
                  onClick={logOutHandler}
                  className="block px-4 py-2 hover:bg-gray-100 transform duration-500 hover:-translate-y-1"
                >
                  Log Out
                </span>
              </div>
            )}
            {/* menu modal */}
            {isModalOpen && (
          <div className="fixed z-10 inset-0 lg:top-20 top-16 overflow-y-auto flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-gray-100 rounded-lg p-4 md:p-8 antialiased max-h-[80vh] md:max-h-[70vh] w-[90vw] md:w-[60vw] overflow-y-scroll relative">
              {/* <button onClick={closeModal}><img className="h-7 transform duration-500 hover:-translate-y-1 absolute right-10" src={closeIcon} alt="" /></button>  */}
            <LeftSidebar/>
            </div>  
          
          </div>

        )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
