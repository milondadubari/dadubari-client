import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const JobApplicantProfile = () => {
  const data = useSelector((data)=>data?.users?.data);
  return (
    <div className="rounded-lg bg-white p-4 space-y-4 w-full">
      {/* About */}
      {/* About info */}
      <div>
        <div className="flex justify-between">
          <div>
            <h1 className="font-medium text-2xl mb-3 pl-4">Personal Details</h1>
          </div>
          <div className="flex gap-3">
            <button className="block mx-auto bg-indigo-600 rounded-2xl text-white font-semibold mb-2">
              <Link className=" py-2 px-16" to="/resume">Edit</Link>
            </button>
            <button className="block px-16 mx-auto bg-purple-600 py-2 rounded-2xl text-white font-semibold mb-2">
              Resume
            </button>
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between bg-gray-50 rounded-lg">
            <div className="p-4 space-y-2">
              <p className="text-gray-500 text-lg flex-1">
                Name: <span className="text-black">{data?.fullName}</span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                Father Name:{" "}
                <span className="text-black">{data?.fatherName}</span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                Mother Name:{" "}
                <span className="text-black">{data?.motherName}</span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                NID No: <span className="text-black">{data?.NID}</span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                Date Of Birth:{" "}
                <span className="text-black">
                  {data?.DOBJob?.split("-").reverse().join("/")}
                </span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                Phone Number:{" "}
                <span className="text-black">{data?.phoneNumber}</span>
              </p>
              <p className="text-gray-500 text-lg flex-1">
                Email:{" "}
                <span className="text-black">
                  {data?.emailJob || data?.email}
                </span>
              </p>
            </div>
            <div>
              <img
                src={data?.avatar?.url}
                className="w-56 m-4"
                alt="image"
              />
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-gray-500 text-lg flex-1">
              Professional Summary:{" "}
              <span className="text-black">{data?.professionalSummary}</span>
            </p>
          </div>
        </div>
      </div>
      {/* Education */}
      <div>
        <h1 className="font-medium text-2xl mb-3 pl-4">Education</h1>
        <div className="space-y-3">
          <div className="p-4 flex justify-between space-y-2 bg-gray-50 rounded-lg">
            {/* <div><p className="text-gray-500 text-lg flex-1">
                            Degree: <span className='text-black'>Computer Science & Engineering</span>
                        </p>
                        <p className="text-gray-500 text-lg flex-1">
                            Institute Name: <span className='text-black'>Dhaka University</span>
                        </p>
                        <p className="text-gray-500 text-lg flex-1">
                        Institute Location: <span className='text-black'>12/2/2016</span>
                        </p>
                        <p className="text-gray-500 text-lg flex-1">
                        Field Of Study: <span className='text-black'>Computer</span>
                        </p>
                        <p className="text-gray-500 text-lg flex-1">
                        Roll / Reg. No. : <span className='text-black'>765337</span>
                        </p>
                        <p className="text-gray-500 text-lg flex-1">
                        Your Skills : <span className='text-black'>Programming , Data management , Freelancing</span>
                        </p></div>
                        <h3 className='font-bold'>2012-2016</h3> */}
            <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
              <table className="w-full text-gray-500">
                <thead className="text-base text-left text-gray-700 uppercase bg-gray-100">
                  <tr>
                    <th scope="col" className="px-10 py-3">
                      Degree / Certificate
                    </th>
                    <th scope="col" className="px-10 py-3">
                      Institute Name
                    </th>
                    <th scope="col" className="px-10 py-3">
                      Field of Study
                    </th>
                    <th scope="col" className="px-10 py-3">
                      Grading
                    </th>
                    <th scope="col" className="px-10 py-3">
                      Year of Passing
                    </th>
                  </tr>
                </thead>
                <tbody className="text-left">
                  <tr className="odd:bg-white even:bg-gray-50 dark:border-gray-700">
                    <th
                      scope="row"
                      className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"
                    >
                      Master&apos;s
                    </th>
                    <td className="px-6 py-4">{data?.InstituteNameMSC}</td>
                    <td className="px-6 py-4">{data?.FieldOfStudyMSC}</td>
                    <td className="px-6 py-4">{data?.GradeMSC}</td>
                    <td className="px-6 py-4">{data?.EndMSC?.split("-")[2]}</td>
                  </tr>
                  <tr className="odd:bg-white even:bg-gray-50 dark:border-gray-700">
                    <th
                      scope="row"
                      className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"
                    >
                      Honurs
                    </th>
                    <td className="px-6 py-4">{data?.InstituteNameBSC}</td>
                    <td className="px-6 py-4">{data?.FieldOfStudyBSC}</td>
                    <td className="px-6 py-4">{data?.GradeBSC}</td>
                    <td className="px-6 py-4">{data?.EndBSC?.split("-")[2]}</td>
                  </tr>
                  <tr className="odd:bg-white even:bg-gray-50 dark:border-gray-700">
                    <th
                      scope="row"
                      className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"
                    >
                      HSC
                    </th>
                    <td className="px-6 py-4">{data?.InstituteNameHSC}</td>
                    <td className="px-6 py-4">{data?.FieldOfStudyHSC}</td>
                    <td className="px-6 py-4">{data?.GradeHSC}</td>
                    <td className="px-6 py-4">{data?.EndHSC?.split("-")[2]}</td>
                  </tr>
                  <tr className="odd:bg-white even:bg-gray-50 dark:border-gray-700">
                    <th
                      scope="row"
                      className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"
                    >
                      SSC
                    </th>
                    <td className="px-6 py-4">{data?.InstituteNameSSC}</td>
                    <td className="px-6 py-4">{data?.FieldOfStudySSC}</td>
                    <td className="px-6 py-4">{data?.GradeSSC}</td>
                    <td className="px-6 py-4">{data?.EndSSC?.split("-")[2]}</td>
                  </tr>

                  {/* Other rows follow with similar structure */}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      {/* Work Experience */}
      <div>
        <h1 className="font-medium text-2xl mb-3 pl-4">Work Experience</h1>
        <div className="space-y-3">
          <div className="p-4 space-y-2 bg-gray-50 rounded-lg">
            <p className="text-gray-500 text-lg flex-1">
              Job Title: <span className="text-black">{data?.jobTitleJob}</span>
            </p>
            <p className="text-gray-500 text-lg flex-1">
              Company: <span className="text-black">{data?.companyJob}</span>
            </p>
            <p className="text-gray-500 text-lg flex-1">
              Job Start:{" "}
              <span className="text-black">
                {data?.jobStart?.split("-").reverse().join("/")}
              </span>
            </p>
            <p className="text-gray-500 text-lg flex-1">
              Job End:{" "}
              <span className="text-black">
                {data?.jobEnd?.split("-").length === 0
                  ? data.jobEnd
                  : data?.jobEnd?.split("-").reverse().join("/")}
              </span>
            </p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-gray-500 text-lg flex-1">
              Job Description:{" "}
              <span className="text-black">{data?.Description}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobApplicantProfile;
