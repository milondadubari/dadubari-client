
const Footer = () => {
  return (
    <div className='container mx-auto py-3 bg-white rounded-lg space-y-1'>
      <p className='text-center '>Select language: <span className='font-medium tracking-wide'>English(UK) বাংলা অসমীয়া हिन्दी</span>  </p>
      <p className='text-center '>Copyrights 2023 | All rights reserved by <span className='font-semibold'>DaduBari</span></p>
      
    </div>
  )
}

export default Footer