import React, { useState } from 'react';
import { QrReader } from 'react-qr-reader';


const QRScanner = () => {
  const [result, setResult] = useState('No result');

  const handleScan = (data) => {
    if (data) {
      setResult(data);
    }
  };

  const handleError = (err) => {
    console.error(err);
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-200">
      <QrReader
        delay={300}
        onError={handleError}
        onScan={handleScan}
        style={{ width: '300px' }} // Adjust the width as needed
      />
      <p className="mt-4 text-lg">{result}</p>
    </div>
  );
};

export default QRScanner;
