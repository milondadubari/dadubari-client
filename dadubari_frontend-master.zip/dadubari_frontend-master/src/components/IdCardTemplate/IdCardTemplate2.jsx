import React from 'react';
import QRCode from "qrcode.react";
import emailIcon from "../../icons/svg/emailIcon.svg";
import phoneOneIcon from "../../icons/svg/phoneIcon.svg"
import addressIcon from "../../icons/svg/addressIcon.svg";
import websiteIcon from "../../icons/svg/websiteIcon.svg";
const IdCardTemplate2 = () => {
    return (
            <div
              className="h-[550px] w-[340px] p-5 space-y-5 flex flex-col justify-center bg-no-repeat bg-cover bg-violet-200 "
            >
                {/* first part */}
                <div className="flex items-center justify-center gap-3 mt-3">
                  {/* Company logo goes here */}
                  <img
                    src= "https://i.ibb.co/SJ8T8mq/dadubari-logo.png"
                    className="h-20 w-20 "
                    alt="Company Logo"
                  />
                  {/* Company Name Goes Here */}
                  <div>
                    <h1 className="text-lg font-semibold">
                      Web Solution
                    </h1>
                    <p className="text-sm">All your service</p>
                  </div>
                </div>
              {/* 2nd part */}
              <div className="flex justify-between">
                {/* profile Image */}
                <div>
                  <img
                    className="w-36 object-cover rounded-md"
                    src= "https://i.ibb.co/BL2FBLK/shadow.png"
                    alt=""
                  />
                </div>
                {/* Qr Code */}
                <div className="flex items-center">
                  <QRCode
                    className="bg-white p-1 rounded-lg"
                    // value={generateQRCode()}
                    size={140}
                  />
                </div>
                
              </div>
              {/* 3rd part*/}
              <div className="flex flex-col justify-between">
              
                {/* Profile Data */}
                <div className="w-60">
                  <h1 className="text-xl font-semibold">Shamsu Uddin</h1>
                  <h4 className="text-sm mb-1">Web Developer</h4>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={emailIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">email@shamsu.info</p>
                  </p>
                  
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={phoneOneIcon}
                      alt=""
                    />
                    <div>
                    <p>+008823764385</p>
                    <p className="mb-4">+9009872345</p>
                    </div>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={addressIcon}
                      alt=""
                    />
                    <p className="mb-4">Narshingdi, Bangladesh</p>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={websiteIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">www.shamsu.info</p>
                  </p>
                </div>
                
              </div>
            </div>
    );
};

export default IdCardTemplate2;