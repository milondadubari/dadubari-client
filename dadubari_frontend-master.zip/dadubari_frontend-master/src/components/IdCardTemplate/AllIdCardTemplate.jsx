import React from 'react';
import IdCardTemplate1 from './IdCardTemplate1';
import IdCardTemplate2 from './IdCardTemplate2';

const AllIdCardTemplate = () => {
    return (
        <div className="space-y-10">
            <h1 className="text-2xl font-bold border-b-4 text-center w-60 mx-auto pb-2 mb-10 border-black">Choose A Template</h1>
            <div className="flex flex-wrap gap-5">
            <IdCardTemplate1 />
            <IdCardTemplate2 />

            </div>
        </div>
    );
};

export default AllIdCardTemplate;