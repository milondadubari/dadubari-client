import React from 'react';
import QRCode from "qrcode.react";
import emailIcon from "../../icons/svg/emailIcon.svg";
import phoneOneIcon from "../../icons/svg/phoneIcon.svg"
import addressIcon from "../../icons/svg/addressIcon.svg";
import websiteIcon from "../../icons/svg/websiteIcon.svg";
const IdCardTemplate1 = () => {
    return (
            <div
              className="h-[340px] w-[550px] p-5 flex gap-28 bg-no-repeat bg-cover"
              style={{
                backgroundImage: `url('https://i.ibb.co/Rz6qBxQ/card-temlate1.jpg')`,
              }}
            >
              {/* left part */}
              <div className="flex flex-col items-center justify-between">
                {/* profile Image */}
                <div>
                  <img
                    className="w-36 object-cover rounded-md"
                    src= "https://i.ibb.co/BL2FBLK/shadow.png"
                    alt=""
                  />
                </div>
                {/* Qr Code */}
                <div className="flex items-center">
                  <QRCode
                    className="bg-white p-1 rounded-lg"
                    // value={generateQRCode()}
                    size={140}
                  />
                </div>
                
              </div>
              {/* right part*/}
              <div className="flex flex-col justify-between items-end">
              <div className="flex gap-3">
                  {/* Company logo goes here */}
                  <img
                    src= "https://i.ibb.co/SJ8T8mq/dadubari-logo.png"
                    className="h-14 w-14 "
                    alt="Company Logo"
                  />
                  {/* Company Name Goes Here */}
                  <div>
                    <h1 className="text-lg font-semibold">
                      Web Solution
                    </h1>
                    <p className="text-sm">All your service</p>
                  </div>
                </div>
                {/* Profile Data */}
                <div className="w-60">
                  <h1 className="text-xl font-semibold">Shamsu Uddin</h1>
                  <h4 className="text-sm mb-1">Web Developer</h4>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={emailIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">email@shamsu.info</p>
                  </p>
                  
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={phoneOneIcon}
                      alt=""
                    />
                    <div>
                    <p>+008823764385</p>
                    <p className="mb-4">+9009872345</p>
                    </div>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={addressIcon}
                      alt=""
                    />
                    <p className="mb-4">Narshingdi, Bangladesh</p>
                  </p>
                  <p className="flex items-center mb-[-10px]">
                    <img
                      className="inline-block h-5 mr-2"
                      src={websiteIcon}
                      alt=""
                    />{" "}
                    <p className="mb-[18px]">www.shamsu.info</p>
                  </p>
                </div>
                
              </div>
            </div>
    );
};

export default IdCardTemplate1;