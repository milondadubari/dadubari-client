import React from 'react';
import { Link } from "react-router-dom";
import canvasVerifyIcon from "../../../../src/icons/svg/canvasVerifyIcon.svg"
import whatsappIcon from "../../../../src/icons/svg/whatsappIcon.svg";
import favoriteIcon from "../../../../src/icons/svg/favoriteIcon.svg";
import messageIcon from "../../../../src/icons/svg/messageIcon.svg";
const CanvasUserDetails = () => {
    return (
        <div
        className="rounded-lg"
        style={{
          backgroundImage: `url(https://i.ibb.co/TPGFMqQ/cover-OIG-Z1-Z.jpg)`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* cover photo and profile picture */}
        <div className="h-2/5 pt-40 pb-5 px-5 flex justify-between">
          {/* Profile info */}
          <div className="flex flex-col md:flex-row gap-2 items-start md:items-center md:gap-6">
            <img
              src="https://i.ibb.co/sK6H3gK/Mercedes-Benz-GLS.jpg"
              className="rounded-xl w-20 h-20 object-cover object-top md:w-32 md:h-32 "
              alt=""
            />
            <div className="space-y-1">
              <h1 className="text-xl md:text-3xl font-medium text-white flex ">
                Car Hat <img src={canvasVerifyIcon} alt="" />
              </h1>
              <p className="text-gray-200 text-sm"> Car Selling Company BD</p>
              <p className="text-gray-200"> @userid55887</p>
            </div>
          </div>
          {/* Edit & Activities */}
          <div className="flex flex-col md:flex-row gap-3 justify-center md:justify-normal items-end">
            <Link>
              <button className="text-black px-2 md:px-6 py-2 rounded-xl bg-white flex items-center gap-1.5 font-medium transform duration-500 hover:-translate-y-1">
                <img src={whatsappIcon} className="h-6" alt="" />{" "}
                <span className="hidden md:block"> Whatsapp</span>
              </button>
            </Link>
            <button className="text-black px-2 md:px-4 py-2 rounded-xl bg-white flex items-center gap-1.5 font-medium transform duration-500 hover:-translate-y-1">
              <img src={favoriteIcon} className="h-6" alt="" />
              <span className="hidden md:block">Favorite</span>
            </button>
            <button className="text-black px-2 md:px-4 py-2 rounded-xl bg-white flex items-center gap-1.5 font-medium transform duration-500 hover:-translate-y-1">
              <img src={messageIcon} className="h-6" alt="" />
              <span className="hidden md:block">Instant Message</span>
            </button>
          </div>
        </div>
        {/* Profile details */}
      </div>
    );
};

export default CanvasUserDetails;