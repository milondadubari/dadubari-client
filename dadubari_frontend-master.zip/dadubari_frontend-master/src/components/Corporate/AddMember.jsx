import { useState } from "react";
import { toast } from 'react-toastify';
import axiosInstance from "../../services";
import { authorization } from "../../utils/authorization";

const AddMember = ({isModalOpen, setIsModalOpen, id}) => {
    const [data,setData] = useState({});

    const handleChange=(e)=>{
        const {name , value} = e.target;
        setData({...data, [name] : value});
    }
    const handleAddMember = async(e) => {
        e.preventDefault();
        if(!data.userid){
            toast.warn("Add an user id")
            return;
        }else if (data.userid?.trim().length === 0){
            toast.warn("Add an user id")
            return;
        }
         
        try {
            const res = await axiosInstance.post(`api/v4/corporate/profile/add-member/${id}`, data, authorization);
            if(res?.status===200){
                toast.success("member added successfully");
                setIsModalOpen(false);
            }
        } catch (error) {
            toast.error(error?.response?.data?.message);
        }
    };
  return (
    <div>              
        {isModalOpen && (
        <div className="fixed z-10 inset-0 lg:top-20 top-16 overflow-y-auto flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg p-5 lg:w-96">
                <h2 className="text-2xl font-semibold mb-4">Add Member</h2>
                <form onSubmit={handleAddMember} className="space-y-4">
                    <div className="flex flex-col">
                        <label htmlFor="userId" className="mb-1 font-medium text-gray-800">User ID</label>
                        <input type="text" id="userId" name='userid' value={data['userid'] || ""} onChange={handleChange} className="border rounded-md px-3 py-1 focus:outline-none" />
                    </div>
                    <div className="flex flex-col">
                        <label htmlFor="officialId" className="mb-1 font-medium text-gray-800">Official ID</label>
                        <input type="text" id="officialId" name='officialId' value={data['officialId'] || ""} onChange={handleChange} className="border rounded-md px-3 py-1 focus:outline-none" />
                    </div>
                    <div className="flex flex-col">
                        <label htmlFor="position" className="mb-1 font-medium text-gray-800">Position</label>
                        <input type="text" id="position" name='position' value={data['position'] || ""} onChange={handleChange} className="border rounded-md px-3 py-1 focus:outline-none" />
                    </div>
                    <div className="flex flex-col">
                        <label htmlFor="role" className="mb-1 font-medium text-gray-800">Role</label>
                        <input type="text" id="role" name='role' value={data['role'] || ""} onChange={handleChange} className="border rounded-md px-3 py-1 focus:outline-none" />
                    </div>

                    <div className='flex justify-between gap-5'>
                    <button
                        type="submit"
                        onClick={handleAddMember}
                        className="bg-violet-500 hover:bg-indigo-500 text-white font-semibold px-4 py-2 rounded-md"
                    >
                        Add
                    </button>
                    <button
                        type="button"
                        onClick={()=>setIsModalOpen(false)}
                        className="text-gray-600 hover:text-white hover:bg-indigo-500  font-semibold px-4 py-2 rounded-md border border-gray-300"
                    >
                        Cancel
                    </button>
                    </div>
                </form>
            </div>
        </div>
    )}

    {/* ...Existing code... */}
    
    {/* Add Members button */}
    <button
        onClick={()=>setIsModalOpen(true)}
        className=" whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 py-2 rounded-md"
    >
        Add Members
    </button></div>
  )
}

export default AddMember