
const CorporateMemberAttendance = () => {
    return (
        <div className='space-y-3'>
            <div className='rounded-lg bg-white p-4 flex justify-between items-center'>
                <div className='text-lg font-medium'>
                    Date: 25 December, 2023 
                </div>
                <div className='text-lg font-medium'>
                    Total: <span className='text-violet-500'>142</span> 
                </div>
                <div className='flex text-lg font-medium border rounded-full border-violet-500'>
                    <div className='px-6 py-2 rounded-full bg-violet-500 text-white'>Present</div>
                    <div className='px-6 py-2 rounded-full '>Absent</div>
                </div>
            </div>
            <div>
            <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table className="w-full text-sm text-center rtl:text-right text-black">
                <thead className="text-xs text-gray-900 uppercase bg-gray-50 ">
                    <tr>
                        <th scope="col" className="px-3 py-3">
                            Photo
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Employ ID
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Name
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Position
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Category
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Shift
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Entry Time
                        </th>
                        <th scope="col" className="px-3 py-3">
                            Leave Time
                        </th>
                        <th scope="col" className="px-3 w-32 py-3">
                            Late Arrival Reason
                        </th>
                        <th scope="col" className="px-3 w-32 py-3">
                            Early Departure Reason
                        </th>
                        <th scope="col" className="px-3 w-32 py-3">
                            Work Duration
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr className="odd:bg-white even:bg-gray-50  border-b ">
                        <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                            <img className='rounded-md h-16' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        </th>
                        <td className="px-3 py-4 font-semibold">
                            wd0092
                        </td>
                        <td className="px-3 py-4">
                            Shamsu Uddin
                        </td>
                        <td className="px-3 py-4">
                            Employee
                        </td>
                        <td className="px-3 py-4">
                            Part time
                        </td>
                        <td className="px-3 py-4">
                            Day
                        </td>
                        <td className="px-3 py-4">
                            8.10 am
                        </td>
                        <td className="px-3 py-4">
                            3.00 pm
                        </td>
                        <td className="px-3 py-4">
                            Traffic zam
                        </td>
                        <td className="px-3 py-4">
                            Nan
                        </td>
                        <td className="px-3 py-4">
                            6.50 hrs
                        </td>
                    </tr>
                    <tr className="odd:bg-white even:bg-gray-50  border-b ">
                        <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                            <img className='rounded-md h-16' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        </th>
                        <td className="px-3 py-4 font-semibold">
                            wd0092
                        </td>
                        <td className="px-3 py-4">
                            Shamsu Uddin
                        </td>
                        <td className="px-3 py-4">
                            Employee
                        </td>
                        <td className="px-3 py-4">
                            Part time
                        </td>
                        <td className="px-3 py-4">
                            Day
                        </td>
                        <td className="px-3 py-4">
                            8.10 am
                        </td>
                        <td className="px-3 py-4">
                            3.00 pm
                        </td>
                        <td className="px-3 py-4">
                            Traffic zam
                        </td>
                        <td className="px-3 py-4">
                            Nan
                        </td>
                        <td className="px-3 py-4">
                            6.50 hrs
                        </td>
                    </tr>
                    <tr className="odd:bg-white even:bg-gray-50  border-b ">
                        <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                            <img className='rounded-md h-16' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        </th>
                        <td className="px-3 py-4 font-semibold">
                            wd0092
                        </td>
                        <td className="px-3 py-4">
                            Shamsu Uddin
                        </td>
                        <td className="px-3 py-4">
                            Employee
                        </td>
                        <td className="px-3 py-4">
                            Part time
                        </td>
                        <td className="px-3 py-4">
                            Day
                        </td>
                        <td className="px-3 py-4">
                            8.10 am
                        </td>
                        <td className="px-3 py-4">
                            3.00 pm
                        </td>
                        <td className="px-3 py-4">
                            Traffic zam
                        </td>
                        <td className="px-3 py-4">
                            Nan
                        </td>
                        <td className="px-3 py-4">
                            6.50 hrs
                        </td>
                    </tr>
                    <tr className="odd:bg-white even:bg-gray-50  border-b ">
                        <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                            <img className='rounded-md h-16' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        </th>
                        <td className="px-3 py-4 font-semibold">
                            wd0092
                        </td>
                        <td className="px-3 py-4">
                            Shamsu Uddin
                        </td>
                        <td className="px-3 py-4">
                            Employee
                        </td>
                        <td className="px-3 py-4">
                            Part time
                        </td>
                        <td className="px-3 py-4">
                            Day
                        </td>
                        <td className="px-3 py-4">
                            8.10 am
                        </td>
                        <td className="px-3 py-4">
                            3.00 pm
                        </td>
                        <td className="px-3 py-4">
                            Traffic zam
                        </td>
                        <td className="px-3 py-4">
                            Nan
                        </td>
                        <td className="px-3 py-4">
                            6.50 hrs
                        </td>
                    </tr>
                    <tr className="odd:bg-white even:bg-gray-50  border-b ">
                        <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                            <img className='rounded-md h-16' src="https://i.ibb.co/KD3H57R/shamsuuddin-image.jpg" alt="" />
                        </th>
                        <td className="px-3 py-4 font-semibold">
                            wd0092
                        </td>
                        <td className="px-3 py-4">
                            Shamsu Uddin
                        </td>
                        <td className="px-3 py-4">
                            Employee
                        </td>
                        <td className="px-3 py-4">
                            Part time
                        </td>
                        <td className="px-3 py-4">
                            Day
                        </td>
                        <td className="px-3 py-4">
                            8.10 am
                        </td>
                        <td className="px-3 py-4">
                            3.00 pm
                        </td>
                        <td className="px-3 py-4">
                            Traffic zam
                        </td>
                        <td className="px-3 py-4">
                            Nan
                        </td>
                        <td className="px-3 py-4">
                            6.50 hrs
                        </td>
                    </tr>
                    {/* Add other table rows here */}
                </tbody>
            </table>
        </div>
            </div>
        </div>

    );
};

export default CorporateMemberAttendance;