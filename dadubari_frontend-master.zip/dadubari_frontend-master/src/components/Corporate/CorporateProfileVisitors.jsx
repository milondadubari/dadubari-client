import axiosInstance from "../../services";
import { authorization } from "../../utils/authorization";
import { useEffect, useState } from "react";

const CorporateProfileVisitors = ({id}) => {
    const [visitors, setVisitors] = useState([]);
    const getAllPendingVisitors =async()=>{
        try {
            const res = await axiosInstance.get(`/api/v4/corporate/profile/getAllPending/${id}`,authorization);
            setVisitors(res?.data?.pendingVisitors);
        } catch (error) {console.log("first")}
    }
    useEffect(()=>{
        getAllPendingVisitors();
    },[])
    return (
        <div className='space-y-3'>
            <div className='rounded-lg bg-white p-4 flex justify-between items-center'>
                <div className='text-lg font-medium'>
                    Total Application: <span className='text-violet-500'>{visitors.length}</span>
                </div>
                <div className='flex text-lg font-medium border rounded-full border-violet-500'>
                    <div className='px-6 py-2 rounded-full bg-violet-500 text-white'>Application</div>
                    <div className='px-6 py-2 rounded-full border-violet-500 border-r-2'>Visited</div>
                    <div className='px-6 py-2 rounded-full '>Rejected</div>
                </div>
            </div>
            <div>
                <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table className="w-full text-sm text-center rtl:text-right text-black">
                        <thead className="text-xs text-gray-900 uppercase bg-gray-50 ">
                            <tr>
                                <th scope="col" className="px-3 py-3">
                                    Photo
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Name
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Designation
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Company
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Visiting time
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Visiting Topic
                                </th>
                                <th scope="col" className="px-3 py-3">
                                    Visiting Status
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                visitors?.map((visitor)=>{
                                    return(
                                        <tr key={visitor._id} className="odd:bg-white even:bg-gray-50  border-b ">
                                <th scope="row" className="px-3 py-4 font-medium text-gray-900 whitespace-nowrap">
                                    <img className='rounded-md h-16' src={`${visitor?.visitorInCorporate?.avatar?.url}`} alt="" />
                                </th>
                                <td className="px-3 py-4 font-semibold">
                                    {visitor?.applicantName}
                                </td>
                                <td className="px-3 py-4">
                                    {visitor?.designation}
                                </td>
                                <td className="px-3 py-4">
                                    ABC company
                                </td>
                                <td className="px-3 py-4">
                                    13 Dec, 2023 , Saturaday (9.00 am - 11.00 am)
                                </td>
                                <td className="px-3 py-4">
                                    Meeting with Manager
                                </td>
                                <td className="px-3 py-4">
                                    {visitor?.situation}
                                </td>
                            </tr>
                                    )
                                })
                            }
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default CorporateProfileVisitors;