import { useEffect, useState } from 'react';
import { authorization } from '../../utils/authorization';
import axiosInstance from '../../services';
import AddMember from './AddMember';
import { Link } from 'react-router-dom';


const CorporateProfileMembers = ({id, page}) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [members,setMembers] = useState([]);
    const getMembers = async()=>{
        try {
            const res = await axiosInstance.get(`api/v4/corporate/profile/get-all-members/${id}`,authorization);
            setMembers(res?.data?.content);
        } catch (error) {}
    }
    useEffect(()=>{
        getMembers();
    },[])

    return (
        <div className='rounded-lg bg-white p-4 space-y-4 w-full'>
            <div className="flex flex-wrap justify-between gap-4 bg-white rounded-lg">
                <div className='flex flex-wrap gap-4 md:min-w-[500px]'>
                    <input
                        type="text"
                        className="h-10 bg-gray-100 rounded-md flex-1 px-4 text-gray-800 focus:outline-none"
                        placeholder="Search by keyword"
                    />
                    <button
                        type="submit"
                        className="whitespace-nowrap bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 py-2 rounded-md"
                    >
                        {" "}
                        Search
                    </button>
                </div>
                {
                    page === "my" ? (<AddMember isModalOpen={isModalOpen} setIsModalOpen={setIsModalOpen} id={id} />) : page ==="others" ? (<Link to={'/corporate/apply-to-visit'}>
                    < button className="text-white border p-2 px-6 rounded-md transition ease-in-out delay-50  bg-purple-500 border-purple-500 transform duration-500 hover:-translate-y-1 text-lg font-medium">
                            Apply To Visit
                    </button>
                </Link>) : ""
                
                }
            </div>
            <div className='flex flex-wrap gap-3 justify-between'>
                {
                    members?.map((member)=>{
                        return(
                            <div key={member?._id} className="bg-gray-50 flex-1 p-4 rounded-lg">
                    <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                        <a href="#">
                            <img className="rounded-t-lg mb-5" src={`${member?.membersInCorporate?.avatar?.url}`} alt="product image" />
                        </a>
                        <div className="px-5 pb-5 space-y-1 text-center">
                            <h5 className="text-xl font-bold tracking-tight text-gray-900">{member?.membersInCorporate?.name}</h5>
                            <p className="text-lg font-semibold text-gray-900">Position: {member?.position}</p>
                            <p className="text-lg font-semibold text-gray-900">Role: {member?.role}</p>
                            <p className="text-lg font-semibold text-gray-900">Email: {member?.membersInCorporate?.email}</p>
                            <div className='flex justify-center'>
                                <img className="rounded-t-lg mb-5 !mt-3 h-40" src="https://i.ibb.co/ZWJy49G/qrc.jpg" alt="QR code" />
                            </div>

                        </div>
                    </div>
                </div>
                        )
                    })
                }
            </div>
        </div>
    );
};

export default CorporateProfileMembers;