import { useSelector } from "react-redux";

const WelcomeMessage = () => {
  const userDetails = useSelector((data) => data?.users?.data);

  // Function to get the time of day
  const getTimeOfDay = () => {
    const currentTime = new Date().getHours();
    if (currentTime >= 5 && currentTime < 12) {
      return "morning";
    } else if (currentTime >= 12 && currentTime < 17) {
      return "afternoon";
    } else if (currentTime >= 17 && currentTime < 21) {
      return "evening";
    } else {
      return "night";
    }
  };

  // Get the appropriate greeting based on the time of day
  const greeting = getTimeOfDay();

  // Define content for each time of day
  const greetingsContent = {
    morning: {
      text: "Good morning",
      message:
        "Mornings are life’s way of saying that you can start your dreams.",
      image: "https://img.icons8.com/arcade/64/morning.png",
    },
    afternoon: {
      text: "Good afternoon",
      message: "Afternoons are a great time to recharge and continue your day.",
      image: "https://img.icons8.com/arcade/64/afternoon.png",
    },
    evening: {
      text: "Good evening",
      message: "Evenings are a time to relax and unwind. Enjoy your evening!",
      image: "https://img.icons8.com/arcade/64/evening.png",
    },
    night: {
      text: "Good night",
      message: "Time to rest and rejuvenate. Have a peaceful night!",
      image: "https://img.icons8.com/arcade/64/night.png",
    },
  };

  return (
    <div className="bg-white p-5 rounded-lg w-full">
      <div className="flex items-center">
        <div className="space-y-1 w-full">
          <h1 className="text-lg font-semibold">
            {greetingsContent[greeting].text}, {userDetails?.name}
          </h1>
          <p>{greetingsContent[greeting].message}</p>
        </div>
        <div>
          <img
            className="motion-safe:animate-bounce"
            src={greetingsContent[greeting].image}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default WelcomeMessage;
