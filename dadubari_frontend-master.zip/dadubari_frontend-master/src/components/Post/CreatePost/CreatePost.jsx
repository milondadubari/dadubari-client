import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  createPostsReducer,
  getPostsReducer,
} from "../../../Reducers/postReducers/postSlice";
import uploadImage from "../../../icons/svg/uploadImage.svg";
import uploadVideo from "../../../icons/svg/uploadVideo.svg";
import uploadFiles from "../../../icons/svg/uploadFiles.svg";
import moreIcon from "../../../icons/svg/moreIcon.svg";
import createPostIcon from "../../../icons/svg/createPostIcon.svg";
import { toast } from "react-toastify";
import { toastDesign } from "../../../Reducers/userReducers/userSlice";
import { Link } from 'react-router-dom';

const CreatePost = () => {
  const [image, setImage] = useState("");
  const [video, setVideo] = useState("");
  const [caption, setCaption] = useState("");

  const dispatch = useDispatch();

  //!hanlde video
  const handleVideoChange = (e) => {
    const file = e.target.files[0];
    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        setVideo(Reader.result);
      }
    };
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];

    const Reader = new FileReader();
    Reader.readAsDataURL(file);
    Reader.onload = () => {
      if (Reader.readyState === 2) {
        setImage(Reader.result);
      }
    };
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    if (caption.trim().length <= 0 && image === "" && video === "") {
      toast.error("Write something to post", toastDesign);
      return;
    }
    const data = {
      image,
      caption,
      video,
    };
    await dispatch(createPostsReducer(data));
    setImage("");
    setVideo("");
    dispatch(getPostsReducer());
  };

  const userDetails = useSelector((da) => da?.users?.data);
  return (
    <form onSubmit={submitHandler}>
      <div className="bg-white p-5 rounded-lg w-full">
        {
          <div className="w-full flex justify-center mb-3 gap-4">
            {image && <img className="w-16" src={image} alt="" />}
            {video && (
              <video className="w-20" controls>
                <source src={video} />
              </video>
            )}
          </div>
        }

        <div className="flex gap-5 w-full">
          <img
            src={userDetails?.avatar?.url}
            alt="User"
            className="w-11 h-11 object-cover object-top rounded-xl hidden sm:block"
          />

          <div className="w-full">
            <div className="flex gap-4">
              <textarea
                type="text"
                value={caption}
                className="h-auto bg-gray-100 rounded-md w-full px-4 py-1 text-gray-800 focus:outline-none"
                placeholder="What's going on? #Hashtag.. @Mention.."
                onChange={(e) => setCaption(e.target.value)}
              />
              <button
                type="submit"
                className="whitespace-nowrap max-h-8 hidden sm:block bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4 rounded-md"
              >
                {" "}
                Create Post
              </button>
              <button
                type="submit"
                className="whitespace-nowrap max-h-16 sm:hidden bg-violet-500 hover:bg-indigo-500 transition ease-in-out delay-50 transform duration-500 font-semibold text-white px-4  rounded-md"
              >
                {" "}
                <img src={createPostIcon} alt="" />
              </button>
            </div>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          {/* upload image */}
          <div>
            <label htmlFor="fileInputAvatar" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadImage} alt="" />{" "}
                <span className="hidden sm:block ">Upload Images</span>
              </div>
            </label>
            <input
              type="file"
              id="fileInputAvatar"
              accept="image/*"
              onChange={handleImageChange}
              className="opacity-0 hidden"
            />
          </div>
          {/*upload  video*/}
          <div>
            <label htmlFor="fileInputCover" className="cursor-pointer">
              <div className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
                <img className="w-5" src={uploadVideo} alt="" />{" "}
                <span className="hidden sm:block ">Upload Videos</span>
                <input
                  type="file"
                  id="fileInputCover"
                  accept="video/*"
                  onChange={handleVideoChange}
                  className="opacity-0 hidden"
                />
              </div>
            </label>
          </div>

          <Link to={"/Coming-soon"} className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
            <img src={uploadFiles} className="h-5" alt="" />{" "}
            <span className="hidden sm:block ">Upload Files</span>
          </Link>
          <Link to={"/Coming-soon"} className="whitespace-nowrap p-3 border border-gray-200 hover:bg-gray-100 text-gray-700 rounded-md font-semibold flex gap-2 items-center duration-500">
            <img src={moreIcon} className="h-5" alt="" />{" "}
            <span className="hidden sm:block ">More</span>
          </Link>
        </div>
      </div>
    </form>
  );
  
};

export default CreatePost;
