import commentReply from "../../../icons/svg/commentReply.svg";
import commentMore from "../../../icons/svg/commentMore.svg";
import { useEffect, useState } from "react";
import { postTime } from "./NormalPost";
import axiosInstance from "../../../services";
import { authorization } from "../../../utils/authorization";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { toastDesign } from "../../../Reducers/userReducers/userSlice";
import User from "../../../pages/User/User";

const PostComment = ({ getSinglePostDetails, postOwnerId, postId }) => {
  const [isCommentEditViewOpen, setIsCommentEditViewOpen] = useState("");
  const [commentTitle, setCommentTitle] = useState("");
  const [comments, setComments] = useState([]);
  const logedInUserId = useSelector((data) => data.users?.data?._id);

  //!getAllcomment
  const getAllCommentsOfAPost = async (postId) => {
    try {
      const data = await axiosInstance.get(
        `/api/v2/get-commments/post/${postId}`,
        authorization
      );
      setComments(data.data.comments);
    } catch (error) {
      console.log(error);
    }
  };

  //!Add comment
  const handleComment = async (e) => {
    e.preventDefault();
    if (postId) {
      try {
        const data = await axiosInstance.post(
          `/api/v2/add-comment/${postId}`,
          { comment: commentTitle },
          authorization
        );
        if (data) {
          toast.success("comment added",toastDesign)
          getAllCommentsOfAPost(postId);
          getSinglePostDetails();
          setCommentTitle("");
        }
      } catch (error) {
        toast.error("comment failed",toastDesign)
        console.log(error);
      }
    }
  };

  //!delete comment
  const handleDeleteComment = async (id) => {
    try {
      const data = await axiosInstance.delete(
        `api/v2/delete-comment/${id}`,
        authorization
      );
      if (data) {
        toast.success("comment deleted",toastDesign)
        getAllCommentsOfAPost(postId);
      }
    } catch (error) {
      toast.error("comment delete failed",toastDesign)
      console.log(error);
    }
  };

  useEffect(() => {
    getAllCommentsOfAPost(postId);
  }, [postId]);
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-bold text-gray-900">
            Comment ({comments?.length})
        </h2>
      </div>
      <form onSubmit={handleComment} className="mb-4">
        <div className="py-2 px-4 mb-4 bg-white rounded-lg rounded-t-lg border border-gray-200">
          <label htmlFor="comment" className="sr-only">
              Your comment
          </label>
            <textarea
              id="comment"
              rows="1"
              className="px-0 w-full text-sm text-gray-900 border-0 focus:ring-0 focus:outline-none placeholder-gray-900 "
              placeholder="Write a comment..."
              name="comment"
              value={commentTitle}
              onChange={(e) => setCommentTitle(e.target.value)}
              required
            ></textarea>
          </div>
          <button
            type="submit"
            className="inline-flex items-center py-2 px-4 text-xs font-medium text-center text-gray-950 bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-200  bg-gray-200 hover:shadow-md transition ease-in-out delay-50"
          >
            Post comment
          </button>
        </form>

        {comments &&
          comments?.map((comment) => {
            const time = postTime(new Date(comment?.createdAt).getTime());
            return (
              <div key={comment?._id}>
                <article className="p-6 text-base bg-white rounded-lg">
                  <footer className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <p className="inline-flex items-center mr-3 text-sm text-gray-900 font-semibold">
                        <img
                          className="mr-2 w-6 h-6 rounded-full"
                          src={comment?.user?.avatar?.url}
                          alt="Michael Gough"
                        />
                        <User userName={comment?.user?.name} userid={comment?.user?._id} />
                      </p>
                      <p className="text-sm text-gray-600 ">
                        <time dateTime="2022-02-08" title="February 8th, 2022">
                          {time}
                        </time>
                      </p>
                    </div>
                    <button
                      id="dropdownComment1Button"
                      data-dropdown-toggle="dropdownComment1"
                      className="inline-flex items-center p-2 text-sm font-medium text-center text-gray-700 bg-white rounded-lg hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-50"
                      type="button"
                      onClick={() =>
                        setIsCommentEditViewOpen((prev) =>
                          prev === comment?._id ? "" : comment?._id
                        )
                      }
                    >
                      <img src={commentMore} className="w-4 h-4" alt="" />
                      <span className="sr-only">Comment settings</span>
                    </button>
                    {/* <!-- Dropdown menu --> */}
                    {/* //! Here is some issue in the drop down button , do fix it. yes there will be different components for edit and delete */}
                    <div
                      className={`${
                        isCommentEditViewOpen === comment?._id
                          ? "bolck"
                          : "hidden"
                      }`}
                    >
                      <div
                        id="dropdownComment1"
                        className="z-10 w-36 bg-white rounded divide-y divide-gray-100 shadow"
                      >
                        <ul
                          className="py-1 text-sm text-gray-700 "
                          aria-labelledby="dropdownMenuIconHorizontalButton"
                        >
                          <li>
                            <button
                              href="#"
                              className="block py-2 px-4 hover:bg-gray-100"
                            >
                              Edit
                            </button>
                          </li>
                          {logedInUserId === postOwnerId ||
                          logedInUserId === comment?.user?._id ? (
                            <li>
                              <button
                                href="#"
                                className="block py-2 px-4 hover:bg-gray-100 "
                                onClick={() =>
                                  handleDeleteComment(comment?._id)
                                }
                              >
                                Remove
                              </button>
                            </li>
                          ) : (
                            ""
                          )}
                          <li>
                            <button
                              href="#"
                              className="block py-2 px-4 hover:bg-gray-100 "
                            >
                              Report
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </footer>
                  <p className="text-gray-500 ">{comment?.comment}</p>
                  <div className="flex items-center mt-4 space-x-4">
                    <button
                      type="button"
                      className="flex items-center text-sm text-gray-500 hover:underline  font-medium"
                    >
                      <img
                        src={commentReply}
                        className="mr-1.5 w-3.5 h-3.5"
                        alt=""
                      />
                      Reply
                    </button>
                  </div>
                </article>
              </div>
            );
          })}
      </div>
    
  );
};

export default PostComment;
