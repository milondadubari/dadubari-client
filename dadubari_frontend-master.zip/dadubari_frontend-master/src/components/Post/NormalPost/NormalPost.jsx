import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../../services";
import { AiOutlineLike } from "react-icons/ai";
import PostComment from "./PostComment";
import { authorization } from "../../../utils/authorization";
import commentMore from "../../../icons/svg/commentMore.svg";
import commentIcon from "../../../icons/svg/commentIcon.svg";
import closeIcon from "../../../icons/svg/closeIcon.svg";
import shareIcon from "../../../icons/svg/shareIcon.svg";
import { getAllMyPosts } from "../../../Reducers/postReducers/getSingleUserPostSlice";
import { toast } from "react-toastify";
import { toastDesign } from "../../../Reducers/userReducers/userSlice";
import { Link, useNavigate } from "react-router-dom";
import User from "../../../pages/User/User";
import postCommentIcon from "../../../icons/svg/postCommentIcon.svg"

export const postTime = (date) => {
  let seconds = Math.floor((new Date() - date) / 1000);

  let interval = seconds / 31536000;

  if (interval > 1 && interval <= 2) return Math.floor(interval) + " year ago";
  if (interval > 1) return Math.floor(interval) + " years ago";
  interval = seconds / 2592000;
  if (interval > 1 && interval <= 2) return Math.floor(interval) + " month ago";
  if (interval > 1) return Math.floor(interval) + "months ago";

  interval = seconds / 86400;
  if (interval > 1 && interval <= 2) return Math.floor(interval) + " day ago";
  if (interval > 1) return Math.floor(interval) + " days ago";
  interval = seconds / 3600;
  if (interval > 1 && interval <= 2) return Math.floor(interval) + " hour ago";
  if (interval > 1) return Math.floor(interval) + " hours ago";
  interval = seconds / 60;
  if (interval > 1 && interval <= 2)
    return Math.floor(interval) + " minute ago";
  if (interval > 1) return Math.floor(interval) + " minutes ago";
  return "Just now";
};

const NormalPost = ({ data }) => {
  //!states
  const [postDetails, setPostDeatils] = useState("");
  const [likeUnlike, setLikeUnlike] = useState("");
  const [isLiked, setisLiked] = useState(false);
  const [postComment, setPostComment] = useState("");
  const [isPostEditViewOpen, setIsPostEditViewOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const dispatch = useDispatch();

  //!like details of post
  const getSinglePostDetails = async () => {
    try {
      const res = await axiosInstance.get(
        `/api/v2/get-post/${data?._id}`,
        authorization
      );
      setPostComment(res?.data?.post?.comments);
      setPostDeatils(res?.data?.post?.likes);
    } catch (error) {
      console.log("single post found error");
    }
  };

  useEffect(() => {
    getSinglePostDetails();
  }, []);

  const navigate = useNavigate();
  //!delete post
  const handleDletePost = async (id) => {
    try {
      const res = await axiosInstance.delete(
        `/api/v2/delete-post/${id}`,
        authorization
      );
      if (res?.data) {
        toast.success("post deleted", toastDesign)
        dispatch(getAllMyPosts());
        navigate("/profile");
      }
    } catch (error) {
      toast.success("post delete failed", toastDesign)
    }
  };

  //!Handling Like and Unlike
  const handleLikeAndUnlike = async () => {
    setisLiked((prev) => !prev);
    try {
      const res = await axiosInstance.patch(
        `/api/v2/like-and-unlike/${data?._id}`,
        data?._id,
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("dadubari")}`,
          },
        }
      );
      setLikeUnlike(res?.data);
      getSinglePostDetails();
    } catch (error) {
      console.log("like unlike error");
    }
  };

  //!user data
  const userDetails = useSelector((da) => da?.users?.data);

  useEffect(() => {
    if (postDetails.includes(userDetails?._id)) {
      setisLiked(true);
    }
  }, [userDetails?._id, postDetails]);


  const time = postTime(new Date(data?.createdAt).getTime());
  return (
    <div className="bg-white p-5 rounded-lg w-full">
      <div className="flex justify-between">
        <div className="flex gap-4 w-full items-center my-4">
          {/* Profile */}
          <img
            src={data?.owner?.avatar?.url}
            alt="User"
            className=" w-12 h-12 md:w-16 md:h-16 object-cover object-top rounded-md shadow-lg bg-black"
          />
          <div>
            <h1 className="text-gray-700 flex items-center gap-2 flex-wrap">
              <h1 className="font-medium text-black text-lg"><User userid={data?.owner?._id} userName={data?.owner?.name} /></h1>
              {data?.image
                ? "uploaded new photo"
                : data?.video
                  ? "uploaded new video"
                  : "has a status"}
            </h1>
            <p className="text-gray-400">{time}</p>
          </div>
        </div>

        <img
          src={commentMore}
          onClick={() => setIsPostEditViewOpen((prev) => !prev)}
          className="w-4 h-4 cursor-pointer"
          alt=""
        />
      </div>
      <div>
        <div>
          <div className={`${isPostEditViewOpen ? "bolck" : "hidden"}`}>
            <div
              id="dropdownComment1"
              className="z-10 w-36 bg-white rounded divide-y divide-gray-100 shadow"
            >
              <ul
                className="py-1 text-sm text-gray-700 "
                aria-labelledby="dropdownMenuIconHorizontalButton"
              >
                {data?.owner._id === userDetails._id ? (
                  <li>
                    <button
                      href="#"
                      className="block py-2 px-4 hover:bg-gray-100"
                    >
                      Edit
                    </button>
                  </li>
                ) : (
                  ""
                )}
                {data?.owner._id === userDetails._id ? (
                  <li>
                    <button
                      href="#"
                      className="block py-2 px-4 hover:bg-gray-100"
                      onClick={() => handleDletePost(data?._id)}
                    >
                      Remove
                    </button>
                  </li>
                ) : (
                  ""
                )}
                <li>
                  <Link to={"/Coming-soon"}
                    className="block py-2 px-4 hover:bg-gray-100 "
                  >
                    Report
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div>
          {data?.image ? (
            <img
              src={data?.image?.url}
              className="mt-6 mx-auto max-h-52 md:max-h-80 w-auto rounded-lg"
              alt=""
            />
          ) : (
            ""
          )}
        </div>
        <div>
          {data?.video ? (
            <video
              className="mt-6 mx-auto max-h-52 md:max-h-80 w-auto rounded-lg"
              controls
            >
              <source src={data?.video?.url} />
            </video>
          ) : (
            ""
          )}
        </div>
        {/* post content */}
        <h1 className="py-3">{data?.caption}</h1>
      </div>
      <hr className="mt-2" />
      <div className="mt-4 px-3 flex items-center justify-between">
        {/* Like comment share icon */}
        <div className="flex gap-2 items-center">
          {/* Like icon */}
          {!isLiked ? (
            <AiOutlineLike
              onClick={handleLikeAndUnlike}
              className="text-violet-500 w-6 h-6 cursor-pointer transform duration-500 hover:-translate-y-1"
            />
          ) : (
            <svg
              className="w-6 h-6 transition ease-in-out delay-50 hover:text-violet-500 transform duration-500 hover:-translate-y-1 cursor-pointer"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              onClick={handleLikeAndUnlike}
            >
              <path
                d="M20.2694 16.265L20.9749 12.1852C21.1511 11.1662 20.3675 10.2342 19.3345 10.2342H14.1534C13.6399 10.2342 13.2489 9.77328 13.332 9.26598L13.9947 5.22142C14.1024 4.56435 14.0716 3.892 13.9044 3.24752C13.7659 2.71364 13.354 2.28495 12.8123 2.11093L12.6673 2.06435C12.3399 1.95918 11.9826 1.98365 11.6739 2.13239C11.3342 2.29611 11.0856 2.59473 10.9935 2.94989L10.5178 4.78374C10.3664 5.36723 10.1460 5.93045 9.8617 6.46262C9.44634 7.24017 8.80416 7.86246 8.13663 8.43769L6.69789 9.67749C6.29223 10.0271 6.07919 10.5506 6.12535 11.0844L6.93752 20.4771C7.01201 21.3386 7.73231 22 8.59609 22H13.2447C16.726 22 19.697 19.5744 20.2694 16.265Z"
                fill="#8B5CF6"
              ></path>
              <path
                opacity="0.5"
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.96767 9.48508C3.36893 9.46777 3.71261 9.76963 3.74721 10.1698L4.71881 21.4063C4.78122 22.1281 4.21268 22.7502 3.48671 22.7502C2.80289 22.7502 2.25 22.1954 2.25 21.5129V10.2344C2.25 9.83275 2.5664 9.50240 2.96767 9.48508Z"
                fill="#8B5CF6"
              ></path>
            </svg>
          )}
          {/* comment icon */}
          <img className="h-9 transform duration-500 hover:-translate-y-1 cursor-pointer" src={commentIcon} onClick={openModal} alt="" />
          {/* Share icon */}
          <Link to={"/Coming-soon"}>
            <img className="h-9 transform duration-500 hover:-translate-y-1 cursor-pointer" src={shareIcon} alt="" />
          </Link>
        </div>
        <div className="flex gap-3 text-gray-500">
          <p>
            {postDetails?.length <= 1
              ? `${postDetails?.length}  like`
              : `${postDetails?.length} likes`}{" "}
          </p>
          <p>{`${postComment?.length <= 1
              ? postComment?.length + " comment"
              : postComment?.length + " comments"
            }`}</p>
        </div>
      </div>
      {/* comment section */}
      <div className="mt-4 ">
        {isModalOpen && (
          <div className="fixed z-10 inset-0 lg:top-20 top-16 overflow-y-auto flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-gray-100 rounded-lg p-4 md:p-8 antialiased max-h-[80vh] md:max-h-[70vh] w-[90vw] md:w-[60vw] overflow-y-scroll relative">
              <button onClick={closeModal}><img className="h-7 transform duration-500 hover:-translate-y-1 absolute right-10" src={closeIcon} alt="" /></button> 
            <PostComment
              comments={data?.comments}
              postId={data?._id}
              postOwnerId={data?.owner?._id}
              getSinglePostDetails={getSinglePostDetails}
            />
            </div>  
          
          </div>

        )}



      </div>
    </div>
  );
};

export default NormalPost;
