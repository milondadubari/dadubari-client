import { useEffect, useState } from "react";
import CreatePost from "../../Post/CreatePost/CreatePost";
import WelcomeMessage from "../../Post/WelcomeMessage/WelcomeMessage";
import NormalPost from "../../Post/NormalPost/NormalPost";
import ReelVideo from "../../Post/ReelVideo/ReelVideo";
import axiosInstance from "../../../services";
import { PostContext } from "../../../context/PostContext";

const CenterSidebar = () => {
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  let isLength = true;

  const {post , setPost, length , setLength} = PostContext();

  useEffect(() => {
    const getHomeData = async () => {
      try {
        if (one > 0) return;
        if (page == 1) one++;
        if (post?.length < length) {
          const res = await axiosInstance.get(
            `/api/v2/get-all-posts/?limit=4&page=${page}`
          );

          if (res?.data?.posts?.length > 0) {
            setPost((prev) => [...prev, ...res?.data?.posts]);
            if (isLength) {
              isLength = false;
              setLength(res?.data?.totalData);
            }
          }
        }
      } catch (error) {
        console.log(error);
      }
    };
    getHomeData();
  }, [page]);

  const handleInfiniteScroll = async () => {
    try {
      if (
        window.innerHeight + document.documentElement.scrollTop + 10 >=
        document.documentElement.scrollHeight
      ) {
        setPage((prev) => prev + 1);
        setLoading(true);
      }
    } catch (error) {
      console.log(error);
    }
  };

  let one = 0;
  useEffect(() => {
    window.addEventListener("scroll", handleInfiniteScroll);
    return () => window.removeEventListener("scroll", handleInfiniteScroll);
  }, []);

  return (
    <div className="space-y-3">
      <ReelVideo></ReelVideo>
      <CreatePost></CreatePost>
      <WelcomeMessage></WelcomeMessage>
      <div>
        {post?.map((d) => {
          return (
            <div key={d?._id}>
              <NormalPost data={d} />
            </div>
          );
        })}
        {post.length < length && loading && (
          <p className="text-center">loading...</p>
        )}
      </div>
    </div>
  );
};

export default CenterSidebar;
