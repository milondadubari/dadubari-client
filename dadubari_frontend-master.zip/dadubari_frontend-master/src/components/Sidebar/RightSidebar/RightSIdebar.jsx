import MiniProfile from '../../UserProfile/MiniProfile/MiniProfile';
import Trendings from '../../Other/Trendings/Trendings';

const RightSIdebar = () => {
    return (
        <div className='space-y-3 sticky top-[90px]'>
            <MiniProfile></MiniProfile>
            <Trendings></Trendings>
        </div>
    );
};

export default RightSIdebar;