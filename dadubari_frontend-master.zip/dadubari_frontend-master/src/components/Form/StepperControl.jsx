const StepperControl = ({ handleClick, currentStep, allSteps }) => {
  return (
    <div className="container flex justify-around mt-4 mb-8">
      <button
        onClick={() => handleClick("back")}
        className={`bg-white text-slate-400 uppercase py-2 px-4 rounded-xl font-semibold curse-pointer border-2 border-slate-300 hover:bg-purple-600 hover:text-white transition duration-200 ease-in-out ${
          currentStep === 1 ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        Back
      </button>
      <button
        onClick={() => currentStep === allSteps?.length ? handleClick("submit") : handleClick("next")}
        className="bg-white text-slate-400 uppercase py-2 px-4 rounded-xl font-semibold curse-pointer border-2 border-slate-300 hover:bg-purple-600 hover:text-white transition duration-200 ease-in-out"
        type="submit"
      >
        {currentStep === allSteps?.length ? "Submit" : "Next"}
      </button>
    </div>
  );
};

export default StepperControl;
