import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../services";
import { toast } from "react-toastify";

export const toastDesign = {
  position: "bottom-center",
  autoClose: 5000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  progress: 0,
  theme: "dark",
};

export const userResister = createAsyncThunk(
  "users/userRegister",
  async (data, { rejectWithValue }) => {
    try {
      data = { ...data, email: data.email.toLowerCase() , userid : data.userid.toLowerCase() };
      if (data.password.length < 8) {
        return rejectWithValue("Password must be at least 8 characters");
      }
      const res = await axiosInstance.post("/api/v1/register", data);
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const userLogin = createAsyncThunk(
  "users/userLogin",
  async (data, { rejectWithValue }) => {
    try {
      data = { ...data, email: data.email.toLowerCase() };
      const res = await axiosInstance.post("/api/v1/login", data);
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const userLoginCheck = createAsyncThunk(
  "users/userLoginCheck",
  async (_, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.get("/api/v1/checkOut", {
        headers: {
          authorization: `Bearer ${localStorage.getItem("dadubari")}`,
        },
      });
      
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const userForgetPassword = createAsyncThunk(
  "users/userForgetPassword",
  async (data, { rejectWithValue }) => {
    try {
      data = { ...data, email: data.email.toLowerCase() };
      const res = await axiosInstance.post("/api/v1/forgetPassword", data);
      toast.success(res?.data?.message, toastDesign);
      return res.data;
    } catch (error) {
      toast.error(error?.response?.data?.message, toastDesign);
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const userEmailVerification = createAsyncThunk(
  "users/userEmailVerification",
  async ({ id, token }, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.get(
        `/api/v1/user/verification/${id}/${token}`
      );
      toast.success(res?.data?.message, toastDesign);
      return res.data;
    } catch (error) {
      toast.error(error?.response?.data?.message, toastDesign);
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const userUpdatePassword = createAsyncThunk(
  "users/userUpdatePassword",
  async ({ id, token, data }, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.post(
        `/api/v1/forget-password/${id}/${token}`,
        data
      );
      toast.success(res?.data?.message, toastDesign);
      return res.data;
    } catch (error) {
      toast.error(error?.response?.data?.message, toastDesign);
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

const initialState = {
  isLoading: false,
  data: [],
  isError: false,
  error: null,
  dadubari : localStorage.getItem('dadubari')
  ? localStorage.getItem('dadubari')
  : null,
};

const usersSlice = createSlice({
  name: "users",
  initialState,
  extraReducers: (builder) => {
    builder
      //!user register
      .addCase(userResister.pending, (state) => {
        state.isError = false;
        state.error = null;
        state.data = [];
      })
      .addCase(userResister.fulfilled, (state, action) => {
        state.isError = false;
        state.error = null;
        state.data = action.payload;
        toast.success(action.payload?.message, toastDesign);
      })
      .addCase(userResister.rejected, (state, action) => {
        state.isError = true;
        state.error = action.payload;
        state.data = [];
        toast.error(action.payload, toastDesign);
      })

      //!user login
      .addCase(userLogin.pending, (state) => {
        state.isError = false;
        state.error = null;
        state.data = [];
      })
      .addCase(userLogin.fulfilled, (state, action) => {
        state.data = action.payload;
        state.error = null;
        state.isError = false;
        state.dadubari = action.payload?.token
        localStorage.setItem("dadubari", action.payload?.token);
        toast.success(action.payload?.message, toastDesign);
      })
      .addCase(userLogin.rejected, (state, action) => {
        state.isLoading = false;
        state.data = [];
        state.isError = true;
        state.error = action.payload;
        state.dadubari = null;
        toast.error(action.payload, toastDesign);
      })

      //!check login
      .addCase(userLoginCheck.pending, (state) => {
        state.isError = false;
        state.error = null;
        state.data = [];
      })
      .addCase(userLoginCheck.fulfilled, (state, action) => {
        state.dadubari = action.payload?.token;
        state.isLoading = true;
        state.data = action.payload?.user;
        state.error = null;
        state.isError = false;
      })
      .addCase(userLoginCheck.rejected, (state, action) => {
        state.isLoading = false;
        state.data = [];
        state.isError = true;
        state.error = action.payload;
        state.dadubari = null;
        
      })

      //!forget password
      .addCase(userForgetPassword.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.error = null;
        state.data = [];
      })
      .addCase(userForgetPassword.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;
        state.error = null;
        state.isError = false;
      })
      .addCase(userForgetPassword.rejected, (state, action) => {
        state.isLoading = false;
        state.data = [];
        state.isError = true;
        state.error = action.payload;
      });
  },
});

export default usersSlice.reducer;
