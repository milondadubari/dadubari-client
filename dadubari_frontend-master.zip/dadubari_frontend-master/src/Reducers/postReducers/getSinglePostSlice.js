import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../services";


export const getSinglePost = createAsyncThunk("singlePost/getSinglePost",async(id, { rejectWithValue })=>{
    try {
        const res = await axiosInstance.get(`/api/v2/get-post/${id}`, {
          headers: {
            authorization: `Bearer ${localStorage.getItem("dadubari")}`,
          },
        });
        console.log(res)
        return res.data;
      } catch (error) {
        return rejectWithValue(error?.response?.data?.message);
      }
})

const initialState = {
    isLoading: false,
    data: [],
    isError: false,
    error: null,
  };

  const singlePostsSlice = createSlice({
    name: "singlePost",
    initialState,
    extraReducers: (builder) => {
      builder
        //!get all my posts
        .addCase(getSinglePost.pending, (state) => {
          state.isLoading = true;
          state.isError = false;
          state.error = null;
          state.data = [];
        })
        .addCase(getSinglePost.fulfilled, (state, action) => {
          state.isLoading = false;
          state.isError = false;
          state.error = null;
          state.data = action.payload;
  
        })
        .addCase(getSinglePost.rejected, (state, action) => {
          state.isLoading = false;
          state.isError = true;
          state.error = action.payload;
          state.data = [];
  
        });
    },
  });


  export default singlePostsSlice.reducer;