import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../services";
import { toast } from "react-toastify";
import { toastDesign } from "../userReducers/userSlice";

export const createPostsReducer = createAsyncThunk(
  "posts/createPostsReducer",
  async (data, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.post("/api/v2/create-post", data, {
        headers: {
          authorization: `Bearer ${localStorage.getItem("dadubari")}`,
        },
      });
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

export const getPostsReducer = createAsyncThunk(
  "posts/getPostsReducer",
  async (data, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.get("/api/v2/get-all-posts");
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

const initialState = {
  isLoading: false,
  data: [],
  isError: false,
  error: null,
};

const postsSlice = createSlice({
  name: "posts",
  initialState,
  extraReducers: (builder) => {
    builder
      //!create posts
      .addCase(createPostsReducer.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.error = null;
      })
      .addCase(createPostsReducer.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isError = false;
        state.error = null;
        toast.success(action.payload?.message, toastDesign);
      })
      .addCase(createPostsReducer.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.error = action.payload;

        toast.error(action.payload, toastDesign);
      })

      //!get all posts
      .addCase(getPostsReducer.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.error = null;
        state.data = [];
      })
      .addCase(getPostsReducer.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isError = false;
        state.error = null;
        state.data = action.payload;

      })
      .addCase(getPostsReducer.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.error = action.payload;
        state.data = [];

      });
  },
});

export default postsSlice.reducer;
