import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../services";

export const getAllMyPosts = createAsyncThunk(
  "myPosts/etAllMyPosts",
  async (_, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.get("/api/v2/get-all-my-posts", {
        headers: {
          authorization: `Bearer ${localStorage.getItem("dadubari")}`,
        },
      });
      return res.data;
    } catch (error) {
       return rejectWithValue(error?.response?.data?.message)
    }
  }
);

const initialState = {
    isLoading: false,
    data: [],
    isError: false,
    error: null,
  };

  const myPostsSlice = createSlice({
    name: "myPosts",
    initialState,
    extraReducers: (builder) => {
      builder
        //!get all my posts
        .addCase(getAllMyPosts.pending, (state) => {
          state.isLoading = true;
          state.isError = false;
          state.error = null;
          state.data = [];
        })
        .addCase(getAllMyPosts.fulfilled, (state, action) => {
          state.isLoading = false;
          state.isError = false;
          state.error = null;
          state.data = action.payload;
  
        })
        .addCase(getAllMyPosts.rejected, (state, action) => {
          state.isLoading = false;
          state.isError = true;
          state.error = action.payload;
          state.data = [];
  
        });
    },
  });


  export default myPostsSlice.reducer;