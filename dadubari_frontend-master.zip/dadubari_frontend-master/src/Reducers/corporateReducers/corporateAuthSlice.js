import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../services";
import { authorizationCorporateAndUser } from "../../utils/authorization";

export const corporateAuthCheck = createAsyncThunk(
  "corporateAuth/corporateAuthCheck",
  async (_, { rejectWithValue }) => {
    try {
      const res = await axiosInstance.get(
        `/api/v4/corporate/checkOut/`,
        authorizationCorporateAndUser
      );
      return res.data;
    } catch (error) {
      return rejectWithValue(error?.response?.data?.message);
    }
  }
);

const initialState = {
  isLoading: false,
  data: [],
  isError: false,
  error: null,
  corporateToken : null
};

const corporateAuthSlice = createSlice({
  name: "corporateAuth",
  initialState,
  extraReducers: (builder) => {
    builder
      //!get all my posts
      .addCase(corporateAuthCheck.pending, (state) => {
        state.isLoading = true;
        state.isError = false;
        state.error = null;
        state.data = [];
        state.corporateToken = null;
      })
      .addCase(corporateAuthCheck.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isError = false;
        state.error = null;
        state.data = action.payload;
        state.corporateToken = action.payload.token;
      })
      .addCase(corporateAuthCheck.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.error = action.payload;
        state.data = [];
        state.corporateToken = null;
        localStorage.removeItem("corporateToken");
      });
  },
});

export default corporateAuthSlice.reducer;
