/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    // colors: {
    //   ...colors,
    //   primary: "#0a192f",
    //   secondary: "#28e98c",
    //   white: "#fff",
    // },
    extend: {},
    fontFamily:{
      signature : ["Lobster"]
    },
    // screens: {
    //   'xxs': '325px',
    //   'xs' : '500px',
    //   'sm': '640px',
    //   'md': '768px',
    //   'lg': '1024px',
    // }
  },
  plugins: [],
}
